import { createReadStream, createWriteStream } from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import { createGzip } from 'zlib';
import { S3 } from 'aws-sdk';
import { config } from '../config';

const execAsync = promisify(exec);

export class BackupService {
  private static instance: BackupService;
  private s3: S3;

  private constructor() {
    this.s3 = new S3({
      accessKeyId: config.aws.accessKeyId,
      secretAccessKey: config.aws.secretAccessKey,
      region: config.aws.region
    });
  }

  static getInstance() {
    if (!BackupService.instance) {
      BackupService.instance = new BackupService();
    }
    return BackupService.instance;
  }

  async createBackup(): Promise<string> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupFileName = `backup-${timestamp}.gz`;
    const backupPath = path.join(__dirname, '../../backups', backupFileName);

    try {
      // إنشاء نسخة احتياطية من قاعدة البيانات
      await this.backupDatabase(backupPath);

      // رفع النسخة الاحتياطية إلى S3
      await this.uploadToS3(backupPath, backupFileName);

      return backupFileName;
    } catch (error) {
      console.error('Error creating backup:', error);
      throw new Error('فشل إنشاء النسخة الاحتياطية');
    }
  }

  private async backupDatabase(backupPath: string): Promise<void> {
    const { MONGODB_URI, DB_NAME } = config.database;

    try {
      await execAsync(
        `mongodump --uri="${MONGODB_URI}" --archive="${backupPath}" --gzip`
      );
    } catch (error) {
      console.error('MongoDB backup failed:', error);
      throw new Error('فشل نسخ قاعدة البيانات احتياطياً');
    }
  }

  private async uploadToS3(filePath: string, fileName: string): Promise<void> {
    const fileStream = createReadStream(filePath);
    const gzip = createGzip();

    const params = {
      Bucket: config.aws.backupBucket,
      Key: `backups/${fileName}`,
      Body: fileStream.pipe(gzip)
    };

    try {
      await this.s3.upload(params).promise();
    } catch (error) {
      console.error('S3 upload failed:', error);
      throw new Error('فشل رفع النسخة الاحتياطية');
    }
  }

  async scheduleBackups(): Promise<void> {
    // جدولة نسخ احتياطي يومي
    setInterval(async () => {
      try {
        await this.createBackup();
        console.log('تم إنشاء نسخة احتياطية بنجاح');
      } catch (error) {
        console.error('فشل النسخ الاحتياطي التلقائي:', error);
      }
    }, 24 * 60 * 60 * 1000); // كل 24 ساعة
  }
}