export const generateStageCode = (): string => {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const letterPart = Array.from({ length: 3 }, 
    () => letters[Math.floor(Math.random() * letters.length)]
  ).join('');
  const numberPart = Array.from({ length: 3 }, 
    () => Math.floor(Math.random() * 10)
  ).join('');
  return `${letterPart}${numberPart}`;
};

export const generateGradeCode = (): string => {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const letterPart = Array.from({ length: 4 }, 
    () => letters[Math.floor(Math.random() * letters.length)]
  ).join('');
  const numberPart = Array.from({ length: 2 }, 
    () => Math.floor(Math.random() * 10)
  ).join('');
  return `${letterPart}${numberPart}`;
};

export const generateSubjectCode = (): string => {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const letterPart = Array.from({ length: 4 }, 
    () => letters[Math.floor(Math.random() * letters.length)]
  ).join('');
  const numberPart = Array.from({ length: 3 }, 
    () => Math.floor(Math.random() * 10)
  ).join('');
  return `${letterPart}${numberPart}`;
};