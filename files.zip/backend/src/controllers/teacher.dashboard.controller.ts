import { Request, Response } from 'express';
import { Teacher } from '../models/Teacher';
import { Exam } from '../models/Exam';
import { Student } from '../models/Student';
import { ExamResult } from '../models/ExamResult';

export const teacherDashboardController = {
  async getStats(req: Request, res: Response) {
    try {
      const teacherId = req.user.id;

      // إحصائيات عامة
      const totalStudents = await Student.countDocuments({
        assignedTeacher: teacherId
      });

      const totalExams = await Exam.countDocuments({
        teacher: teacherId
      });

      const completedExams = await ExamResult.countDocuments({
        'exam.teacher': teacherId,
        status: 'completed'
      });

      // الاختبارات القادمة
      const upcomingExams = await Exam.find({
        teacher: teacherId,
        startDate: { $gt: new Date() }
      })
      .select('title startDate enrolledStudents')
      .sort('startDate')
      .limit(5);

      // إحصائيات الأداء
      const examResults = await ExamResult.find({
        'exam.teacher': teacherId,
        status: 'completed'
      });

      const averageScore = examResults.reduce(
        (acc, result) => acc + result.score, 0
      ) / (examResults.length || 1);

      const examCompletion = (completedExams / totalExams) * 100;

      // حساب التحسن في الأداء
      const improvements = await calculateImprovements(teacherId);

      res.json({
        totalStudents,
        totalExams,
        completedExams,
        upcomingExams: upcomingExams.map(exam => ({
          _id: exam._id,
          title: exam.title,
          date: exam.startDate,
          studentsCount: exam.enrolledStudents.length
        })),
        performanceStats: {
          averageScore,
          examCompletion,
          improvements
        }
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب إحصائيات لوحة التحكم'
      });
    }
  },

  async getExamPerformance(req: Request, res: Response) {
    try {
      const teacherId = req.user.id;

      const examResults = await ExamResult.aggregate([
        {
          $match: {
            'exam.teacher': teacherId,
            status: 'completed'
          }
        },
        {
          $group: {
            _id: '$exam._id',
            examTitle: { $first: '$exam.title' },
            averageScore: { $avg: '$score' },
            studentCount: { $sum: 1 },
            date: { $first: '$completedAt' }
          }
        },
        {
          $sort: { date: -1 }
        },
        {
          $limit: 10
        }
      ]);

      res.json(examResults);
    } catch (error) {
      console.error('Error fetching exam performance:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب بيانات أداء الاختبارات'
      });
    }
  }
};

async function calculateImprovements(teacherId: string): Promise<number> {
  // حساب نسبة التحسن في الأداء عبر المقارنة بين الاختبارات السابقة والحالية
  const examResults = await ExamResult.find({
    'exam.teacher': teacherId,
    status: 'completed'
  })
  .sort('completedAt');

  if (examResults.length < 2) return 0;

  const previousAvg = examResults
    .slice(0, Math.floor(examResults.length / 2))
    .reduce((acc, result) => acc + result.score, 0) / Math.floor(examResults.length / 2);

  const currentAvg = examResults
    .slice(Math.floor(examResults.length / 2))
    .reduce((acc, result) => acc + result.score, 0) / (examResults.length - Math.floor(examResults.length / 2));

  return ((currentAvg - previousAvg) / previousAvg) * 100;
}