import { Request, Response } from 'express';
import { EducationalStage } from '../models/EducationalStage';
import { Grade } from '../models/Grade';
import { Subject } from '../models/Subject';

export const educationalController = {
  // المراحل التعليمية
  async createStage(req: Request, res: Response) {
    try {
      const { name } = req.body;
      const existingStage = await EducationalStage.findOne({ name });
      
      if (existingStage) {
        return res.status(400).json({
          success: false,
          message: 'المرحلة التعليمية موجودة بالفعل'
        });
      }

      const stage = new EducationalStage({ name });
      await stage.save();

      res.status(201).json(stage);
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء إنشاء المرحلة التعليمية'
      });
    }
  },

  async getStages(req: Request, res: Response) {
    try {
      const stages = await EducationalStage.find().sort('name');
      res.json(stages);
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب المراحل التعليمية'
      });
    }
  },

  // الصفوف الدراسية
  async createGrade(req: Request, res: Response) {
    try {
      const { name } = req.body;
      const existingGrade = await Grade.findOne({ name });
      
      if (existingGrade) {
        return res.status(400).json({
          success: false,
          message: 'الصف الدراسي موجود بالفعل'
        });
      }

      const grade = new Grade({ name });
      await grade.save();

      res.status(201).json(grade);
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء إنشاء الصف الدراسي'
      });
    }
  },

  async getGrades(req: Request, res: Response) {
    try {
      const grades = await Grade.find().sort('name');
      res.json(grades);
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب الصفوف الدراسية'
      });
    }
  },

  // المواد الدراسية
  async createSubject(req: Request, res: Response) {
    try {
      const { nameAr, nameEn, stages } = req.body;
      
      const existingSubject = await Subject.findOne({
        $or: [{ nameAr }, { nameEn }]
      });
      
      if (existingSubject) {
        return res.status(400).json({
          success: false,
          message: 'المادة الدراسية موجودة بالفعل'
        });
      }

      const subject = new Subject({ nameAr, nameEn, stages });
      await subject.save();

      const populatedSubject = await Subject.findById(subject._id)
        .populate('stages', 'name');

      res.status(201).json(populatedSubject);
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء إنشاء المادة الدراسية'
      });
    }
  },

  async getSubjects(req: Request, res: Response) {
    try {
      const subjects = await Subject.find()
        .populate('stages', 'name')
        .sort('nameAr');
      res.json(subjects);
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب المواد الدراسية'
      });
    }
  }
};