import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models/User';
import { config } from '../config';

export const authController = {
  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;

      const user = await User.findOne({ email });
      if (!user) {
        return res.status(401).json({ message: 'بيانات الدخول غير صحيحة' });
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        return res.status(401).json({ message: 'بيانات الدخول غير صحيحة' });
      }

      const token = jwt.sign(
        { id: user._id, role: user.role },
        config.security.jwtSecret,
        { expiresIn: '24h' }
      );

      res.json({
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'حدث خطأ في الخادم' });
    }
  },

  async register(req: Request, res: Response) {
    try {
      const { name, email, password, role } = req.body;

      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ message: 'البريد الإلكتروني مستخدم بالفعل' });
      }

      const user = new User({
        name,
        email,
        password,
        role
      });

      await user.save();

      const token = jwt.sign(
        { id: user._id, role: user.role },
        config.security.jwtSecret,
        { expiresIn: '24h' }
      );

      res.status(201).json({
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'حدث خطأ في الخادم' });
    }
  }
};