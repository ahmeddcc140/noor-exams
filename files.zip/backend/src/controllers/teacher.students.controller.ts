import { Request, Response } from 'express';
import { Student } from '../models/Student';
import { ExamResult } from '../models/ExamResult';
import { Subject } from '../models/Subject';

export const teacherStudentsController = {
  async getStudents(req: Request, res: Response) {
    try {
      const teacherId = req.user.id;

      const students = await Student.find({
        assignedTeacher: teacherId
      }).select('studentCode fullName email grade examResults');

      // حساب الإحصائيات لكل طالب
      const studentsWithStats = await Promise.all(students.map(async (student) => {
        const results = await ExamResult.find({
          student: student._id,
          status: 'completed'
        });

        const averageScore = results.length > 0
          ? results.reduce((acc, result) => acc + result.score, 0) / results.length
          : 0;

        const lastExam = results.length > 0
          ? results.sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime())[0].completedAt
          : undefined;

        return {
          _id: student._id,
          studentCode: student.studentCode,
          fullName: student.fullName,
          email: student.email,
          grade: student.grade,
          averageScore: Math.round(averageScore),
          lastExamDate: lastExam,
          examCount: results.length,
          status: student.status
        };
      }));

      res.json(studentsWithStats);
    } catch (error) {
      console.error('Error fetching students:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب بيانات الطلاب'
      });
    }
  },

  async getStudentStats(req: Request, res: Response) {
    try {
      const { studentId } = req.params;
      const teacherId = req.user.id;

      // التحقق من أن الطالب مسجل مع المعلم
      const student = await Student.findOne({
        _id: studentId,
        assignedTeacher: teacherId
      });

      if (!student) {
        return res.status(404).json({
          success: false,
          message: 'الطالب غير موجود'
        });
      }

      // جلب نتائج الاختبارات مصنفة حسب المواد
      const subjectResults = await ExamResult.aggregate([
        {
          $match: {
            student: student._id,
            status: 'completed'
          }
        },
        {
          $group: {
            _id: '$exam.subject',
            averageScore: { $avg: '$score' },
            count: { $sum: 1 }
          }
        }
      ]);

      // تصنيف المواد القوية والضعيفة
      const subjectsData = await Promise.all(subjectResults.map(async (result) => {
        const subject = await Subject.findById(result._id);
        return {
          subject: subject?.nameAr || '',
          score: Math.round(result.averageScore)
        };
      }));

      const sortedSubjects = subjectsData.sort((a, b) => b.score - a.score);
      const strongSubjects = sortedSubjects.filter(s => s.score >= 70);
      const weakSubjects = sortedSubjects.filter(s => s.score < 70);

      // جلب تاريخ الاختبارات
      const examHistory = await ExamResult.find({
        student: student._id,
        status: 'completed'
      })
      .sort('-completedAt')
      .limit(10)
      .populate('exam', 'title');

      const history = examHistory.map(result => ({
        examId: result.exam._id,
        examTitle: result.exam.title,
        score: result.score,
        date: result.completedAt
      }));

      res.json({
        strongSubjects,
        weakSubjects,
        examHistory: history
      });
    } catch (error) {
      console.error('Error fetching student stats:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب إحصائيات الطالب'
      });
    }
  }
};