import { Request, Response } from 'express';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export const aiController = {
  async analyzeAnswer(req: Request, res: Response) {
    try {
      const { questionType, studentAnswer, correctAnswer, maxScore } = req.body;

      // بناء محتوى الطلب للذكاء الاصطناعي
      const prompt = `
        تحليل إجابة طالب في اختبار تعليمي:
        نوع السؤال: ${questionType}
        الإجابة الصحيحة: ${correctAnswer}
        إجابة الطالب: ${studentAnswer}
        الدرجة القصوى: ${maxScore}

        قم بتحليل إجابة الطالب وتقديم:
        1. درجة مقترحة من ${maxScore}
        2. تعليق عام على الإجابة
        3. النقاط الرئيسية في الإجابة
        4. اقتراحات للتحسين
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "أنت مساعد تعليمي متخصص في تحليل وتقييم إجابات الطلاب."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      });

      // تحليل رد الذكاء الاصطناعي
      const response = completion.choices[0].message.content;
      
      // استخراج المعلومات من الرد
      const analysis = parseAIResponse(response);

      res.json(analysis);
    } catch (error) {
      console.error('Error analyzing answer:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء تحليل الإجابة'
      });
    }
  },

  async generateQuestions(req: Request, res: Response) {
    try {
      const { subject, topic, difficulty, count } = req.body;

      const prompt = `
        توليد ${count} أسئلة تعليمية:
        المادة: ${subject}
        الموضوع: ${topic}
        مستوى الصعوبة: ${difficulty}

        لكل سؤال، قم بتوفير:
        1. نص السؤال
        2. الإجابة الصحيحة
        3. خيارات للأسئلة متعددة الاختيارات
        4. تلميحات للطلاب
        5. تفسير الإجابة
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "أنت مساعد تعليمي متخصص في إنشاء أسئلة تعليمية عالية الجودة."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.8,
        max_tokens: 2000
      });

      const questions = parseGeneratedQuestions(completion.choices[0].message.content);

      res.json(questions);
    } catch (error) {
      console.error('Error generating questions:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء توليد الأسئلة'
      });
    }
  },

  async suggestImprovements(req: Request, res: Response) {
    try {
      const { studentId, examResults, subjects } = req.body;

      const prompt = `
        تحليل أداء الطالب وتقديم اقتراحات للتحسين:
        المواد: ${subjects.join(', ')}
        نتائج الاختبارات: ${JSON.stringify(examResults)}

        قم بتقديم:
        1. تحليل نقاط القوة والضعف
        2. اقتراحات محددة للتحسين في كل مادة
        3. خطة دراسية مقترحة
        4. موارد تعليمية موصى بها
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "أنت مستشار تعليمي متخصص في تحليل أداء الطلاب وتقديم توصيات مخصصة."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1500
      });

      const suggestions = parseSuggestions(completion.choices[0].message.content);

      res.json(suggestions);
    } catch (error) {
      console.error('Error generating suggestions:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء توليد الاقتراحات'
      });
    }
  }
};

// دوال المساعدة لتحليل ردود الذكاء الاصطناعي
function parseAIResponse(response: string): any {
  // تحليل الرد وتنظيمه في كائن منظم
  // يمكن استخدام التعابير النمطية أو تقسيم النص للحصول على المعلومات المطلوبة
  // ...
}

function parseGeneratedQuestions(response: string): any {
  // تحليل الأسئلة المولدة وتنظيمها
  // ...
}

function parseSuggestions(response: string): any {
  // تحليل الاقتراحات وتنظيمها
  // ...
}