import { Request, Response } from 'express';
import { Student } from '../models/Student';
import { Subject } from '../models/Subject';
import { Exam } from '../models/Exam';
import { ExamResult } from '../models/ExamResult';
import { Notification } from '../models/Notification';
import { Achievement } from '../models/Achievement';

export const studentDashboardController = {
  async getDashboardStats(req: Request, res: Response) {
    try {
      const studentId = req.user.id;

      // جلب معلومات الطالب مع المواد المسجل فيها
      const student = await Student.findById(studentId)
        .populate({
          path: 'subjects',
          populate: {
            path: 'teacher',
            select: 'fullName'
          }
        });

      if (!student) {
        return res.status(404).json({
          success: false,
          message: 'الطالب غير موجود'
        });
      }

      // جلب المواد وتقدم الطالب فيها
      const subjects = await Promise.all(student.subjects.map(async (subject) => {
        // حساب آخر درجة في المادة
        const lastResult = await ExamResult.findOne({
          student: studentId,
          subject: subject._id
        }).sort('-createdAt');

        // حساب التقدم في المادة
        const progress = await calculateSubjectProgress(studentId, subject._id);

        // البحث عن الاختبار القادم في المادة
        const nextExam = await Exam.findOne({
          subject: subject._id,
          startDate: { $gt: new Date() },
          status: 'approved'
        }).sort('startDate');

        return {
          id: subject._id,
          name: subject.name,
          teacher: subject.teacher.fullName,
          progress,
          lastGrade: lastResult ? lastResult.score : 0,
          nextExam: nextExam ? {
            date: nextExam.startDate,
            topic: nextExam.title
          } : null
        };
      }));

      // حساب إحصائيات الأداء
      const performance = await calculatePerformanceStats(studentId);

      // جلب الاختبارات القادمة
      const upcomingExams = await getUpcomingExams(studentId);

      // جلب الإشعارات غير المقروءة
      const notifications = await Notification.find({
        recipient: studentId,
        read: false
      })
      .sort('-createdAt')
      .limit(10);

      // جلب الإنجازات
      const achievements = await Achievement.find({
        student: studentId
      }).sort('-date');

      res.json({
        subjects,
        performance,
        upcomingExams,
        notifications: notifications.map(notification => ({
          id: notification._id,
          type: notification.type,
          message: notification.message,
          date: notification.createdAt,
          read: notification.read
        })),
        achievements: achievements.map(achievement => ({
          id: achievement._id,
          title: achievement.title,
          description: achievement.description,
          date: achievement.date,
          icon: achievement.icon
        }))
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب إحصائيات لوحة التحكم'
      });
    }
  },

  async markNotificationAsRead(req: Request, res: Response) {
    try {
      const { notificationId } = req.params;
      
      await Notification.findByIdAndUpdate(notificationId, {
        read: true
      });

      res.json({
        success: true,
        message: 'تم تحديث حالة الإشعار'
      });
    } catch (error) {
      console.error('Error marking notification as read:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء تحديث حالة الإشعار'
      });
    }
  },

  async getAIAssistantResponse(req: Request, res: Response) {
    try {
      const { message, context, conversation } = req.body;
      const studentId = req.user.id;

      // هنا يتم معالجة الرسالة باستخدام نموذج الذكاء الاصطناعي
      // ويمكن استخدام سياق الطالب لتقديم إجابات أكثر تخصيصاً
      
      // مثال بسيط للرد
      const response = await generateAIResponse(message, context, conversation);

      res.json({
        success: true,
        message: response
      });
    } catch (error) {
      console.error('Error getting AI response:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء معالجة طلب المساعد الذكي'
      });
    }
  }
};

// دوال مساعدة

async function calculateSubjectProgress(studentId: string, subjectId: string): Promise<number> {
  // حساب نسبة التقدم في المادة بناءً على الدروس المكتملة والاختبارات
  // ...
  return 75; // مثال
}

async function calculatePerformanceStats(studentId: string) {
  // حساب إحصائيات الأداء العامة للطالب
  // ...
  return {
    overall: 85,
    bySubject: [
      // ...
    ],
    trend: [
      // ...
    ]
  };
}

async function getUpcomingExams(studentId: string) {
  // جلب الاختبارات القادمة للطالب
  // ...
  return [
    // ...
  ];
}

async function generateAIResponse(message: string, context: any, conversation: any[]) {
  // توليد رد من المساعد الذكي
  // يمكن استخدام خدمات مثل OpenAI API
  // ...
  return 'مثال لرد المساعد الذكي';
}