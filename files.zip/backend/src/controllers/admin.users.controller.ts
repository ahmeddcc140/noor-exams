// ... تكملة الكود السابق
      const hashedPassword = await bcrypt.hash(password, 10);

      const user = new User({
        fullName,
        email,
        type,
        password: hashedPassword,
        status: 'active'
      });

      await user.save();

      // إنشاء السجل الخاص حسب نوع المستخدم
      switch (type) {
        case 'student':
          const student = new Student({
            user: user._id,
            grade: additionalData.grade,
            level: additionalData.level
          });
          await student.save();
          break;

        case 'teacher':
          const teacher = new Teacher({
            user: user._id,
            specialization: additionalData.specialization,
            subjects: additionalData.subjects || []
          });
          await teacher.save();
          break;

        case 'parent':
          const parent = new Parent({
            user: user._id,
            children: additionalData.children || []
          });
          await parent.save();
          break;
      }

      // تسجيل النشاط
      await Activity.create({
        type: 'user_creation',
        description: `تم إنشاء مستخدم جديد: ${fullName}`,
        user: req.user.id,
        metadata: { createdUser: user._id }
      });

      res.status(201).json({
        success: true,
        message: 'تم إنشاء المستخدم بنجاح',
        userId: user._id
      });
    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء إنشاء المستخدم'
      });
    }
  },

  async updateUser(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      const updates = req.body;

      // التحقق من وجود المستخدم
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'المستخدم غير موجود'
        });
      }

      // تحديث بيانات المستخدم الأساسية
      if (updates.password) {
        updates.password = await bcrypt.hash(updates.password, 10);
      }

      Object.assign(user, updates);
      await user.save();

      // تحديث البيانات الإضافية حسب نوع المستخدم
      switch (user.type) {
        case 'student':
          await Student.findOneAndUpdate(
            { user: userId },
            { $set: updates },
            { new: true }
          );
          break;

        case 'teacher':
          await Teacher.findOneAndUpdate(
            { user: userId },
            { $set: updates },
            { new: true }
          );
          break;

        case 'parent':
          await Parent.findOneAndUpdate(
            { user: userId },
            { $set: updates },
            { new: true }
          );
          break;
      }

      // تسجيل النشاط
      await Activity.create({
        type: 'user_update',
        description: `تم تحديث بيانات المستخدم: ${user.fullName}`,
        user: req.user.id,
        metadata: { updatedUser: userId }
      });

      res.json({
        success: true,
        message: 'تم تحديث بيانات المستخدم بنجاح'
      });
    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء تحديث بيانات المستخدم'
      });
    }
  },

  async deleteUser(req: Request, res: Response) {
    try {
      const { userId } = req.params;

      // التحقق من وجود المستخدم
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'المستخدم غير موجود'
        });
      }

      // حذف البيانات المرتبطة حسب نوع المستخدم
      switch (user.type) {
        case 'student':
          await Student.findOneAndDelete({ user: userId });
          break;

        case 'teacher':
          await Teacher.findOneAndDelete({ user: userId });
          break;

        case 'parent':
          await Parent.findOneAndDelete({ user: userId });
          break;
      }

      // حذف المستخدم نفسه
      await user.delete();

      // تسجيل النشاط
      await Activity.create({
        type: 'user_deletion',
        description: `تم حذف المستخدم: ${user.fullName}`,
        user: req.user.id,
        metadata: { deletedUser: userId }
      });

      res.json({
        success: true,
        message: 'تم حذف المستخدم بنجاح'
      });
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء حذف المستخدم'
      });
    }
  },

  async updateUserRoles(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      const { roles } = req.body;

      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'المستخدم غير موجود'
        });
      }

      user.roles = roles;
      await user.save();

      await Activity.create({
        type: 'role_update',
        description: `تم تحديث صلاحيات المستخدم: ${user.fullName}`,
        user: req.user.id,
        metadata: { updatedUser: userId, roles }
      });

      res.json({
        success: true,
        message: 'تم تحديث الصلاحيات بنجاح'
      });
    } catch (error) {
      console.error('Error updating user roles:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء تحديث الصلاحيات'
      });
    }
  }
};