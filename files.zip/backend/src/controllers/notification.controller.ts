// ... تكملة الكود السابق
      console.error('Error sending notification:', error);
      return false;
    }
  },

  async deleteNotification(req: Request, res: Response) {
    try {
      const { notificationId } = req.params;
      const userId = req.user.id;

      await Notification.findOneAndDelete({
        _id: notificationId,
        user: userId
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting notification:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء حذف الإشعار'
      });
    }
  }
};