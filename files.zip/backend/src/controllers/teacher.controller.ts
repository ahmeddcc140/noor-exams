import { Request, Response } from 'express';
import { Teacher } from '../models/Teacher';
import { generateTeacherCode, generateTeacherPassword } from '../utils/codeGenerator';
import { hash } from 'bcryptjs';

export const teacherController = {
  async create(req: Request, res: Response) {
    try {
      const {
        fullName,
        phoneNumber,
        email,
        subject,
        educationalLevels
      } = req.body;

      // التحقق من عدم تكرار البريد الإلكتروني
      const existingEmail = await Teacher.findOne({ email });
      if (existingEmail) {
        return res.status(400).json({
          success: false,
          message: 'البريد الإلكتروني مستخدم بالفعل'
        });
      }

      // التحقق من عدم تكرار رقم الهاتف
      const existingPhone = await Teacher.findOne({ phoneNumber });
      if (existingPhone) {
        return res.status(400).json({
          success: false,
          message: 'رقم الهاتف مستخدم بالفعل'
        });
      }

      // توليد كود المعلم وكلمة المرور
      const teacherCode = generateTeacherCode();
      const plainPassword = generateTeacherPassword();
      const hashedPassword = await hash(plainPassword, 10);

      const teacher = new Teacher({
        teacherCode,
        fullName,
        phoneNumber,
        email,
        subject,
        educationalLevels,
        password: hashedPassword
      });

      await teacher.save();

      // إرجاع البيانات مع كود المعلم وكلمة المرور الأصلية
      res.status(201).json({
        success: true,
        message: 'تم إضافة المعلم بنجاح',
        teacherCode,
        password: plainPassword
      });
    } catch (error) {
      console.error('Error creating teacher:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء إضافة المعلم'
      });
    }
  }
};