import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { Parent } from '../models/Parent';
import { Student } from '../models/Student';

export const parentAuthController = {
  async login(req: Request, res: Response) {
    try {
      const { parentCode } = req.body;

      // البحث عن ولي الأمر باستخدام الكود فقط
      const parent = await Parent.findOne({ parentCode });

      if (!parent) {
        return res.status(401).json({
          success: false,
          message: 'الكود غير صحيح، يرجى التأكد من الكود وإعادة المحاولة'
        });
      }

      // جلب قائمة الطلاب المرتبطين بولي الأمر
      const students = await Student.find({ parent: parent._id })
        .select('_id fullName grade level');

      // إنشاء توكن التصريح
      const token = jwt.sign(
        {
          id: parent._id,
          type: 'parent',
          students: students.map(s => s._id) // تضمين قائمة معرفات الطلاب في التوكن
        },
        process.env.JWT_SECRET!,
        { expiresIn: '30d' }
      );

      // تحديث آخر تسجيل دخول
      parent.lastLogin = new Date();
      // تسجيل تاريخ تسجيل الدخول
      parent.loginHistory.push({
        date: new Date(),
        success: true,
        ipAddress: req.ip
      });
      await parent.save();

      res.json({
        success: true,
        token,
        parentId: parent._id,
        students: students.map(student => ({
          id: student._id,
          name: student.fullName,
          grade: student.grade,
          level: student.level
        }))
      });
    } catch (error) {
      console.error('Error in parent login:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء تسجيل الدخول'
      });
    }
  },

  async validateToken(req: Request, res: Response) {
    try {
      // التحقق من صلاحية التوكن (يتم استدعاؤها تلقائياً عند تحميل التطبيق)
      const token = req.headers.authorization?.split(' ')[1];
      
      if (!token) {
        return res.status(401).json({
          success: false,
          message: 'غير مصرح بالدخول'
        });
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
      
      if (decoded.type !== 'parent') {
        return res.status(403).json({
          success: false,
          message: 'نوع المستخدم غير صحيح'
        });
      }

      const parent = await Parent.findById(decoded.id);
      
      if (!parent) {
        return res.status(401).json({
          success: false,
          message: 'المستخدم غير موجود'
        });
      }

      res.json({
        success: true,
        parentId: parent._id
      });
    } catch (error) {
      res.status(401).json({
        success: false,
        message: 'جلسة غير صالحة'
      });
    }
  }
};