import { Request, Response } from 'express';
import { Student } from '../models/Student';
import { Teacher } from '../models/Teacher';
import { Exam } from '../models/Exam';
import { ExamResult } from '../models/ExamResult';
import { Activity } from '../models/Activity';

export const adminDashboardController = {
  async getStats(req: Request, res: Response) {
    try {
      const { range = 'week' } = req.query;

      // حساب تاريخ البداية بناءً على النطاق المحدد
      const startDate = new Date();
      if (range === 'week') {
        startDate.setDate(startDate.getDate() - 7);
      } else if (range === 'month') {
        startDate.setMonth(startDate.getMonth() - 1);
      } else if (range === 'year') {
        startDate.setFullYear(startDate.getFullYear() - 1);
      }

      // إحصائيات الطلاب
      const totalStudents = await Student.countDocuments();
      const activeStudents = await Student.countDocuments({ status: 'active' });
      const newStudents = await Student.countDocuments({
        createdAt: { $gte: startDate }
      });

      // إحصائيات المعلمين
      const totalTeachers = await Teacher.countDocuments();
      const activeTeachers = await Teacher.countDocuments({ status: 'active' });

      // إحصائيات الاختبارات
      const totalExams = await Exam.countDocuments();
      const completedExams = await Exam.countDocuments({ status: 'completed' });
      const pendingExams = await Exam.countDocuments({ status: 'pending' });

      // حساب نسب النجاح والرسوب
      const examResults = await ExamResult.find({
        createdAt: { $gte: startDate }
      });

      const passCount = examResults.filter(result => result.score >= 60).length;
      const totalCount = examResults.length;
      const passRate = totalCount > 0 ? (passCount / totalCount) * 100 : 0;
      const averageScore = totalCount > 0 
        ? examResults.reduce((acc, curr) => acc + curr.score, 0) / totalCount
        : 0;

      // النشاطات الأخيرة
      const recentActivities = await Activity.find()
        .sort('-timestamp')
        .limit(10)
        .populate('user', 'fullName');

      res.json({
        students: {
          total: totalStudents,
          active: activeStudents,
          new: newStudents
        },
        teachers: {
          total: totalTeachers,
          active: activeTeachers
        },
        exams: {
          total: totalExams,
          completed: completedExams,
          pending: pendingExams
        },
        performance: {
          passRate: Math.round(passRate),
          failRate: Math.round(100 - passRate),
          averageScore: Math.round(averageScore)
        },
        activities: recentActivities.map(activity => ({
          id: activity._id,
          type: activity.type,
          description: activity.description,
          user: activity.user.fullName,
          timestamp: activity.timestamp
        }))
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب إحصائيات لوحة التحكم'
      });
    }
  }
};