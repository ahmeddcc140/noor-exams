import { Request, Response } from 'express';
import { Exam } from '../models/Exam';
import { Question } from '../models/Question';
import { ExamResult } from '../models/ExamResult';
import { Teacher } from '../models/Teacher';
import { Activity } from '../models/Activity';
import { Notification } from '../models/Notification';

export const adminExamsController = {
  async getExams(req: Request, res: Response) {
    try {
      const { status, subject, grade, dateRange } = req.query;

      // بناء شروط البحث
      let query: any = {};

      if (status) {
        query.status = status;
      }

      if (subject) {
        query.subject = subject;
      }

      if (grade) {
        query.grade = grade;
      }

      if (dateRange) {
        const now = new Date();
        switch (dateRange) {
          case 'today':
            query.createdAt = {
              $gte: new Date(now.setHours(0, 0, 0, 0)),
              $lt: new Date(now.setHours(23, 59, 59, 999))
            };
            break;
          case 'week':
            query.createdAt = {
              $gte: new Date(now.setDate(now.getDate() - 7))
            };
            break;
          case 'month':
            query.createdAt = {
              $gte: new Date(now.setMonth(now.getMonth() - 1))
            };
            break;
        }
      }

      // جلب الاختبارات مع البيانات المرتبطة
      const exams = await Exam.find(query)
        .populate('teacher', 'fullName')
        .sort('-createdAt');

      // حساب الإحصائيات لكل اختبار
      const examStats = await Promise.all(exams.map(async (exam) => {
        const results = await ExamResult.find({ exam: exam._id });
        const submissionsCount = results.length;
        const totalScore = results.reduce((acc, curr) => acc + curr.score, 0);
        const averageScore = submissionsCount > 0 ? totalScore / submissionsCount : 0;

        return {
          id: exam._id,
          title: exam.title,
          subject: exam.subject,
          grade: exam.grade,
          teacher: {
            id: exam.teacher._id,
            name: exam.teacher.fullName
          },
          status: exam.status,
          startDate: exam.startDate,
          duration: exam.duration,
          questionsCount: exam.questions.length,
          submissionsCount,
          averageScore: Math.round(averageScore),
          createdAt: exam.createdAt
        };
      }));

      res.json(examStats);
    } catch (error) {
      console.error('Error fetching exams:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب بيانات الاختبارات'
      });
    }
  },

  async getExamQuestions(req: Request, res: Response) {
    try {
      const { examId } = req.params;

      const exam = await Exam.findById(examId)
        .populate('questions');

      if (!exam) {
        return res.status(404).json({
          success: false,
          message: 'الاختبار غير موجود'
        });
      }

      res.json(exam.questions);
    } catch (error) {
      console.error('Error fetching exam questions:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب أسئلة الاختبار'
      });
    }
  },

  async approveExam(req: Request, res: Response) {
    try {
      const { examId } = req.params;

      const exam = await Exam.findById(examId)
        .populate('teacher');

      if (!exam) {
        return res.status(404).json({
          success: false,
          message: 'الاختبار غير موجود'
        });
      }

      exam.status = 'approved';
      await exam.save();

      // إنشاء نشاط
      await Activity.create({
        type: 'exam_approval',
        description: `تم اعتماد الاختبار: ${exam.title}`,
        user: req.user.id,
        metadata: { examId }
      });

      // إرسال إشعار للمعلم
      await Notification.create({
        recipient: exam.teacher._id,
        title: 'تم اعتماد الاختبار',
        message: `تم اعتماد اختبار ${exam.title} من قبل الإدارة`,
        type: 'exam_approval'
      });

      res.json({
        success: true,
        message: 'تم اعتماد الاختبار بنجاح'
      });
    } catch (error) {
      console.error('Error approving exam:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء اعتماد الاختبار'
      });
    }
  },

  async rejectExam(req: Request, res: Response) {
    try {
      const { examId } = req.params;
      const { reason } = req.body;

      const exam = await Exam.findById(examId)
        .populate('teacher');

      if (!exam) {
        return res.status(404).json({
          success: false,
          message: 'الاختبار غير موجود'
        });
      }

      exam.status = 'rejected';
      exam.rejectionReason = reason;
      await exam.save();

      // إنشاء نشاط
      await Activity.create({
        type: 'exam_rejection',
        description: `تم رفض الاختبار: ${exam.title}`,
        user: req.user.id,
        metadata: { examId, reason }
      });

      // إرسال إشعار للمعلم
      await Notification.create({
        recipient: exam.teacher._id,
        title: 'تم رفض الاختبار',
        message: `تم رفض اختبار ${exam.title}. السبب: ${reason}`,
        type: 'exam_rejection'
      });

      res.json({
        success: true,
        message: 'تم رفض الاختبار وإرسال السبب للمعلم'
      });
    } catch (error) {
      console.error('Error rejecting exam:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء رفض الاختبار'
      });
    }
  },

  async deleteExam(req: Request, res: Response) {
    try {
      const { examId } = req.params;

      const exam = await Exam.findById(examId);

      if (!exam) {
        return res.status(404).json({
          success: false,
          message: 'الاختبار غير موجود'
        });
      }

      // حذف النتائج المرتبطة
      await ExamResult.deleteMany({ exam: examId });

      // حذف الأسئلة المرتبطة
      await Question.deleteMany({ _id: { $in: exam.questions } });

      // حذف الاختبار
      await exam.delete();

      // إنشاء نشاط
      await Activity.create({
        type: 'exam_deletion',
        description: `تم حذف الاختبار: ${exam.title}`,
        user: req.user.id,
        metadata: { examId }
      });

      res.json({
        success: true,
        message: 'تم حذف الاختبار وجميع البيانات المرتبطة به'
      });
    } catch (error) {
      console.error('Error deleting exam:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء حذف الاختبار'
      });
    }
  },

  async getExamStatistics(req: Request, res: Response) {
    try {
      const { examId } = req.params;

      const exam = await Exam.findById(examId)
        .populate('questions');

      if (!exam) {
        return res.status(404).json({
          success: false,
          message: 'الاختبار غير موجود'
        });
      }

      const results = await ExamResult.find({ exam: examId });

      // حساب الإحصائيات العامة
      const submissionsCount = results.length;
      const totalScore = results.reduce((acc, curr) => acc + curr.score, 0);
      const averageScore = submissionsCount > 0 ? totalScore / submissionsCount : 0;
      const passCount = results.filter(r => r.score >= 60).length;
      const passRate = submissionsCount > 0 ? (passCount / submissionsCount) * 100 : 0;

      // حساب توزيع التقديرات
      const gradeDistribution = {
        excellent: results.filter(r => r.score >= 90).length,
        veryGood: results.filter(r => r.score >= 80 && r.score < 90).length,
        good: results.filter(r => r.score >= 70 && r.score < 80).length,
        pass: results.filter(r => r.score >= 60 && r.score < 70).length,
        fail: results.filter(r => r.score < 60).length
      };

      // حساب إحصائيات الأسئلة
      const questionStats = await Promise.all(exam.questions.map(async (question) => {
        const correctAnswers = results.filter(r => 
          r.answers.find(a => 
            a.questionId.toString() === question._id.toString() && a.isCorrect
          )
        ).length;

        const totalTime = results.reduce((acc, r) => {
          const answer = r.answers.find(a => 
            a.questionId.toString() === question._id.toString()
          );
          return acc + (answer?.timeSpent || 0);
        }, 0);

        return {
          questionId: question._id,
          correctAnswersRate: submissionsCount > 0 ? 
            (correctAnswers / submissionsCount) * 100 : 0,
          averageTime: submissionsCount > 0 ? 
            totalTime / submissionsCount : 0
        };
      }));

      res.json({
        submissionsCount,
        averageScore: Math.round(averageScore),
        passRate: Math.round(passRate),
        gradeDistribution,
        questionStats,
        timeDistribution: calculateTimeDistribution(results)
      });
    } catch (error) {
      console.error('Error fetching exam statistics:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء جلب إحصائيات الاختبار'
      });
    }
  }
};

// دالة مساعدة لحساب توزيع الوقت
function calculateTimeDistribution(results: any[]) {
  // تقسيم الوقت إلى فترات وحساب عدد الطلاب في كل فترة
  // ...
  return [];
}