import { Request, Response } from 'express';
import { Student } from '../models/Student';
import { hash } from 'bcryptjs';

export const studentController = {
  async register(req: Request, res: Response) {
    try {
      const {
        fullName,
        email,
        studentPhone,
        parentPhone,
        educationalLevel,
        grade,
        password
      } = req.body;

      // التحقق من عدم تكرار البريد الإلكتروني
      const existingEmail = await Student.findOne({ email });
      if (existingEmail) {
        return res.status(400).json({
          success: false,
          message: 'البريد الإلكتروني مستخدم بالفعل'
        });
      }

      // التحقق من عدم تكرار رقم هاتف الطالب
      const existingStudentPhone = await Student.findOne({ studentPhone });
      if (existingStudentPhone) {
        return res.status(400).json({
          success: false,
          message: 'رقم هاتف الطالب مستخدم بالفعل'
        });
      }

      // تشفير كلمة المرور
      const hashedPassword = await hash(password, 10);

      // إنشاء الطالب الجديد
      const student = new Student({
        fullName,
        email,
        studentPhone,
        parentPhone,
        educationalLevel,
        grade,
        password: hashedPassword
      });

      await student.save();

      // إرجاع البيانات بدون كلمة المرور
      const { password: _, ...studentData } = student.toObject();

      res.status(201).json({
        success: true,
        message: 'تم تسجيل الطالب بنجاح',
        data: studentData
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء تسجيل الطالب',
        error: error.message
      });
    }
  }
};