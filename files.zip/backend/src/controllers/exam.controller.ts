import { Request, Response } from 'express';
import { Exam } from '../models/Exam';
import { User } from '../models/User';

export const examController = {
  async createExam(req: Request, res: Response) {
    try {
      const examData = {
        ...req.body,
        creator: req.user.id,
        accessCode: Math.random().toString(36).substring(2, 8).toUpperCase()
      };

      const exam = new Exam(examData);
      await exam.save();

      res.status(201).json(exam);
    } catch (error) {
      res.status(500).json({ message: 'حدث خطأ في إنشاء الاختبار' });
    }
  },

  async getExams(req: Request, res: Response) {
    try {
      const { role, id } = req.user;
      let exams;

      if (role === 'teacher') {
        exams = await Exam.find({ creator: id });
      } else if (role === 'student') {
        exams = await Exam.find({
          isPublished: true,
          startDate: { $lte: new Date() },
          endDate: { $gte: new Date() }
        });
      } else {
        exams = await Exam.find();
      }

      res.json(exams);
    } catch (error) {
      res.status(500).json({ message: 'حدث خطأ في جلب الاختبارات' });
    }
  },

  async getExam(req: Request, res: Response) {
    try {
      const exam = await Exam.findById(req.params.id);
      if (!exam) {
        return res.status(404).json({ message: 'الاختبار غير موجود' });
      }
      res.json(exam);
    } catch (error) {
      res.status(500).json({ message: 'حدث خطأ في جلب الاختبار' });
    }
  }
};