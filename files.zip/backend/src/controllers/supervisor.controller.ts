import { Request, Response } from 'express';
import { Supervisor } from '../models/Supervisor';
import { generateSupervisorCode, generateSupervisorPassword } from '../utils/codeGenerator';
import { hash } from 'bcryptjs';

export const supervisorController = {
  async create(req: Request, res: Response) {
    try {
      const {
        fullName,
        phoneNumber,
        email
      } = req.body;

      // التحقق من عدم تكرار البريد الإلكتروني
      const existingEmail = await Supervisor.findOne({ email });
      if (existingEmail) {
        return res.status(400).json({
          success: false,
          message: 'البريد الإلكتروني مستخدم بالفعل'
        });
      }

      // التحقق من عدم تكرار رقم الهاتف
      const existingPhone = await Supervisor.findOne({ phoneNumber });
      if (existingPhone) {
        return res.status(400).json({
          success: false,
          message: 'رقم الهاتف مستخدم بالفعل'
        });
      }

      // توليد كود المشرف وكلمة المرور
      const supervisorCode = generateSupervisorCode();
      const plainPassword = generateSupervisorPassword();
      const hashedPassword = await hash(plainPassword, 10);

      const supervisor = new Supervisor({
        supervisorCode,
        fullName,
        phoneNumber,
        email,
        password: hashedPassword
      });

      await supervisor.save();

      // إرجاع البيانات مع كود المشرف وكلمة المرور الأصلية
      res.status(201).json({
        success: true,
        message: 'تم إضافة المشرف بنجاح',
        supervisorCode,
        password: plainPassword
      });
    } catch (error) {
      console.error('Error creating supervisor:', error);
      res.status(500).json({
        success: false,
        message: 'حدث خطأ أثناء إضافة المشرف'
      });
    }
  }
};