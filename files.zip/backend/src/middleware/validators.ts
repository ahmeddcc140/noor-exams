import { body } from 'express-validator';

export const validateEducational = {
  stage: [
    body('name')
      .notEmpty()
      .withMessage('اسم المرحلة التعليمية مطلوب')
      .trim()
  ],

  grade: [
    body('name')
      .notEmpty()
      .withMessage('اسم الصف الدراسي مطلوب')
      .trim()
  ],

  subject: [
    body('nameAr')
      .notEmpty()
      .withMessage('اسم المادة بالعربية مطلوب')
      .trim(),
    
    body('nameEn')
      .notEmpty()
      .withMessage('اسم المادة بالإنجليزية مطلوب')
      .trim(),
    
    body('stages')
      .isArray()
      .withMessage('يجب اختيار مرحلة تعليمية واحدة على الأقل')
      .notEmpty()
      .withMessage('يجب اختيار مرحلة تعليمية واحدة على الأقل')
  ]
};