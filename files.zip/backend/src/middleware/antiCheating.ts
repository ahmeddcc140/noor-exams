import { Request, Response, NextFunction } from 'express';
import { createHash } from 'crypto';

interface CheatDetectionData {
  userId: string;
  examId: string;
  timestamp: number;
  browserData: any;
  screenChanges: number;
  tabSwitches: number;
  keyboardEvents: any[];
  mouseEvents: any[];
}

class AntiCheatingSystem {
  private static instance: AntiCheatingSystem;
  private suspiciousActivities: Map<string, CheatDetectionData[]>;

  private constructor() {
    this.suspiciousActivities = new Map();
  }

  static getInstance() {
    if (!AntiCheatingSystem.instance) {
      AntiCheatingSystem.instance = new AntiCheatingSystem();
    }
    return AntiCheatingSystem.instance;
  }

  public analyzeBehavior(data: CheatDetectionData): boolean {
    const suspicious = this.detectSuspiciousActivity(data);
    if (suspicious) {
      this.logSuspiciousActivity(data);
    }
    return suspicious;
  }

  private detectSuspiciousActivity(data: CheatDetectionData): boolean {
    // التحقق من تبديل النوافذ المتكرر
    if (data.tabSwitches > 3) return true;

    // التحقق من تغييرات الشاشة المتكررة
    if (data.screenChanges > 5) return true;

    // التحقق من أنماط لصق النصوص
    const pasteEvents = data.keyboardEvents.filter(e => e.type === 'paste');
    if (pasteEvents.length > 2) return true;

    return false;
  }

  private logSuspiciousActivity(data: CheatDetectionData) {
    const key = `${data.userId}-${data.examId}`;
    if (!this.suspiciousActivities.has(key)) {
      this.suspiciousActivities.set(key, []);
    }
    this.suspiciousActivities.get(key)?.push(data);
  }
}

export const antiCheatingMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const antiCheating = AntiCheatingSystem.getInstance();
  
  // التحقق من نشاط المستخدم
  const cheatData: CheatDetectionData = {
    userId: req.user.id,
    examId: req.params.examId,
    timestamp: Date.now(),
    browserData: req.headers['user-agent'],
    screenChanges: parseInt(req.body.screenChanges || '0'),
    tabSwitches: parseInt(req.body.tabSwitches || '0'),
    keyboardEvents: req.body.keyboardEvents || [],
    mouseEvents: req.body.mouseEvents || []
  };

  if (antiCheating.analyzeBehavior(cheatData)) {
    return res.status(403).json({
      message: 'تم اكتشاف نشاط مشبوه. سيتم إبلاغ المعلم.',
      warning: true
    });
  }

  next();
};