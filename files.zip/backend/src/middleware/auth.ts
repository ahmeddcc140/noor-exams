import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export const authMiddleware = (allowedTypes: string[]) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const token = req.headers.authorization?.split(' ')[1];

      if (!token) {
        return res.status(401).json({
          success: false,
          message: 'غير مصرح بالدخول'
        });
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;

      if (!allowedTypes.includes(decoded.type)) {
        return res.status(403).json({
          success: false,
          message: 'ليس لديك صلاحية الوصول'
        });
      }

      req.user = decoded;
      next();
    } catch (error) {
      console.error('Auth middleware error:', error);
      res.status(401).json({
        success: false,
        message: 'غير مصرح بالدخول'
      });
    }
  };
};