import { Router } from 'express';
import { studentController } from '../controllers/student.controller';
import { validateStudentRegistration } from '../middleware/validators';

const router = Router();

router.post('/register', validateStudentRegistration, studentController.register);

export default router;