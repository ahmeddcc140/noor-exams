import { Router } from 'express';
import { supervisorController } from '../controllers/supervisor.controller';
import { validateSupervisorCreation } from '../middleware/validators';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.post(
  '/supervisors',
  authMiddleware(['admin']),
  validateSupervisorCreation,
  supervisorController.create
);

export default router;