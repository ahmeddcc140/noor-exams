import { Router } from 'express';
import { parentAuthController } from '../controllers/parent.auth.controller';
import { parentReportController } from '../controllers/parent.report.controller';
import { authMiddleware } from '../middleware/auth';

const router = Router();

// مسارات المصادقة
router.post('/login', parentAuthController.login);

// مسارات التقارير (محمية)
router.get(
  '/report/:studentId',
  authMiddleware(['parent']),
  parentReportController.getReport
);

router.get(
  '/report/:studentId/pdf',
  authMiddleware(['parent']),
  parentReportController.downloadPDF
);

router.get(
  '/report/:studentId/excel',
  authMiddleware(['parent']),
  parentReportController.downloadExcel
);

export default router;