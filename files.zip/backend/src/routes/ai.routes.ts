import { Router } from 'express';
import { aiController } from '../controllers/ai.controller';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.post(
  '/analyze-answer',
  authMiddleware(['teacher']),
  aiController.analyzeAnswer
);

router.post(
  '/generate-questions',
  authMiddleware(['teacher']),
  aiController.generateQuestions
);

router.post(
  '/suggest-improvements',
  authMiddleware(['teacher']),
  aiController.suggestImprovements
);

export default router;