import { Router } from 'express';
import { adminExamsController } from '../controllers/admin.exams.controller';
import { authMiddleware } from '../middleware/auth';
import { roleMiddleware } from '../middleware/role';

const router = Router();

// تطبيق middleware المصادقة والصلاحيات
router.use(authMiddleware);
router.use(roleMiddleware(['admin', 'supervisor']));

// مسارات إدارة الاختبارات
router.get('/exams', adminExamsController.getExams);
router.get('/exams/:examId/questions', adminExamsController.getExamQuestions);
router.get('/exams/:examId/statistics', adminExamsController.getExamStatistics);
router.post('/exams/:examId/approve', adminExamsController.approveExam);
router.post('/exams/:examId/reject', adminExamsController.rejectExam);
router.delete('/exams/:examId', adminExamsController.deleteExam);

export default router;