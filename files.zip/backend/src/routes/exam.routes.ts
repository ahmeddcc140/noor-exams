import { Router } from 'express';
import { examController } from '../controllers/exam.controller';
import { auth } from '../middleware/auth';
import { validateExam } from '../middleware/validators';

const router = Router();

router.post('/', auth(['teacher']), validateExam, examController.createExam);
router.get('/', auth(['teacher', 'student']), examController.getExams);
router.get('/:id', auth(['teacher', 'student']), examController.getExam);

export default router;