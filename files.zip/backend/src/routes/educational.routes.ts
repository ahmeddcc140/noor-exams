import { Router } from 'express';
import { educationalController } from '../controllers/educational.controller';
import { authMiddleware } from '../middleware/auth';
import { validateEducational } from '../middleware/validators';

const router = Router();

// المراحل التعليمية
router.post(
  '/educational-stages',
  authMiddleware(['admin']),
  validateEducational.stage,
  educationalController.createStage
);
router.get('/educational-stages', educationalController.getStages);

// الصفوف الدراسية
router.post(
  '/grades',
  authMiddleware(['admin']),
  validateEducational.grade,
  educationalController.createGrade
);
router.get('/grades', educationalController.getGrades);

// المواد الدراسية
router.post(
  '/subjects',
  authMiddleware(['admin']),
  validateEducational.subject,
  educationalController.createSubject
);
router.get('/subjects', educationalController.getSubjects);

export default router;