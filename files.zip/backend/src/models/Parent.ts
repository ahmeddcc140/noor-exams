import mongoose from 'mongoose';

const parentSchema = new mongoose.Schema({
  parentCode: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  fullName: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    required: true
  },
  email: String,
  lastLogin: Date,
  loginHistory: [{
    date: Date,
    success: Boolean,
    ipAddress: String
  }],
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// دالة لتوليد كود ولي الأمر تلقائياً
parentSchema.pre('save', async function(next) {
  if (this.isNew) {
    // توليد كود فريد مكون من 8 أرقام
    let uniqueCode;
    let isUnique = false;
    
    while (!isUnique) {
      uniqueCode = Math.floor(10000000 + Math.random() * 90000000).toString();
      const existingParent = await mongoose.models.Parent.findOne({ parentCode: uniqueCode });
      if (!existingParent) {
        isUnique = true;
      }
    }
    
    this.parentCode = uniqueCode;
  }
  next();
});

export const Parent = mongoose.model('Parent', parentSchema);