import mongoose, { Schema, Document } from 'mongoose';

export interface IExam extends Document {
  title: string;
  description?: string;
  subject: string;
  grade: string;
  teacher: mongoose.Types.ObjectId;
  questions: mongoose.Types.ObjectId[];
  duration: number;
  totalPoints: number;
  passScore: number;
  startDate: Date;
  endDate: Date;
  status: 'draft' | 'pending' | 'approved' | 'rejected' | 'active' | 'completed';
  rejectionReason?: string;
  settings: {
    shuffleQuestions: boolean;
    showResults: boolean;
    allowReview: boolean;
    timePerQuestion?: number;
  };
  metadata: {
    createdAt: Date;
    updatedAt: Date;
    lastModifiedBy: mongoose.Types.ObjectId;
  };
}

const examSchema = new Schema<IExam>({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  subject: {
    type: String,
    required: true
  },
  grade: {
    type: String,
    required: true
  },
  teacher: {
    type: Schema.Types.ObjectId,
    ref: 'Teacher',
    required: true
  },
  questions: [{
    type: Schema.Types.ObjectId,
    ref: 'Question'
  }],
  duration: {
    type: Number,
    required: true,
    min: 1
  },
  totalPoints: {
    type: Number,
    required: true,
    min: 0
  },
  passScore: {
    type: Number,
    required: true,
    min: 0
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['draft', 'pending', 'approved', 'rejected', 'active', 'completed'],
    default: 'draft'
  },
  rejectionReason: {
    type: String
  },
  settings: {
    shuffleQuestions: {
      type: Boolean,
      default: true
    },
    showResults: {
      type: Boolean,
      default: true
    },
    allowReview: {
      type: Boolean,
      default: false
    },
    timePerQuestion: {
      type: Number
    }
  },
  metadata: {
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    },
    lastModifiedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true
    }
  }
});

// Middleware قبل الحفظ
examSchema.pre('save', function(next) {
  this.metadata.updatedAt = new Date();
  next();
});

// Middleware بعد التحديث
examSchema.post('save', async function(doc) {
  // تحديث حالة الاختبار تلقائياً بناءً على التواريخ
  const now = new Date();
  if (doc.status === 'approved') {
    if (now >= doc.startDate && now <= doc.endDate) {
      doc.status = 'active';
    } else if (now > doc.endDate) {
      doc.status = 'completed';
    }
    await doc.save();
  }
});

export const Exam = mongoose.model<IExam>('Exam', examSchema);