// ... تكملة للكود السابق
  password: {
    type: String,
    required: true,
    validate: {
      validator: function(v: string) {
        return /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/.test(v);
      },
      message: 'كلمة المرور يجب أن تحتوي على 8 أحرف وتتضمن أحرفاً وأرقاماً ورموزاً'
    }
  }
}, {
  timestamps: true
});