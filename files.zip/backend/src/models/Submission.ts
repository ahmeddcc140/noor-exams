import mongoose, { Document } from 'mongoose';

export interface ISubmission extends Document {
  exam: mongoose.Types.ObjectId;
  student: mongoose.Types.ObjectId;
  answers: Array<{
    question: mongoose.Types.ObjectId;
    answer: string;
    score?: number;
  }>;
  totalScore: number;
  startTime: Date;
  endTime: Date;
  status: 'in-progress' | 'completed' | 'graded';
}

const submissionSchema = new mongoose.Schema({
  exam: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Exam',
    required: true
  },
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  answers: [{
    question: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    answer: String,
    score: Number
  }],
  totalScore: {
    type: Number,
    default: 0
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: Date,
  status: {
    type: String,
    enum: ['in-progress', 'completed', 'graded'],
    default: 'in-progress'
  }
}, {
  timestamps: true
});

export const Submission = mongoose.model<ISubmission>('Submission', submissionSchema);