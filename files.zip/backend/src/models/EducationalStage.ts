import mongoose, { Document, Schema } from 'mongoose';
import { generateStageCode } from '../utils/codeGenerator';

interface IEducationalStage extends Document {
  stageCode: string;
  name: string;
}

const educationalStageSchema = new Schema({
  stageCode: {
    type: String,
    unique: true,
    required: true,
    default: generateStageCode // سيولد كود مثل "EDU123"
  },
  name: {
    type: String,
    required: true,
    unique: true
  }
}, {
  timestamps: true
});

export const EducationalStage = mongoose.model<IEducationalStage>('EducationalStage', educationalStageSchema);