import mongoose, { Document, Schema } from 'mongoose';
import { generateGradeCode } from '../utils/codeGenerator';

interface IGrade extends Document {
  gradeCode: string;
  name: string;
}

const gradeSchema = new Schema({
  gradeCode: {
    type: String,
    unique: true,
    required: true,
    default: generateGradeCode // سيولد كود مثل "GRAD12"
  },
  name: {
    type: String,
    required: true,
    unique: true
  }
}, {
  timestamps: true
});

export const Grade = mongoose.model<IGrade>('Grade', gradeSchema);