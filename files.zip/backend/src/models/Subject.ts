import mongoose, { Document, Schema } from 'mongoose';
import { generateSubjectCode } from '../utils/codeGenerator';

interface ISubject extends Document {
  subjectCode: string;
  nameAr: string;
  nameEn: string;
  stages: mongoose.Types.ObjectId[];
}

const subjectSchema = new Schema({
  subjectCode: {
    type: String,
    unique: true,
    required: true,
    default: generateSubjectCode // سيولد كود مثل "SUBJ123"
  },
  nameAr: {
    type: String,
    required: true,
    unique: true
  },
  nameEn: {
    type: String,
    required: true,
    unique: true
  },
  stages: [{
    type: Schema.Types.ObjectId,
    ref: 'EducationalStage'
  }]
}, {
  timestamps: true
});

export const Subject = mongoose.model<ISubject>('Subject', subjectSchema);