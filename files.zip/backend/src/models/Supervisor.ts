import mongoose, { Document, Schema } from 'mongoose';
import { generateSupervisorCode, generateSupervisorPassword } from '../utils/codeGenerator';

interface ISupervisor extends Document {
  supervisorCode: string;
  fullName: string;
  phoneNumber: string;
  email: string;
  password: string;
  createdAt: Date;
  updatedAt: Date;
}

const supervisorSchema = new Schema({
  supervisorCode: {
    type: String,
    unique: true,
    required: true,
    default: generateSupervisorCode
  },
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  phoneNumber: {
    type: String,
    required: true,
    unique: true,
    validate: {
      validator: (v: string) => /^[0-9]{11,}$/.test(v),
      message: 'رقم الهاتف يجب أن يتكون من 11 رقم على الأقل'
    }
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
    validate: {
      validator: (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
      message: 'البريد الإلكتروني غير صالح'
    }
  },
  password: {
    type: String,
    required: true,
    default: generateSupervisorPassword
  }
}, {
  timestamps: true
});

export const Supervisor = mongoose.model<ISupervisor>('Supervisor', supervisorSchema);