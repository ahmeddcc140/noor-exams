import mongoose, { Schema, Document } from 'mongoose';

export interface IQuestion extends Document {
  type: 'mcq' | 'essay' | 'true_false';
  text: string;
  options?: string[];
  correctAnswer: string;
  points: number;
  difficulty: 'easy' | 'medium' | 'hard';
  subject: string;
  topic: string;
  metadata: {
    author: mongoose.Types.ObjectId;
    createdAt: Date;
    updatedAt: Date;
    usageCount: number;
    averageScore: number;
  };
}

const questionSchema = new Schema<IQuestion>({
  type: {
    type: String,
    enum: ['mcq', 'essay', 'true_false'],
    required: true
  },
  text: {
    type: String,
    required: true,
    trim: true
  },
  options: [{
    type: String,
    trim: true
  }],
  correctAnswer: {
    type: String,
    required: true
  },
  points: {
    type: Number,
    required: true,
    min: 0
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    required: true
  },
  subject: {
    type: String,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  metadata: {
    author: {
      type: Schema.Types.ObjectId,
      ref: 'Teacher',
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    },
    usageCount: {
      type: Number,
      default: 0
    },
    averageScore: {
      type: Number,
      default: 0
    }
  }
});

// التحقق من صحة البيانات
questionSchema.pre('save', function(next) {
  // التحقق من وجود خيارات للأسئلة متعددة الاختيارات
  if (this.type === 'mcq' && (!this.options || this.options.length < 2)) {
    throw new Error('يجب توفير خيارات للسؤال متعدد الاختيارات');
  }

  // التحقق من صحة الإجابة الصحيحة للأسئلة الصح والخطأ
  if (this.type === 'true_false' && !['true', 'false'].includes(this.correctAnswer)) {
    throw new Error('الإجابة الصحيحة للسؤال الصح والخطأ يجب أن تكون true أو false');
  }

  this.metadata.updatedAt = new Date();
  next();
});

export const Question = mongoose.model<IQuestion>('Question', questionSchema);