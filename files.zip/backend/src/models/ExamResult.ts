import mongoose, { Schema, Document } from 'mongoose';

export interface IExamResult extends Document {
  exam: mongoose.Types.ObjectId;
  student: mongoose.Types.ObjectId;
  startTime: Date;
  endTime: Date;
  score: number;
  answers: {
    questionId: mongoose.Types.ObjectId;
    answer: string;
    isCorrect: boolean;
    timeSpent: number;
    points: number;
  }[];
  metadata: {
    device: string;
    ipAddress: string;
    browser: string;
  };
}

const examResultSchema = new Schema<IExamResult>({
  exam: {
    type: Schema.Types.ObjectId,
    ref: 'Exam',
    required: true
  },
  student: {
    type: Schema.Types.ObjectId,
    ref: 'Student',
    required: true
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: true
  },
  score: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  answers: [{
    questionId: {
      type: Schema.Types.ObjectId,
      ref: 'Question',
      required: true
    },
    answer: {
      type: String,
      required: true
    },
    isCorrect: {
      type: Boolean,
      required: true
    },
    timeSpent: {
      type: Number,
      required: true,
      min: 0
    },
    points: {
      type: Number,
      required: true,
      min: 0
    }
  }],
  metadata: {
    device: String,
    ipAddress: String,
    browser: String
  }
}, {
  timestamps: true
});

// إنشاء الفهارس
examResultSchema.index({ exam: 1, student: 1 }, { unique: true });
examResultSchema.index({ exam: 1, score: -1 });
examResultSchema.index({ student: 1, createdAt: -1 });

// Middleware للتحقق من صحة البيانات قبل الحفظ
examResultSchema.pre('save', async function(next) {
  if (this.isNew) {
    const existingResult = await ExamResult.findOne({
      exam: this.exam,
      student: this.student
    });

    if (existingResult) {
      throw new Error('الطالب قد أدى هذا الاختبار مسبقاً');
    }
  }
  next();
});

export const ExamResult = mongoose.model<IExamResult>('ExamResult', examResultSchema);