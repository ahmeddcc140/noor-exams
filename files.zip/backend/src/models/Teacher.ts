import mongoose, { Document, Schema } from 'mongoose';
import { generateTeacherCode, generateTeacherPassword } from '../utils/codeGenerator';

interface ITeacher extends Document {
  teacherCode: string;
  fullName: string;
  phoneNumber: string;
  email: string;
  subject: mongoose.Types.ObjectId;
  educationalLevels: string[];
  password: string;
  createdAt: Date;
  updatedAt: Date;
}

const teacherSchema = new Schema({
  teacherCode: {
    type: String,
    unique: true,
    required: true,
    default: generateTeacherCode
  },
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  phoneNumber: {
    type: String,
    required: true,
    unique: true,
    validate: {
      validator: (v: string) => /^[0-9]{11,}$/.test(v),
      message: 'رقم الهاتف يجب أن يتكون من 11 رقم على الأقل'
    }
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
    validate: {
      validator: (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
      message: 'البريد الإلكتروني غير صالح'
    }
  },
  subject: {
    type: Schema.Types.ObjectId,
    ref: 'Subject',
    required: true
  },
  educationalLevels: [{
    type: String,
    enum: ['primary', 'middle', 'high'],
    required: true
  }],
  password: {
    type: String,
    required: true,
    default: generateTeacherPassword
  }
}, {
  timestamps: true
});

export const Teacher = mongoose.model<ITeacher>('Teacher', teacherSchema);