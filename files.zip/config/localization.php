<?php

return [
    'available_locales' => [
        'ar' => [
            'name' => 'العربية',
            'direction' => 'rtl',
            'flag' => '🇸🇦'
        ],
        'en' => [
            'name' => 'English',
            'direction' => 'ltr',
            'flag' => '🇬🇧'
        ]
    ],
    'default_locale' => 'ar',
    'detect_from_browser' => true,
    'show_language_selector' => true
];