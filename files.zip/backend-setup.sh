cd ../backend
npm init -y