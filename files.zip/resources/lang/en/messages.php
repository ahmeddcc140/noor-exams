<?php

return [
    'welcome' => 'Welcome to Noor Exams System',
    'dashboard' => 'Dashboard',
    'exams' => 'Exams',
    'tasks' => 'Tasks',
    'library' => 'Library',
    'reports' => 'Reports',
    'support' => 'Support',
    'settings' => 'Settings',
    // ... more translations
];