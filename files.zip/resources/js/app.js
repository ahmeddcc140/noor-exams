// إضافة تحسينات تجربة المستخدم
document.addEventListener('DOMContentLoaded', function() {
    // تفعيل التحميل الكسول للصور
    const lazyImages = document.querySelectorAll('img[loading="lazy"]');
    if ('loading' in HTMLImageElement.prototype) {
        lazyImages.forEach(img => {
            img.src = img.dataset.src;
        });
    } else {
        // Fallback لمتصفحات قديمة
        const lazyLoadScript = document.createElement('script');
        lazyLoadScript.src = '/js/lazysizes.min.js';
        document.body.appendChild(lazyLoadScript);
    }

    // تحسين أداء النماذج
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitButton = this.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = 'جاري المعالجة...';
            }
        });
    });
});