@extends('layouts.app')

@section('title', $exam->title)

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- معلومات الاختبار -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <div class="flex justify-between items-center">
            <h1 class="text-2xl font-bold">{{ $exam->title }}</h1>
            <div class="text-gray-600">
                المدة: {{ $exam->duration }} دقيقة
            </div>
        </div>
        <div class="mt-4 grid grid-cols-2 gap-4">
            <div>
                <span class="font-medium">المادة:</span>
                {{ $exam->subject->name }}
            </div>
            <div>
                <span class="font-medium">الدرجة الكلية:</span>
                {{ $exam->total_marks }}
            </div>
            <div>
                <span class="font-medium">تاريخ البدء:</span>
                {{ $exam->start_date->format('Y/m/d H:i') }}
            </div>
            <div>
                <span class="font-medium">تاريخ الانتهاء:</span>
                {{ $exam->end_date->format('Y/m/d H:i') }}
            </div>
        </div>
    </div>

    <!-- أسئلة الاختبار -->
    <form id="examForm" method="POST" action="{{ route('exams.submit', $exam) }}">
        @csrf
        <div class="space-y-6">
            @foreach($exam->questions as $question)
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="mb-4">
                        <h3 class="text-lg font-medium">
                            السؤال {{ $loop->iteration }}
                            <span class="text-gray-600 text-sm">
                                ({{ $question->marks }} درجات)
                            </span>
                        </h3>
                        <p class="mt-2">{{ $question->content }}</p>
                    </div>

                    @switch($question->type)
                        @case('multiple_choice')
                            <div class="space-y-2">
                                @foreach($question->options as $option)
                                    <label class="flex items-center">
                                        <input type="radio" 
                                               name="answers[{{ $question->id }}]" 
                                               value="{{ $option['id'] }}"
                                               class="ml-2">
                                        {{ $option['text'] }}
                                    </label>
                                @endforeach
                            </div>
                            @break

                        @case('true_false')
                            <div class="space-x-4">
                                <label class="inline-flex items-center">
                                    <input type="radio" 
                                           name="answers[{{ $question->id }}]" 
                                           value="true"
                                           class="ml-2">
                                    صح
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="radio" 
                                           name="answers[{{ $question->id }}]" 
                                           value="false"
                                           class="ml-2">
                                    خطأ
                                </label>
                            </div>
                            @break

                        @case('short_answer')
                            <textarea name="answers[{{ $question->id }}]"
                                      rows="3"
                                      class="w-full rounded-md border-gray-300"
                                      placeholder="اكتب إجابتك هنا..."></textarea>
                            @break
                    @endswitch
                </div>
            @endforeach
        </div>

        <!-- أزرار التحكم -->
        <div class="mt-8 flex justify-between">
            <button type="button" 
                    onclick="if(confirm('هل أنت متأكد من حفظ الإجابات؟')) document.getElementById('examForm').submit();"
                    class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
                حفظ وإنهاء
            </button>
            <button type="button"
                    onclick="window.location.href='{{ route('exams.index') }}'"
                    class="bg-gray-500 text-white px-6 py-2 rounded-md hover:bg-gray-600">
                إلغاء
            </button>
        </div>
    </form>
</div>

@push('scripts')
<script>
// التحقق من الوقت المتبقي
let timeLeft = {{ $exam->duration * 60 }};
const timer = setInterval(() => {
    timeLeft--;
    if (timeLeft <= 0) {
        clearInterval(timer);
        alert('انتهى وقت الاختبار');
        document.getElementById('examForm').submit();
    }
    
    // تحديث عرض الوقت المتبقي
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    document.getElementById('timer').textContent = 
        `${minutes}:${seconds.toString().padStart(2, '0')}`;
}, 1000);

// منع مغادرة الصفحة
window.onbeforeunload = function() {
    return "هل أنت متأكد من مغادرة الاختبار؟";
}
</script>
@endpush
@endsection