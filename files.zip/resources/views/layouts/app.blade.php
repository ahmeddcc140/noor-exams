<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }} - @yield('title')</title>
    
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    
    <!-- Scripts -->
    @livewireStyles
</head>
<body class="font-sans antialiased bg-gray-100">
    @include('layouts.navigation')
    
    <main class="container mx-auto px-4 py-6">
        @yield('content')
    </main>

    @livewireScripts
</body>
</html>