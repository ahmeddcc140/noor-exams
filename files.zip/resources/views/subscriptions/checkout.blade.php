@extends('layouts.app')

@section('title', 'إتمام الاشتراك')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="max-w-2xl mx-auto">
        <h1 class="text-2xl font-bold mb-8">إتمام عملية الاشتراك</h1>

        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="font-semibold mb-4">تفاصيل الباقة</h2>
            <div class="flex justify-between mb-2">
                <span>الباقة:</span>
                <span>{{ $package->name }}</span>
            </div>
            <div class="flex justify-between mb-2">
                <span>المدة:</span>
                <span>{{ $package->duration_in_days }} يوم</span>
            </div>
            <div class="flex justify-between mb-2">
                <span>السعر:</span>
                <span>{{ number_format($package->price, 2) }} ج.م</span>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="font-semibold mb-4">اختر وسيلة الدفع</h2>

            <form id="paymentForm" action="{{ route('subscriptions.process-payment') }}" method="POST">
                @csrf
                <input type="hidden" name="package_id" value="{{ $package->id }}">

                <div class="space-y-4">
                    <!-- فوري -->
                    <label class="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                        <input type="radio" name="payment_method" value="fawry" class="ml-2">
                        <img src="{{ asset('images/payment/fawry.png') }}" alt="فوري" class="h-8 ml-2">
                        <span>الدفع عن طريق فوري</span>
                    </label>

                    <!-- فودافون كاش -->
                    <label class="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                        <input type="radio" name="payment_method" value="vodafone_cash" class="ml-2">
                        <img src="{{ asset('images/payment/vodafone.png') }}" alt="فودافون كاش" class="h-8 ml-2">
                        <span>فودافون كاش</span>
                    </label>

                    <!-- ميزة -->
                    <label class="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                        <input type="radio" name="payment_method" value="meeza" class="ml-2">
                        <img src="{{ asset('images/payment/meeza.png') }}" alt="ميزة" class="h-8 ml-2">
                        <span>بطاقة ميزة</span>
                    </label>

                    <!-- تحويل بنكي -->
                    <label class="flex items-center p-4 border rounded-md cursor-pointer hover:bg-gray-50">
                        <input type="radio" name="payment_method" value="bank_transfer" class="ml-2">
                        <i class="fas fa-university text-2xl ml-2"></i>
                        <span>تحويل بنكي</span>
                    </label>
                </div>

                <button type="submit" 
                        class="w-full bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 mt-6">
                    إتمام الدفع
                </button>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.getElementById('paymentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
    
    if (!paymentMethod) {
        alert('الرجاء اختيار وسيلة دفع');
        return;
    }

    this.submit();
});
</script>
@endpush
@endsection