@extends('layouts.app')

@section('title', 'باقات الاشتراك')

@section('content')
<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold mb-8 text-center">اختر باقة الاشتراك المناسبة لك</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        @foreach($packages as $package)
        <div class="bg-white rounded-lg shadow-md p-6 text-center">
            <h2 class="text-xl font-bold mb-4">{{ $package->name }}</h2>
            <p class="text-gray-600 mb-4">{{ $package->description }}</p>
            
            <div class="text-3xl font-bold text-blue-600 mb-4">
                {{ number_format($package->price, 2) }} ج.م
            </div>

            <ul class="text-right mb-6 space-y-2">
                @foreach($package->features as $feature)
                <li class="flex items-center">
                    <i class="fas fa-check text-green-500 ml-2"></i>
                    {{ $feature }}
                </li>
                @endforeach
            </ul>

            <button onclick="window.location.href='{{ route('subscriptions.checkout', $package) }}'"
                    class="w-full bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700">
                اشترك الآن
            </button>
        </div>
        @endforeach
    </div>
</div>
@endsection