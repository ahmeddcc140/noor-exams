@extends('layouts.app')

@section('title', 'لوحة تحكم المشرف')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- إحصائيات النظام -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">إجمالي الطلاب</p>
                    <h3 class="text-2xl font-bold">{{ $totalStudents }}</h3>
                </div>
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-user-graduate"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">إجمالي المعلمين</p>
                    <h3 class="text-2xl font-bold">{{ $totalTeachers }}</h3>
                </div>
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">الاختبارات النشطة</p>
                    <h3 class="text-2xl font-bold">{{ $activeExams }}</h3>
                </div>
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-file-alt"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">نسبة النجاح</p>
                    <h3 class="text-2xl font-bold">{{ number_format($successRate, 1) }}%</h3>
                </div>
                <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <i class="fas fa-chart-pie"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- إدارة المستخدمين -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- آخر المستخدمين المسجلين -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold">آخر المستخدمين المسجلين</h2>
                <a href="{{ route('admin.users.index') }}" 
                   class="text-blue-600 hover:underline">عرض الكل</a>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead>
                        <tr>
                            <th class="text-right py-2">الاسم</th>
                            <th class="text-right py-2">الدور</th>
                            <th class="text-right py-2">تاريخ التسجيل</th>
                            <th class="text-right py-2">الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recentUsers as $user)
                        <tr>
                            <td class="py-2">{{ $user->name }}</td>
                            <td class="py-2">{{ __('roles.' . $user->role) }}</td>
                            <td class="py-2">{{ $user->created_at->format('Y/m/d') }}</td>
                            <td class="py-2">
                                <span class="px-2 py-1 rounded-full text-xs {{ 
                                    $user->status === 'active' ? 'bg-green-100 text-green-800' :
                                    'bg-red-100 text-red-800' 
                                }}">
                                    {{ __('status.' . $user->status) }}
                                </span>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- تقارير النظام -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold">تقارير النظام</h2>
                <a href="{{ route('admin.reports.index') }}" 
                   class="text-blue-600 hover:underline">عرض الكل</a>
            </div>
            
            <div class="space-y-4">
                @foreach($systemReports as $report)
                <div class="border-r-4 {{ 
                    $report->type === 'warning' ? 'border-yellow-600' :
                    $report->type === 'error' ? 'border-red-600' :
                    'border-blue-600'
                }} px-4 py-3">
                    <h3 class="font-medium">{{ $report->title }}</h3>
                    <p class="text-sm text-gray-600">{{ $report->description }}</p>
                    <p class="text-xs text-gray-500 mt-1">
                        {{ $report->created_at->diffForHumans() }}
                    </p>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <!-- إحصائيات الأداء -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-lg font-semibold">إحصائيات النظام</h2>
            <select class="rounded-md border-gray-300" id="statisticsPeriod">
                <option value="day">اليوم</option>
                <option value="week">الأسبوع</option>
                <option value="month">الشهر</option>
            </select>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- رسم بياني للمستخدمين -->
            <div class="h-80">
                <canvas id="usersChart"></canvas>
            </div>

            <!-- رسم بياني للاختبارات -->
            <div class="h-80">
                <canvas id="examsChart"></canvas>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// رسم بياني للمستخدمين
const usersCtx = document.getElementById('usersChart').getContext('2d');
new Chart(usersCtx, {
    type: 'line',
    data: {
        labels: @json($usersData->labels),
        datasets: [{
            label: 'المستخدمين الجدد',
            data: @json($usersData->values),
            borderColor: '#2563eb',
            tension: 0.1
        }]