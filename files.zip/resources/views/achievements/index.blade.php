@extends('layouts.app')

@section('title', 'الإنجازات والشهادات')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <!-- قسم الإحصائيات -->
        <div class="col-span-full bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="grid grid-cols-3 gap-4">
                <div class="text-center">
                    <h3 class="text-2xl font-bold text-blue-600">{{ $totalPoints }}</h3>
                    <p class="text-gray-600">مجموع النقاط</p>
                </div>
                <div class="text-center">
                    <h3 class="text-2xl font-bold text-green-600">{{ $achievementsCount }}</h3>
                    <p class="text-gray-600">الإنجازات المحققة</p>
                </div>
                <div class="text-center">
                    <h3 class="text-2xl font-bold text-purple-600">{{ $certificatesCount }}</h3>
                    <p class="text-gray-600">الشهادات المكتسبة</p>
                </div>
            </div>
        </div>

        <!-- الإنجازات -->
        @foreach($achievements as $achievement)
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <img src="{{ asset('images/badges/' . $achievement->type . '.svg') }}" 
                         alt="{{ $achievement->title }}"
                         class="w-12 h-12">
                    <div class="mr-4">
                        <h3 class="font-semibold">{{ $achievement->title }}</h3>
                        <p class="text-sm text-gray-600">{{ $achievement->description }}</p>
                    </div>
                </div>
                <span class="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">
                    {{ $achievement->points }} نقطة
                </span>
            </div>
            <div class="text-sm text-gray-500">
                تم التحقيق في {{ $achievement->earned_at->format('Y/m/d') }}
            </div>
        </div>
        @endforeach

        <!-- الشهادات -->
        @foreach($certificates as $certificate)
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="mb-4">
                <h3 class="font-semibold">{{ $certificate->title }}</h3>
                <p class="text-sm text-gray-600">{{ $certificate->description }}</p>
            </div>
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-500">
                    تاريخ الإصدار: {{ $certificate->issued_at->format('Y/m/d') }}
                </span>
                <a href="{{ route('certificates.download', $certificate) }}" 
                   class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 text-sm">
                    تحميل الشهادة
                </a>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection