// ... يتبع من الكود السابق

                <div class="mt-4 space-y-2">
                    <div>
                        <span class="text-sm text-gray-500">تاريخ التسليم:</span>
                        <span class="text-sm font-medium">
                            {{ $task->due_date->format('Y/m/d') }}
                        </span>
                    </div>
                    
                    @if(auth()->user()->role === 'student')
                    <div>
                        <span class="text-sm text-gray-500">المعلم:</span>
                        <span class="text-sm font-medium">
                            {{ $task->teacher->full_name }}
                        </span>
                    </div>
                    @endif

                    @if($task->status !== 'completed')
                    <div class="pt-4">
                        @if(auth()->user()->role === 'student')
                            <button onclick="submitTask({{ $task->id }})"
                                    class="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                                تسليم المهمة
                            </button>
                        @else
                            <button onclick="reviewTask({{ $task->id }})"
                                    class="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                                مراجعة المهمة
                            </button>
                        @endif
                    </div>
                    @endif
                </div>
            </div>
        @empty
            <div class="col-span-3 text-center py-12">
                <p class="text-gray-500">لا توجد مهام حالياً</p>
            </div>
        @endforelse
    </div>
</div>

@push('scripts')
<script>
function submitTask(taskId) {
    window.location.href = `/tasks/${taskId}/submit`;
}

function reviewTask(taskId) {
    window.location.href = `/tasks/${taskId}/review`;
}
</script>
@endpush
@endsection