@extends('layouts.app')

@section('title', 'المكتبة الرقمية')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- شريط البحث -->
    <div class="mb-8">
        <div class="flex gap-4">
            <div class="flex-1">
                <input type="text" 
                       placeholder="ابحث عن الكتب والمراجع..." 
                       class="w-full rounded-md border-gray-300">
            </div>
            <select class="rounded-md border-gray-300">
                <option value="">جميع المواد</option>
                @foreach($subjects as $subject)
                <option value="{{ $subject->id }}">{{ $subject->name }}</option>
                @endforeach
            </select>
            <button class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
                بحث
            </button>
        </div>
    </div>

    <!-- عرض المحتوى -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach($resources as $resource)
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="mb-4">
                <div class="flex items-center justify-between">
                    <h3 class="font-semibold">{{ $resource->title }}</h3>
                    <span class="text-sm text-gray-500">
                        {{ $resource->subject->name }}
                    </span>
                </div>
                <p class="text-sm text-gray-600 mt-2">
                    {{ $resource->description }}
                </p>
            </div>
            
            <div class="flex justify-between items-center">
                <div class="flex items-center text-sm text-gray-500">
                    <span>{{ $resource->views_count }} مشاهدة</span>
                    <span class="mx-2">•</span>
                    <span>{{ $resource->downloads_count }} تحميل</span>
                </div>
                
                <a href="{{ route('library.download', $resource) }}"
                   class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 text-sm">
                    تحميل
                </a>
            </div>
        </div>
        @endforeach
    </div>

    <!-- الترقيم -->
    <div class="mt-8">
        {{ $resources->links() }}
    </div>
</div>
@endsection