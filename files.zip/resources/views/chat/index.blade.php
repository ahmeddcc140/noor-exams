@extends('layouts.app')

@section('title', 'الدردشة المباشرة')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="flex h-[600px] bg-white rounded-lg shadow-md">
        <!-- قائمة المحادثات -->
        <div class="w-1/3 border-l">
            <div class="p-4 border-b">
                <h2 class="font-semibold">المحادثات</h2>
            </div>
            <div class="overflow-y-auto h-[calc(100%-65px)]">
                @foreach($chats as $chat)
                <button class="w-full text-right p-4 hover:bg-gray-50 {{ $currentChat?->id === $chat->id ? 'bg-blue-50' : '' }}"
                        onclick="selectChat({{ $chat->id }})">
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="font-medium">
                                {{ auth()->user()->role === 'student' ? 
                                   $chat->teacher->full_name : 
                                   $chat->student->full_name }}
                            </h3>
                            <p class="text-sm text-gray-600 truncate">
                                {{ $chat->last_message }}
                            </p>
                        </div>
                        <span class="text-xs text-gray-500">
                            {{ $chat->last_message_at->diffForHumans() }}
                        </span>
                    </div>
                </button>
                @endforeach
            </div>
        </div>

        <!-- منطقة المحادثة -->
        <div class="flex-1 flex flex-col">
            @if($currentChat)
                <div class="p-4 border-b">
                    <h3 class="font-semibold">
                        {{ auth()->user()->role === 'student' ? 
                           $currentChat->teacher->full_name : 
                           $currentChat->student->full_name }}
                    </h3>
                </div>

                <div class="flex-1 overflow-y-auto p-4 space-y-4">
                    @foreach($messages as $message)
                    <div class="flex {{ $message->sender_id === auth()->id() ? 'justify-end' : 'justify-start' }}">
                        <div class="max-w-[70%] {{ 
                            $message->sender_id === auth()->id() ? 
                            'bg-blue-600 text-white' : 
                            'bg-gray-100 text-gray-900' 
                        }} rounded-lg px-4 py-2">
                            <p>{{ $message->content }}</p>
                            <span class="text-xs {{ 
                                $message->sender_id === auth()->id() ? 
                                'text-blue-100' : 
                                'text-gray-500' 
                            }}">
                                {{ $message->created_at->format('H:i') }}
                            </span>
                        </div>
                    </div>
                    @endforeach
                </div>

                <div class="p-4 border-t">
                    <form id="messageForm" class="flex gap-4">
                        <input type="text" 
                               id="messageInput"
                               placeholder="اكتب رسالتك..." 
                               class="flex-1 rounded-md border-gray-300">
                        <button type="submit"
                                class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
                            إرسال
                        </button>
                    </form>
                </div>
            @else
                <div class="flex-1 flex items-center justify-center text-gray-500">
                    اختر محادثة للبدء
                </div>
            @endif
        </div>
    </div>
</div>

@push('scripts')
<script>
const chatId = {{ $currentChat?->id ?? 'null' }};
let ws;

if (chatId) {
    connectWebSocket();
}

function connectWebSocket() {
    ws = new WebSocket(`ws://localhost:6001/chat/${chatId}`);
    
    ws.onmessage = function(event) {
        const message = JSON.parse(event.data);
        appendMessage(message);
    };
}

function appendMessage(message) {
    // إضافة الرسالة للمحادثة
}

document.getElementById('messageForm').onsubmit = function(e) {
    e.preventDefault();
    const input = document.getElementById('messageInput');
    const content = input.value.trim();
    
    if (content && ws) {
        ws.send(JSON.stringify({
            content,
            chat_id: chatId
        }));
        input.value = '';
    }
};

function selectChat(id) {
    window.location.href = `/chat/${id}`;
}
</script>
@endpush
@endsection