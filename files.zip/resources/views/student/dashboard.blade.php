@extends('layouts.app')

@section('title', 'لوحة التحكم')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <!-- بطاقة الاختبارات القادمة -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold mb-4">الاختبارات القادمة</h3>
            @forelse($upcomingExams as $exam)
                <div class="mb-4 p-4 border rounded-md">
                    <h4 class="font-medium">{{ $exam->title }}</h4>
                    <p class="text-sm text-gray-600">
                        {{ $exam->start_date->format('Y/m/d H:i') }}
                    </p>
                </div>
            @empty
                <p class="text-gray-500">لا توجد اختبارات قادمة</p>
            @endforelse
        </div>

        <!-- بطاقة المهام -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold mb-4">المهام المطلوبة</h3>
            @forelse($pendingTasks as $task)
                <div class="mb-4 p-4 border rounded-md">
                    <h4 class="font-medium">{{ $task->title }}</h4>
                    <p class="text-sm text-gray-600">
                        تاريخ التسليم: {{ $task->due_date->format('Y/m/d') }}
                    </p>
                </div>
            @empty
                <p class="text-gray-500">لا توجد مهام معلقة</p>
            @endforelse
        </div>

        <!-- بطاقة الإنجازات -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold mb-4">آخر الإنجازات</h3>
            @forelse($recentAchievements as $achievement)
                <div class="mb-4 p-4 border rounded-md">
                    <h4 class="font-medium">{{ $achievement->title }}</h4>
                    <p class="text-sm text-gray-600">
                        النقاط: {{ $achievement->points }}
                    </p>
                </div>
            @empty
                <p class="text-gray-500">لم يتم تحقيق إنجازات بعد</p>
            @endforelse
        </div>
    </div>

    <!-- تقرير الأداء -->
    <div class="mt-8">
        <h3 class="text-xl font-semibold mb-6">تقرير الأداء</h3>
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <h4 class="font-medium mb-2">المعدل العام</h4>
                    <p class="text-2xl font-bold text-blue-600">
                        {{ number_format($averageScore, 1) }}%
                    </p>
                </div>
                <div>
                    <h4 class="font-medium mb-2">الاختبارات المكتملة</h4>
                    <p class="text-2xl font-bold text-green-600">
                        {{ $completedExams }}
                    </p>
                </div>
                <div>
                    <h4 class="font-medium mb-2">المهام المنجزة</h4>
                    <p class="text-2xl font-bold text-purple-600">
                        {{ $completedTasks }}
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection