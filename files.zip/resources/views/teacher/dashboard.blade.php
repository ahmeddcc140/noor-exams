@extends('layouts.app')

@section('title', 'لوحة تحكم المعلم')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- إحصائيات سريعة -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">الطلاب النشطين</p>
                    <h3 class="text-2xl font-bold">{{ $activeStudents }}</h3>
                </div>
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">الاختبارات الحالية</p>
                    <h3 class="text-2xl font-bold">{{ $activeExams }}</h3>
                </div>
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-file-alt"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">المهام المعلقة</p>
                    <h3 class="text-2xl font-bold">{{ $pendingTasks }}</h3>
                </div>
                <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <i class="fas fa-tasks"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500">متوسط الأداء</p>
                    <h3 class="text-2xl font-bold">{{ number_format($averagePerformance, 1) }}%</h3>
                </div>
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-chart-line"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- الاختبارات القادمة والمهام -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- الاختبارات القادمة -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold">الاختبارات القادمة</h2>
                <a href="{{ route('teacher.exams.create') }}" 
                   class="text-blue-600 hover:underline">إضافة اختبار</a>
            </div>
            
            <div class="space-y-4">
                @forelse($upcomingExams as $exam)
                <div class="border-r-4 border-blue-600 px-4 py-3">
                    <div class="flex justify-between">
                        <div>
                            <h3 class="font-medium">{{ $exam->title }}</h3>
                            <p class="text-sm text-gray-600">{{ $exam->subject->name }}</p>
                        </div>
                        <div class="text-left">
                            <p class="text-sm">{{ $exam->start_date->format('Y/m/d') }}</p>
                            <p class="text-sm text-gray-500">{{ $exam->start_date->format('H:i') }}</p>
                        </div>
                    </div>
                </div>
                @empty
                <p class="text-gray-500 text-center py-4">لا توجد اختبارات قادمة</p>
                @endforelse
            </div>
        </div>

        <!-- المهام المعلقة -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold">المهام المعلقة للتصحيح</h2>
                <a href="{{ route('teacher.tasks.index') }}" 
                   class="text-blue-600 hover:underline">عرض الكل</a>
            </div>
            
            <div class="space-y-4">
                @forelse($pendingTasksList as $task)
                <div class="border-r-4 border-yellow-600 px-4 py-3">
                    <div class="flex justify-between">
                        <div>
                            <h3 class="font-medium">{{ $task->title }}</h3>
                            <p class="text-sm text-gray-600">{{ $task->student->full_name }}</p>
                        </div>
                        <a href="{{ route('teacher.tasks.review', $task) }}"
                           class="text-blue-600 hover:underline">تصحيح</a>
                    </div>
                </div>
                @empty
                <p class="text-gray-500 text-center py-4">لا توجد مهام معلقة للتصحيح</p>
                @endforelse
            </div>
        </div>
    </div>

    <!-- تقارير الأداء -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-lg font-semibold">تقارير الأداء</h2>
            <select class="rounded-md border-gray-300">
                <option value="week">آخر أسبوع</option>
                <option value="month">آخر شهر</option>
                <option value="semester">الفصل الدراسي</option>
            </select>
        </div>

        <!-- رسم بياني للأداء -->
        <div class="h-80">
            <canvas id="performanceChart"></canvas>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('performanceChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: @json($performanceData->labels),
        datasets: [{
            label: 'متوسط الأداء',
            data: @json($performanceData->values),
            borderColor: '#2563eb',
            tension: 0.1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});
</script>
@endpush
@endsection