@extends('layouts.app')

@section('title', 'التقارير والتحليل')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- تحليل الأداء العام -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 class="text-xl font-bold mb-6">تحليل الأداء العام</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
                <h4 class="text-sm text-gray-600">المعدل العام</h4>
                <p class="text-2xl font-bold text-blue-600">{{ number_format($averageScore, 1) }}%</p>
            </div>
            <div>
                <h4 class="text-sm text-gray-600">التحسن</h4>
                <p class="text-2xl font-bold {{ $improvement > 0 ? 'text-green-600' : 'text-red-600' }}">
                    {{ $improvement > 0 ? '+' : '' }}{{ number_format($improvement, 1) }}%
                </p>
            </div>
            <div>
                <h4 class="text-sm text-gray-600">الترتيب</h4>
                <p class="text-2xl font-bold text-purple-600">{{ $rank }} من {{ $totalStudents }}</p>
            </div>
            <div>
                <h4 class="text-sm text-gray-600">الاختبارات المكتملة</h4>
                <p class="text-2xl font-bold text-gray-800">{{ $completedExams }}</p>
            </div>
        </div>
    </div>

    <!-- تحليل المواد -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 class="text-xl font-bold mb-6">تحليل المواد</h2>
        <div class="space-y-4">
            @foreach($subjectsAnalysis as $subject)
            <div>
                <div class="flex justify-between mb-1">
                    <span class="font-medium">{{ $subject->name }}</span>
                    <span>{{ $subject->score }}%</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="bg-blue-600 h-2 rounded-full" 
                         style="width: {{ $subject->score }}%"></div>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    <!-- توصيات التحسين -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold mb-6">توصيات التحسين</h2>
        <div class="space-y-4">
            @foreach($recommendations as $recommendation)
            <div class="border-r-4 border-blue-600 px-4 py-3">
                <h4 class="font-medium">{{ $recommendation->title }}</h4>
                <p class="text-gray-600 mt-1">{{ $recommendation->description }}</p>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection