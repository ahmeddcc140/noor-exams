@extends('layouts.app')

@section('title', 'تسجيل الدخول')

@section('content')
<div class="min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <h2 class="text-2xl font-bold text-center mb-8">تسجيل الدخول</h2>
        
        <form method="POST" action="{{ route('login') }}" class="space-y-6">
            @csrf
            
            <div>
                <label class="block text-gray-700">البريد الإلكتروني</label>
                <input type="email" name="email" class="mt-1 block w-full rounded-md border-gray-300" required>
            </div>

            <div>
                <label class="block text-gray-700">كلمة المرور</label>
                <input type="password" name="password" class="mt-1 block w-full rounded-md border-gray-300" required>
            </div>

            <div class="flex items-center justify-between">
                <label class="flex items-center">
                    <input type="checkbox" name="remember" class="rounded border-gray-300">
                    <span class="mr-2">تذكرني</span>
                </label>

                <a href="{{ route('password.request') }}" class="text-blue-600 hover:underline">
                    نسيت كلمة المرور؟
                </a>
            </div>

            <button type="submit" class="w-full bg-blue-600 text-white rounded-md py-2 hover:bg-blue-700">
                دخول
            </button>
        </form>
    </div>
</div>
@endsection