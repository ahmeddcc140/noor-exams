// ... تكملة الكود السابق
          <h2 className="text-xl font-semibold mb-4">اقتراحات التحسين</h2>
          <div className="space-y-4">
            {report.analysis.suggestions.map((suggestion, index) => (
              <div key={index} className="bg-blue-50 p-4 rounded-lg">
                <div className="text-blue-700">{suggestion}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* الاختبارات القادمة */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">الاختبارات القادمة</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {report.upcomingExams.map((exam) => (
            <div key={exam.examId} className="border rounded-lg p-4">
              <div className="font-medium mb-2">{exam.title}</div>
              <div className="text-sm text-gray-600 mb-1">{exam.subject}</div>
              <div className="text-sm text-blue-600">
                {new Date(exam.date).toLocaleDateString('ar-SA')}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* نافذة التواصل مع المعلمين */}
      {showMessageModal && (
        <MessageTeacherModal
          studentId={params.studentId}
          onClose={() => setShowMessageModal(false)}
        />
      )}
    </div>
  );
}