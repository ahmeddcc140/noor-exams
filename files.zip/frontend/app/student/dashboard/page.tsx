'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import SubjectCard from '@/components/student/SubjectCard';
import PerformanceChart from '@/components/student/PerformanceChart';
import UpcomingExams from '@/components/student/UpcomingExams';
import Notifications from '@/components/student/Notifications';
import AIAssistant from '@/components/student/AIAssistant';
import { toast } from 'react-hot-toast';

interface DashboardStats {
  subjects: {
    id: string;
    name: string;
    teacher: string;
    progress: number;
    lastGrade: number;
    nextExam?: {
      date: string;
      topic: string;
    };
  }[];
  performance: {
    overall: number;
    bySubject: {
      subject: string;
      average: number;
    }[];
    trend: {
      date: string;
      score: number;
    }[];
  };
  upcomingExams: {
    id: string;
    subject: string;
    title: string;
    date: string;
    duration: number;
    preparationStatus: 'not_started' | 'in_progress' | 'ready';
  }[];
  notifications: {
    id: string;
    type: string;
    message: string;
    date: string;
    read: boolean;
  }[];
  achievements: {
    id: string;
    title: string;
    description: string;
    date: string;
    icon: string;
  }[];
}

export default function StudentDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAIAssistant, setShowAIAssistant] = useState(false);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const response = await axios.get('/api/student/dashboard/stats', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      toast.error('حدث خطأ أثناء تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  if (loading || !stats) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* رأس الصفحة */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold">مرحباً، {localStorage.getItem('studentName')}</h1>
          <p className="text-gray-600">
            {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <button
          onClick={() => setShowAIAssistant(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 flex items-center gap-2"
        >
          <span>المساعد الذكي</span>
          <span>🤖</span>
        </button>
      </div>

      {/* المواد الدراسية */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">المواد الدراسية</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stats.subjects.map((subject) => (
            <SubjectCard
              key={subject.id}
              subject={subject}
            />
          ))}
        </div>
      </section>

      {/* الأداء والإحصائيات */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <section className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">تحليل الأداء</h2>
          <PerformanceChart
            overall={stats.performance.overall}
            bySubject={stats.performance.bySubject}
            trend={stats.performance.trend}
          />
        </section>

        <section className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">الاختبارات القادمة</h2>
          <UpcomingExams
            exams={stats.upcomingExams}
          />
        </section>
      </div>

      {/* الإشعارات والإنجازات */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">آخر الإشعارات</h2>
          <Notifications
            notifications={stats.notifications}
            onMarkAsRead={async (notificationId) => {
              try {
                await axios.post(`/api/student/notifications/${notificationId}/read`, {}, {
                  headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                });
                fetchDashboardStats();
              } catch (error) {
                console.error('Error marking notification as read:', error);
              }
            }}
          />
        </section>

        <section className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">إنجازاتك</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {stats.achievements.map((achievement) => (
              <div
                key={achievement.id}
                className="text-center p-4 rounded-lg border border-gray-200 hover:border-blue-500 transition-colors"
              >
                <div className="text-3xl mb-2">{achievement.icon}</div>
                <div className="font-medium text-sm">{achievement.title}</div>
                <div className="text-xs text-gray-500">{achievement.description}</div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* المساعد الذكي */}
      {showAIAssistant && (
        <AIAssistant
          onClose={() => setShowAIAssistant(false)}
          studentStats={stats}
        />
      )}
    </div>
  );
}