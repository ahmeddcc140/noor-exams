'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface ExamResult {
  examId: string;
  examTitle: string;
  totalScore: number;
  maxScore: number;
  submissionDate: string;
  questions: {
    question: string;
    yourAnswer: string;
    correctAnswer: string;
    score: number;
    maxScore: number;
    feedback?: string;
  }[];
}

export default function ExamResults({ params }: { params: { examId: string } }) {
  const [result, setResult] = useState<ExamResult | null>(null);
  const router = useRouter();

  useEffect(() => {
    fetchResults();
  }, [params.examId]);

  const fetchResults = async () => {
    try {
      const response = await axios.get(`/api/student/exam-results/${params.examId}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      setResult(response.data);
    } catch (error) {
      console.error('Error fetching results:', error);
      router.push('/student/dashboard');
    }
  };

  if (!result) return <div className="text-center py-8">جاري التحميل...</div>;

  const percentage = (result.totalScore / result.maxScore) * 100;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="p-6 border-b">
          <h1 className="text-2xl font-bold mb-2">{result.examTitle}</h1>
          <div className="flex justify-between items-center">
            <span className="text-gray-600">
              تاريخ التقديم: {new Date(result.submissionDate).toLocaleDateString('ar-SA')}
            </span>
            <div className="text-xl font-semibold">
              النتيجة: {result.totalScore}/{result.maxScore} ({percentage.toFixed(1)}%)
            </div>
          </div>
        </div>

        <div className="p-6">
          <h2 className="text-xl font-semibold mb-4">مراجعة الإجابات</h2>
          <div className="space-y-6">
            {result.questions.map((q, index) => (
              <div key={index} className={`p-4 rounded-lg ${
                q.score === q.maxScore ? 'bg-green-50' : 'bg-red-50'
              }`}>
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium">السؤال {index + 1}</h3>
                  <span className="text-sm font-medium">
                    {q.score}/{q.maxScore} نقاط
                  </span>
                </div>
                <p className="mb-2">{q.question}</p>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="font-medium">إجابتك: </span>
                    <span className={q.score === q.maxScore ? 'text-green-600' : 'text-red-600'}>
                      {q.yourAnswer}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium">الإجابة الصحيحة: </span>
                    <span className="text-green-600">{q.correctAnswer}</span>
                  </div>
                  {q.feedback && (
                    <div className="mt-2 p-2 bg-gray-50 rounded">
                      <span className="font-medium">تعليق المعلم: </span>
                      {q.feedback}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}