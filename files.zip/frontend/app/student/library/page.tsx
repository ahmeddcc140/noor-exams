'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import ResourceCard from '@/components/student/library/ResourceCard';
import ResourceFilters from '@/components/student/library/ResourceFilters';
import { toast } from 'react-hot-toast';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'pdf' | 'video' | 'presentation' | 'worksheet';
  subject: string;
  topic: string;
  uploadedBy: {
    name: string;
    role: string;
  };
  uploadDate: string;
  size: number;
  duration?: number;
  thumbnailUrl?: string;
  downloadCount: number;
  rating: number;
}

export default function StudentLibrary() {
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    type: 'all',
    subject: 'all',
    topic: '',
    sortBy: 'date'
  });
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchResources();
  }, [filters, searchQuery]);

  const fetchResources = async () => {
    try {
      const queryParams = new URLSearchParams({
        ...filters,
        search: searchQuery
      });

      const response = await axios.get(`/api/student/library/resources?${queryParams}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setResources(response.data);
    } catch (error) {
      console.error('Error fetching resources:', error);
      toast.error('حدث خطأ أثناء تحميل المواد التعليمية');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">المكتبة التعليمية</h1>
        <div className="relative">
          <input
            type="search"
            placeholder="ابحث عن مواد تعليمية..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-96 px-4 py-2 border rounded-full focus:outline-none focus:border-blue-500"
          />
          <svg
            className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
          </svg>
        </div>
      </div>

      <ResourceFilters
        filters={filters}
        onFilterChange={(newFilters) => setFilters(newFilters)}
      />

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.length === 0 ? (
            <div className="col-span-full text-center text-gray-500 py-12">
              لم يتم العثور على مواد تعليمية
            </div>
          ) : (
            resources.map((resource) => (
              <ResourceCard
                key={resource.id}
                resource={resource}
                onDownload={async () => {
                  try {
                    const response = await axios.get(
                      `/api/student/library/resources/${resource.id}/download`,
                      {
                        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
                        responseType: 'blob'
                      }
                    );
                    
                    const url = window.URL.createObjectURL(new Blob([response.data]));
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', resource.title);
                    document.body.appendChild(link);
                    link.click();
                    link.remove();
                  } catch (error) {
                    console.error('Error downloading resource:', error);
                    toast.error('حدث خطأ أثناء تحميل المادة التعليمية');
                  }
                }}
                onRate={async (rating: number) => {
                  try {
                    await axios.post(`/api/student/library/resources/${resource.id}/rate`, {
                      rating
                    }, {
                      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                    });
                    toast.success('تم تقييم المادة التعليمية بنجاح');
                    fetchResources();
                  } catch (error) {
                    console.error('Error rating resource:', error);
                    toast.error('حدث خطأ أثناء تقييم المادة التعليمية');
                  }
                }}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
}