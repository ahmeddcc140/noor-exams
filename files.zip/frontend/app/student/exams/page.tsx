'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import ExamCard from '@/components/student/ExamCard';
import ExamFilters from '@/components/student/ExamFilters';
import { toast } from 'react-hot-toast';

interface Exam {
  id: string;
  title: string;
  subject: string;
  startDate: string;
  endDate: string;
  duration: number;
  status: 'upcoming' | 'in_progress' | 'completed';
  score?: number;
  questions: number;
  totalPoints: number;
  allowReview: boolean;
}

export default function StudentExams() {
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: 'all',
    subject: 'all',
    date: 'all'
  });

  useEffect(() => {
    fetchExams();
  }, [filters]);

  const fetchExams = async () => {
    try {
      const queryParams = new URLSearchParams({
        status: filters.status,
        subject: filters.subject,
        date: filters.date
      });

      const response = await axios.get(`/api/student/exams?${queryParams}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setExams(response.data);
    } catch (error) {
      console.error('Error fetching exams:', error);
      toast.error('حدث خطأ أثناء جلب بيانات الاختبارات');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">الاختبارات</h1>
        <div className="flex gap-4">
          <button
            onClick={() => setFilters({ status: 'upcoming', subject: 'all', date: 'all' })}
            className={`px-4 py-2 rounded-full ${
              filters.status === 'upcoming'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            القادمة
          </button>
          <button
            onClick={() => setFilters({ status: 'completed', subject: 'all', date: 'all' })}
            className={`px-4 py-2 rounded-full ${
              filters.status === 'completed'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            المكتملة
          </button>
        </div>
      </div>

      <ExamFilters
        filters={filters}
        onFilterChange={(newFilters) => setFilters(newFilters)}
      />

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exams.length === 0 ? (
            <div className="col-span-full text-center text-gray-500 py-12">
              لا توجد اختبارات متاحة حالياً
            </div>
          ) : (
            exams.map((exam) => (
              <ExamCard
                key={exam.id}
                exam={exam}
                onStartExam={async () => {
                  try {
                    const response = await axios.post(`/api/student/exams/${exam.id}/start`, {}, {
                      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                    });
                    window.location.href = `/student/exams/${exam.id}/take`;
                  } catch (error) {
                    console.error('Error starting exam:', error);
                    toast.error('حدث خطأ أثناء بدء الاختبار');
                  }
                }}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
}