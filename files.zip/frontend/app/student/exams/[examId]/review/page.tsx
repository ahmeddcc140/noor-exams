'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';

interface Question {
  id: string;
  type: 'mcq' | 'essay' | 'true_false';
  text: string;
  options?: string[];
  correctAnswer: string;
  points: number;
  explanation?: string;
}

interface Answer {
  questionId: string;
  answer: string;
  isCorrect: boolean;
  points: number;
  feedback?: string;
}

export default function ExamReview({ params }: { params: { examId: string } }) {
  const [loading, setLoading] = useState(true);
  const [exam, setExam] = useState<any>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<{[key: string]: Answer}>({});
  const [selectedQuestion, setSelectedQuestion] = useState<number>(0);

  useEffect(() => {
    loadExamReview();
  }, []);

  const loadExamReview = async () => {
    try {
      const response = await axios.get(`/api/student/exams/${params.examId}/review`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setExam(response.data.exam);
      setQuestions(response.data.questions);
      
      // تحويل الإجابات إلى تنسيق أسهل للاستخدام
      const answersMap = response.data.answers.reduce((acc: any, answer: Answer) => {
        acc[answer.questionId] = answer;
        return acc;
      }, {});
      setAnswers(answersMap);
    } catch (error) {
      console.error('Error loading exam review:', error);
      toast.error('حدث خطأ أثناء تحميل مراجعة الاختبار');
    } finally {
      setLoading(false);
    }
  };

  const renderAnswerReview = (question: Question, answer: Answer) => {
    switch (question.type) {
      case 'mcq':
        return (
          <div className="space-y-2">
            {question.options?.map((option, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border ${
                  option === question.correctAnswer
                    ? 'border-green-500 bg-green-50'
                    : option === answer.answer
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span>{option}</span>
                  {option === question.correctAnswer && (
                    <span className="text-green-600">✓</span>
                  )}
                  {option === answer.answer && option !== question.correctAnswer && (
                    <span className="text-red-600">✕</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        );

      case 'true_false':
        return (
          <div className="grid grid-cols-2 gap-4">
            <div
              className={`p-4 rounded-lg border text-center ${
                'true' === question.correctAnswer
                  ? 'border-green-500 bg-green-50'
                  : 'true' === answer.answer
                  ? 'border-red-500 bg-red-50'
                  : 'border-gray-200'
              }`}
            >
              صح
              {question.correctAnswer === 'true' && (
                <span className="text-green-600 mr-2">✓</span>
              )}
            </div>
            <div
              className={`p-4 rounded-lg border text-center ${
                'false' === question.correctAnswer
                  ? 'border-green-500 bg-green-50'
                  : 'false' === answer.answer
                  ? 'border-red-500 bg-red-50'
                  : 'border-gray-200'
              }`}
            >
              خطأ
              {question.correctAnswer === 'false' && (
                <span className="text-green-600 mr-2">✓</span>
              )}
            </div>
          </div>
        );

      case 'essay':
        return (
          <div className="space-y-4">
            <div className="p-4 rounded-lg border bg-gray-50">
              <div className="text-sm text-gray-600 mb-2">إجابتك:</div>
              <div>{answer.answer}</div>
            </div>
            <div className="p-4 rounded-lg border bg-gray-50">
              <div className="text-sm text-gray-600 mb-2">الإجابة النموذجية:</div>
              <div>{question.correctAnswer}</div>
            </div>
          </div>
        );
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  const currentQuestion = questions[selectedQuestion];
  const currentAnswer = answers[currentQuestion.id];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* معلومات الاختبار */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h1 className="text-2xl font-bold mb-2">{exam.title}</h1>
          <div className="flex gap-6 text-gray-600">
            <div>المادة: {exam.subject}</div>
            <div>الدرجة: {exam.score}%</div>
            <div>تاريخ الاختبار: {new Date(exam.date).toLocaleDateString('ar-SA')}</div>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-8">
          {/* قائمة الأسئلة */}
          <div className="col-span-1">
            <div className="bg-white rounded-lg shadow-md p-4">
              <h3 className="font-medium mb-4">الأسئلة</h3>
              <div className="space-y-2">
                {questions.map((q, index) => (
                  <button
                    key={q.id}
                    onClick={() => setSelectedQuestion(index)}
                    className={`w-full p-3 rounded-lg text-right ${
                      selectedQuestion === index
                        ? 'bg-blue-50 border border-blue-500'
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>السؤال {index + 1}</span>
                      {answers[q.id]?.isCorrect ? (
                        <span className="text-green-600">✓</span>
                      ) : (
                        <span className="text-red-600">✕</span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* تفاصيل السؤال والإجابة */}
          <div className="col-span-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="mb-6">
                <div className="text-lg font-medium mb-2">
                  {currentQuestion.text}
                </div>
                <div className="text-sm text-gray-600">
                  {currentQuestion.points} نقطة | {
                    currentAnswer.isCorrect ? (
                      <span className="text-green-600">إجابة صحيحة</span>
                    ) : (
                      <span className="text-red-600">إجابة خاطئة</span>
                    )
                  }
                </div>
              </div>

              {renderAnswerReview(currentQuestion, currentAnswer)}

              {/* شرح الإجابة */}
              {currentQuestion.explanation && (
                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <div className="text-sm font-medium text-blue-800 mb-2">شرح الإجابة:</div>
                  <div className="text-blue-700">{currentQuestion.explanation}</div>
                </div>
              )}

              {/* ملاحظات المعلم */}
              {currentAnswer.feedback && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-sm font-medium text-gray-600 mb-2">ملاحظات المعلم:</div>
                  <div>{currentAnswer.feedback}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}