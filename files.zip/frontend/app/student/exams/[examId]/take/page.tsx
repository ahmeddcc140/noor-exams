'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';
import ExamTimer from '@/components/student/ExamTimer';
import QuestionView from '@/components/student/QuestionView';
import { toast } from 'react-hot-toast';

interface Question {
  id: string;
  type: 'mcq' | 'essay' | 'true_false';
  text: string;
  options?: string[];
  points: number;
}

interface ExamSession {
  id: string;
  examId: string;
  startTime: string;
  endTime: string;
  remainingTime: number;
  answers: {
    [key: string]: {
      answer: string;
      timeSpent: number;
    };
  };
}

export default function TakeExam({ params }: { params: { examId: string } }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [exam, setExam] = useState<any>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<{[key: string]: string}>({});
  const [session, setSession] = useState<ExamSession | null>(null);
  const [timeSpent, setTimeSpent] = useState<{[key: string]: number}>({});

  useEffect(() => {
    loadExamSession();
  }, []);

  const loadExamSession = async () => {
    try {
      const response = await axios.get(`/api/student/exams/${params.examId}/session`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setExam(response.data.exam);
      setQuestions(response.data.questions);
      setSession(response.data.session);
      
      if (response.data.session.answers) {
        setAnswers(Object.keys(response.data.session.answers).reduce((acc, key) => {
          acc[key] = response.data.session.answers[key].answer;
          return acc;
        }, {}));
        
        setTimeSpent(Object.keys(response.data.session.answers).reduce((acc, key) => {
          acc[key] = response.data.session.answers[key].timeSpent;
          return acc;
        }, {}));
      }
    } catch (error) {
      console.error('Error loading exam session:', error);
      toast.error('حدث خطأ أثناء تحميل الاختبار');
      router.push('/student/exams');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerSubmit = async (questionId: string, answer: string) => {
    try {
      const updatedAnswers = { ...answers, [questionId]: answer };
      setAnswers(updatedAnswers);

      const updatedTimeSpent = {
        ...timeSpent,
        [questionId]: (timeSpent[questionId] || 0) + 1
      };
      setTimeSpent(updatedTimeSpent);

      await axios.post(`/api/student/exams/${params.examId}/answer`, {
        questionId,
        answer,
        timeSpent: updatedTimeSpent[questionId]
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
    } catch (error) {
      console.error('Error submitting answer:', error);
      toast.error('حدث خطأ أثناء حفظ الإجابة');
    }
  };

  const handleFinishExam = async () => {
    if (!confirm('هل أنت متأكد من إنهاء الاختبار؟')) return;

    try {
      await axios.post(`/api/student/exams/${params.examId}/finish`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      router.push(`/student/exams/${params.examId}/result`);
    } catch (error) {
      console.error('Error finishing exam:', error);
      toast.error('حدث خطأ أثناء إنهاء الاختبار');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* شريط المعلومات */}
      <div className="bg-white border-b shadow-sm p-4 fixed top-0 left-0 right-0 z-10">
        <div className="container mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold">{exam.title}</h1>
            <p className="text-sm text-gray-600">{exam.subject}</p>
          </div>
          <div className="flex items-center gap-6">
            <ExamTimer
              initialTime={session?.remainingTime || exam.duration * 60}
              onTimeEnd={handleFinishExam}
            />
            <div className="text-sm">
              السؤال {currentQuestionIndex + 1} من {questions.length}
            </div>
          </div>
        </div>
      </div>

      {/* محتوى الاختبار */}
      <div className="container mx-auto pt-24 pb-32 px-4">
        <div className="max-w-3xl mx-auto">
          <QuestionView
            question={questions[currentQuestionIndex]}
            answer={answers[questions[currentQuestionIndex].id]}
            onAnswer={(answer) => handleAnswerSubmit(questions[currentQuestionIndex].id, answer)}
          />
        </div>
      </div>

      {/* شريط التنقل */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-sm p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex gap-4">
            <button
              onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
              disabled={currentQuestionIndex === 0}
              className="px-4 py-2 rounded-md bg-gray-100 text-gray-700 disabled:opacity-50"
            >
              السابق
            </button>
            <button
              onClick={() => setCurrentQuestionIndex(prev => Math.min(questions.length - 1, prev + 1))}
              disabled={currentQuestionIndex === questions.length - 1}
              className="px-4 py-2 rounded-md bg-gray-100 text-gray-700 disabled:opacity-50"
            >
              التالي
            </button>
          </div>

          <button
            onClick={handleFinishExam}
            className="px-6 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700"
          >
            إنهاء الاختبار
          </button>
        </div>
      </div>

      {/* قائمة الأسئلة */}
      <div className="fixed top-24 right-4 bg-white rounded-lg shadow-md p-4 w-64">
        <h3 className="text-sm font-medium mb-2">الأسئلة</h3>
        <div className="grid grid-cols-5 gap-2">
          {questions.map((q, index) => (
            <button
              key={q.id}
              onClick={() => setCurrentQuestionIndex(index)}
              className={`w-10 h-10 rounded-full flex items-center justify-center text-sm
                ${currentQuestionIndex === index ? 'bg-blue-600 text-white' : ''}
                ${answers[q.id] ? 'bg-green-100' : 'bg-gray-100'}
              `}
            >
              {index + 1}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}