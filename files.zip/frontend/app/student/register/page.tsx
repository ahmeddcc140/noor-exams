'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface RegisterForm {
  studentCode: string;
  fullName: string;
  email: string;
  studentPhone: string;
  parentPhone: string;
  parentCode: string;
  educationalLevel: 'primary' | 'middle' | 'high';
  grade: string;
  password: string;
  confirmPassword: string;
}

export default function StudentRegister() {
  const router = useRouter();
  const [form, setForm] = useState<RegisterForm>({
    studentCode: '',
    fullName: '',
    email: '',
    studentPhone: '',
    parentPhone: '',
    parentCode: '',
    educationalLevel: 'primary',
    grade: '',
    password: '',
    confirmPassword: ''
  });

  const [errors, setErrors] = useState<Partial<RegisterForm>>({});
  const [passwordMatch, setPasswordMatch] = useState<boolean>(true);
  const [phoneMatch, setPhoneMatch] = useState<boolean>(false);

  // التحقق من تطابق كلمة المرور
  useEffect(() => {
    setPasswordMatch(form.password === form.confirmPassword);
  }, [form.password, form.confirmPassword]);

  // التحقق من عدم تطابق أرقام الهواتف
  useEffect(() => {
    setPhoneMatch(form.studentPhone === form.parentPhone);
  }, [form.studentPhone, form.parentPhone]);

  const validateForm = (): boolean => {
    const newErrors: Partial<RegisterForm> = {};

    // التحقق من الاسم الرباعي
    if (form.fullName.split(' ').length < 4) {
      newErrors.fullName = 'يرجى إدخال الاسم الرباعي كاملاً';
    }

    // التحقق من البريد الإلكتروني
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'يرجى إدخال بريد إلكتروني صحيح';
    }

    // التحقق من رقم هاتف الطالب
    if (form.studentPhone.length < 11) {
      newErrors.studentPhone = 'يجب أن لا يقل رقم الهاتف عن 11 رقماً';
    }

    // التحقق من رقم هاتف ولي الأمر
    if (form.parentPhone.length < 11) {
      newErrors.parentPhone = 'يجب أن لا يقل رقم الهاتف عن 11 رقماً';
    }

    // التحقق من تطابق الهواتف
    if (form.studentPhone === form.parentPhone) {
      newErrors.parentPhone = 'لا يمكن أن يكون رقم الهاتف مطابقاً لرقم هاتف الطالب';
    }

    // التحقق من كلمة المرور
    if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/.test(form.password)) {
      newErrors.password = 'يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل وتتضمن أحرفاً وأرقاماً ورموزاً';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !passwordMatch) {
      return;
    }

    try {
      const response = await axios.post('/api/student/register', form);
      if (response.data.success) {
        router.push('/student/registration-success');
      }
    } catch (error) {
      console.error('Registration error:', error);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 className="text-2xl font-bold mb-6 text-center">تسجيل طالب جديد</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* كود الطالب - يتم إنشاؤه تلقائياً */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">كود الطالب</label>
            <input
              type="text"
              value={form.studentCode}
              className="w-full px-3 py-2 border rounded-md bg-gray-100"
              disabled
              placeholder="سيتم إنشاؤه تلقائياً"
            />
          </div>

          {/* الاسم الرباعي */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">الاسم الرباعي</label>
            <input
              type="text"
              value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            />
            {errors.fullName && (
              <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>
            )}
          </div>

          {/* البريد الإلكتروني */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">البريد الإلكتروني</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            />
            {errors.email && (
              <p className="text-red-500 text-sm mt-1">{errors.email}</p>
            )}
          </div>

          {/* رقم هاتف الطالب */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">رقم هاتف الطالب</label>
            <input
              type="tel"
              value={form.studentPhone}
              onChange={(e) => setForm({ ...form, studentPhone: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
              pattern="[0-9]{11,}"
            />
            {errors.studentPhone && (
              <p className="text-red-500 text-sm mt-1">{errors.studentPhone}</p>
            )}
          </div>

          {/* رقم هاتف ولي الأمر */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">رقم هاتف ولي الأمر</label>
            <input
              type="tel"
              value={form.parentPhone}
              onChange={(e) => setForm({ ...form, parentPhone: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
              pattern="[0-9]{11,}"
            />
            {errors.parentPhone && (
              <p className="text-red-500 text-sm mt-1">{errors.parentPhone}</p>
            )}
            {phoneMatch && (
              <p className="text-red-500 text-sm mt-1">رقم الهاتف مطابق لرقم هاتف الطالب</p>
            )}
          </div>

          {/* المرحلة الدراسية */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">المرحلة الدراسية</label>
            <select
              value={form.educationalLevel}
              onChange={(e) => setForm({ ...form, educationalLevel: e.target.value as any })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="primary">ابتدائي</option>
              <option value="middle">إعدادي</option>
              <option value="high">ثانوي</option>
            </select>
          </div>

          {/* الصف الدراسي */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">الصف الدراسي</label>
            <select
              value={form.grade}
              onChange={(e) => setForm({ ...form, grade: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            >
              {form.educationalLevel === 'primary' && (
                <>
                  <option value="1">الصف الأول</option>
                  <option value="2">الصف الثاني</option>
                  <option value="3">الصف الثالث</option>
                  <option value="4">الصف الرابع</option>
                  <option value="5">الصف الخامس</option>
                  <option value="6">الصف السادس</option>
                </>
              )}
              {form.educationalLevel === 'middle' && (
                <>
                  <option value="7">الصف الأول</option>
                  <option value="8">الصف الثاني</option>
                  <option value="9">الصف الثالث</option>
                </>
              )}
              {form.educationalLevel === 'high' && (
                <>
                  <option value="10">الصف الأول</option>
                  <option value="11">الصف الثاني</option>
                  <option value="12">الصف الثالث</option>
                </>
              )}
            </select>
          </div>

          {/* كلمة المرور */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">كلمة المرور</label>
            <input
              type="password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            />
            {errors.password && (
              <p className="text-red-500 text-sm mt-1">{errors.password}</p>
            )}
          </div>

          {/* تأكيد كلمة المرور */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">تأكيد كلمة المرور</label>
            <input
              type="password"
              value={form.confirmPassword}
              onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            />
            {!passwordMatch && (
              <p className="text-red-500 text-sm mt-1">كلمة المرور غير متطابقة</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
            disabled={!passwordMatch || phoneMatch}
          >
            تسجيل
          </button>
        </form>
      </div>
    </div>
  );
}