'use client';

import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';

interface Message {
  id: string;
  sender: {
    id: string;
    name: string;
    role: string;
    avatar?: string;
  };
  recipient: {
    id: string;
    name: string;
    role: string;
    avatar?: string;
  };
  content: string;
  attachments?: {
    name: string;
    url: string;
    type: string;
  }[];
  createdAt: string;
  read: boolean;
}

interface Teacher {
  id: string;
  name: string;
  subject: string;
  avatar?: string;
  lastSeen: string;
  online: boolean;
}

export default function StudentMessages() {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchTeachers();
    const interval = setInterval(fetchMessages, 5000); // تحديث الرسائل كل 5 ثواني
    return () => clearInterval(interval);
  }, [selectedTeacher]);

  const fetchTeachers = async () => {
    try {
      const response = await axios.get('/api/student/messages/teachers', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setTeachers(response.data);
      if (response.data.length > 0 && !selectedTeacher) {
        setSelectedTeacher(response.data[0]);
      }
    } catch (error) {
      console.error('Error fetching teachers:', error);
      toast.error('حدث خطأ أثناء تحميل قائمة المعلمين');
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async () => {
    if (!selectedTeacher) return;

    try {
      const response = await axios.get(`/api/student/messages/${selectedTeacher.id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setMessages(response.data);
      scrollToBottom();
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTeacher || !newMessage.trim()) return;

    try {
      const response = await axios.post('/api/student/messages/send', {
        recipientId: selectedTeacher.id,
        content: newMessage,
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });

      setMessages([...messages, response.data]);
      setNewMessage('');
      scrollToBottom();
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('حدث خطأ أثناء إرسال الرسالة');
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="h-screen flex">
      {/* قائمة المعلمين */}
      <div className="w-80 bg-white border-l">
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold">المعلمين</h2>
        </div>
        <div className="overflow-y-auto h-full">
          {teachers.map((teacher) => (
            <button
              key={teacher.id}
              onClick={() => setSelectedTeacher(teacher)}
              className={`w-full p-4 flex items-center gap-3 hover:bg-gray-50 ${
                selectedTeacher?.id === teacher.id ? 'bg-blue-50' : ''
              }`}
            >
              <div className="relative">
                <img
                  src={teacher.avatar || '/default-avatar.png'}
                  alt={teacher.name}
                  className="w-12 h-12 rounded-full"
                />
                {teacher.online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                )}
              </div>
              <div className="flex-1 text-right">
                <div className="font-medium">{teacher.name}</div>
                <div className="text-sm text-gray-500">{teacher.subject}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* منطقة المحادثة */}
      <div className="flex-1 flex flex-col bg-gray-50">
        {selectedTeacher ? (
          <>
            {/* رأس المحادثة */}
            <div className="bg-white p-4 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={selectedTeacher.avatar || '/default-avatar.png'}
                  alt={selectedTeacher.name}
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <div className="font-medium">{selectedTeacher.name}</div>
                  <div className="text-sm text-gray-500">{selectedTeacher.subject}</div>
                </div>
              </div>
              <div className="text-sm text-gray-500">
                {selectedTeacher.online ? 'متصل الآن' : `آخر ظهور: ${new Date(selectedTeacher.lastSeen).toLocaleString('ar-SA')}`}
              </div>
            </div>

            {/* الرسائل */}
            <div className="flex-1 overflow-y-auto p-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`mb-4 flex ${
                    message.sender.role === 'student' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg p-3 ${
                      message.sender.role === 'student'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white'
                    }`}
                  >
                    <div className="text-sm">{message.content}</div>
                    {message.attachments && message.attachments.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {message.attachments.map((attachment, index) => (
                          <a
                            key={index}
                            href={attachment.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-sm text-blue-100 hover:text-white"
                          >
                            📎 {attachment.name}
                          </a>
                        ))}
                      </div>
                    )}
                    <div className="text-xs mt-1 opacity-75">
                      {new Date(message.createdAt).toLocaleTimeString('ar-SA')}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* نموذج إرسال الرسائل */}
            <form onSubmit={sendMessage} className="bg-white p-4 shadow-t">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="اكتب رسالتك هنا..."
                  className="flex-1 px-4 py-2 border rounded-full focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim()}
                  className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 disabled:opacity-50"
                >
                  إرسال
                </button>
              </div>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            اختر معلماً لبدء المحادثة
          </div>
        )}
      </div>
    </div>
  );
}