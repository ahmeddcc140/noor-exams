'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface ExamQuestion {
  id: string;
  question: string;
  type: 'multiple-choice' | 'true-false' | 'essay';
  options?: { text: string; isCorrect?: boolean }[];
}

interface ExamData {
  _id: string;
  title: string;
  duration: number;
  questions: ExamQuestion[];
}

export default function TakeExam({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [exam, setExam] = useState<ExamData | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchExam = async () => {
      try {
        const response = await axios.get(`/api/exams/${params.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
          }
        });
        setExam(response.data);
        setTimeLeft(response.data.duration * 60); // Convert minutes to seconds
      } catch (error) {
        console.error('Error fetching exam:', error);
        router.push('/student/dashboard');
      }
    };

    fetchExam();
  }, [params.id]);

  useEffect(() => {
    if (timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const handleSubmit = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      await axios.post(`/api/exams/${params.id}/submit`, {
        answers,
        endTime: new Date().toISOString()
      }, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      router.push(`/student/results/${params.id}`);
    } catch (error) {
      console.error('Error submitting exam:', error);
      setIsSubmitting(false);
    }
  };

  if (!exam) return <div className="text-center py-8">جاري التحميل...</div>;

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white shadow-lg rounded-lg p-6 mb-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">{exam.title}</h1>
          <div className="text-xl font-semibold text-red-600">
            الوقت المتبقي: {formatTime(timeLeft)}
          </div>
        </div>

        <div className="space-y-8">
          {exam.questions.map((question, index) => (
            <div key={question.id} className="border-b pb-6">
              <h3 className="text-lg font-medium mb-4">
                السؤال {index + 1}: {question.question}
              </h3>

              {question.type === 'multiple-choice' && (
                <div className="space-y-3">
                  {question.options?.map((option, optIndex) => (
                    <label key={optIndex} className="flex items-center space-x-3">
                      <input
                        type="radio"
                        name={question.id}
                        value={option.text}
                        onChange={(e) => setAnswers({
                          ...answers,
                          [question.id]: e.target.value
                        })}
                        className="form-radio h-4 w-4 text-indigo-600"
                      />
                      <span className="text-gray-700">{option.text}</span>
                    </label>
                  ))}
                </div>
              )}

              {question.type === 'true-false' && (
                <div className="space-x-6">
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name={question.id}
                      value="true"
                      onChange={(e) => setAnswers({
                        ...answers,
                        [question.id]: e.target.value
                      })}
                      className="form-radio h-4 w-4 text-indigo-600"
                    />
                    <span className="mr-2">صح</span>
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name={question.id}
                      value="false"
                      onChange={(e) => setAnswers({
                        ...answers,
                        [question.id]: e.target.value
                      })}
                      className="form-radio h-4 w-4 text-indigo-600"
                    />
                    <span className="mr-2">خطأ</span>
                  </label>
                </div>
              )}

              {question.type === 'essay' && (
                <textarea
                  value={answers[question.id] || ''}
                  onChange={(e) => setAnswers({
                    ...answers,
                    [question.id]: e.target.value
                  })}
                  className="w-full h-32 p-2 border rounded-md"
                  placeholder="اكتب إجابتك هنا..."
                />
              )}
            </div>
          ))}
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 disabled:bg-gray-400"
          >
            {isSubmitting ? 'جاري التسليم...' : 'تسليم الاختبار'}
          </button>
        </div>
      </div>
    </div>
  );
}