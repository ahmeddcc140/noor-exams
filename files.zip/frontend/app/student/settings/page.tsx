'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';

interface StudentSettings {
  profile: {
    name: string;
    email: string;
    phone: string;
    avatar?: string;
  };
  notifications: {
    email: boolean;
    push: boolean;
    sms: boolean;
    examReminders: boolean;
    gradesPublished: boolean;
    teacherMessages: boolean;
  };
  privacy: {
    showOnlineStatus: boolean;
    showLastSeen: boolean;
    showProgress: boolean;
  };
  preferences: {
    language: string;
    theme: string;
    fontSize: string;
  };
}

export default function StudentSettings() {
  const [settings, setSettings] = useState<StudentSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const [newAvatar, setNewAvatar] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await axios.get('/api/student/settings', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setSettings(response.data);
    } catch (error) {
      console.error('Error fetching settings:', error);
      toast.error('حدث خطأ أثناء تحميل الإعدادات');
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setNewAvatar(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  const saveSettings = async (section: string, data: any) => {
    setSaving(true);
    try {
      let endpoint = `/api/student/settings/${section}`;
      let payload = data;

      if (section === 'profile' && newAvatar) {
        const formData = new FormData();
        formData.append('avatar', newAvatar);
        Object.keys(data).forEach(key => {
          formData.append(key, data[key]);
        });
        
        await axios.post(endpoint, formData, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'multipart/form-data'
          }
        });
      } else {
        await axios.post(endpoint, payload, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
      }

      toast.success('تم حفظ الإعدادات بنجاح');
      fetchSettings();
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('حدث خطأ أثناء حفظ الإعدادات');
    } finally {
      setSaving(false);
    }
  };

  if (loading || !settings) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-8">إعدادات الحساب</h1>

      <div className="grid grid-cols-4 gap-8">
        {/* القائمة الجانبية */}
        <div className="col-span-1">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <button
              onClick={() => setActiveTab('profile')}
              className={`w-full p-4 text-right ${
                activeTab === 'profile' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              الملف الشخصي
            </button>
            <button
              onClick={() => setActiveTab('notifications')}
              className={`w-full p-4 text-right ${
                activeTab === 'notifications' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              الإشعارات
            </button>
            <button
              onClick={() => setActiveTab('privacy')}
              className={`w-full p-4 text-right ${
                activeTab === 'privacy' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              الخصوصية
            </button>
            <button
              onClick={() => setActiveTab('preferences')}
              className={`w-full p-4 text-right ${
                activeTab === 'preferences' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              التفضيلات
            </button>
          </div>
        </div>

        {/* محتوى الإعدادات */}
        <div className="col-span-3">
          <div className="bg-white rounded-lg shadow-md p-6">
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold mb-4">الملف الشخصي</h2>
                
                {/* الصورة الشخصية */}
                <div className="flex items-center gap-4">
                  <img
                    src={avatarPreview || settings.profile.avatar || '/default-avatar.png'}
                    alt="الصورة الشخصية"
                    className="w-24 h-24 rounded-full object-cover"
                  />
                  <div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarChange}
                      className="hidden"
                      id="avatar-upload"
                    />
                    <label
                      htmlFor="avatar-upload"
                      className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md cursor-pointer hover:bg-gray-200"
                    >
                      تغيير الصورة
                    </label>
                  </div>
                </div>

                {/* معلومات الملف الشخصي */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      الاسم
                    </label>
                    <input
                      type="text"
                      value={settings.profile.name}
                      onChange={(e) => setSettings({
                        ...settings,
                        profile: { ...settings.profile, name: e.target.value }
                      })}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      البريد الإلكتروني
                    </label>
                    <input
                      type="email"
                      value={settings.profile.email}
                      onChange={(e) => setSettings({
                        ...settings,
                        profile: { ...settings.profile, email: e.target.value }
                      })}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      رقم الهاتف
                    </label>
                    <input
                      type="tel"
                      value={settings.profile.phone}
                      onChange={(e) => setSettings({
                        ...settings,
                        profile: { ...settings.profile, phone: e.target.value }
                      })}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold mb-4">إعدادات الإشعارات</h2>
                
                <div className="space-y-4">
                  <label className="flex items-center justify-between">
                    <span>إشعارات البريد الإلكتروني</span>
                    <input
                      type="checkbox"
                      checked={settings.notifications.email}
                      onChange={(e) => setSettings({
                        ...settings,
                        notifications: { ...settings.notifications, email: e.target.checked }
                      })}
                      className="w-5 h-5 text-blue-600"
                    />
                  </label>
                  
                  <label className="flex items-center justify-between">
                    <span>إشعارات المتصفح</span>
                    <input
                      type="checkbox"
                      checked={settings.notifications.push}
                      onChange={(e) => setSettings({
                        ...settings,
                        notifications: { ...settings.notifications, push: e.target.checked }
                      })}
                      className="w-5 h-5 text-blue-600"
                    />
                  </label>
                  
                  <label className="flex items-center justify-between">
                    <span>الرسائل النصية</span>
                    <input
                      type="checkbox"
                      checked={settings.notifications.sms}
                      onChange={(e) => setSettings({
                        ...settings,
                        notifications: { ...settings.notifications, sms: e.target.checked }
                      })}
                      className="w-5 h-5 text-blue-600"
                    />
                  </label>
                </div>
              </div>
            )}

            {/* أزرار الحفظ */}
            <div className="mt-6 flex justify-end gap-4">
              <button
                onClick={() => saveSettings(activeTab, settings[activeTab as keyof StudentSettings])}
                disabled={saving}
                className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                {saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}