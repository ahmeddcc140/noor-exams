'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  points: number;
  progress: number;
  total: number;
  unlockedAt?: string;
  rewards?: {
    type: string;
    value: string;
    claimed: boolean;
  }[];
}

export default function StudentAchievements() {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [points, setPoints] = useState(0);

  useEffect(() => {
    fetchAchievements();
  }, [filter]);

  const fetchAchievements = async () => {
    try {
      const response = await axios.get(`/api/student/achievements?filter=${filter}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setAchievements(response.data.achievements);
      setPoints(response.data.points);
    } catch (error) {
      console.error('Error fetching achievements:', error);
      toast.error('حدث خطأ أثناء تحميل الإنجازات');
    } finally {
      setLoading(false);
    }
  };

  const claimReward = async (achievementId: string, rewardIndex: number) => {
    try {
      await axios.post(`/api/student/achievements/${achievementId}/claim`, {
        rewardIndex
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      toast.success('تم استلام المكافأة بنجاح');
      fetchAchievements();
    } catch (error) {
      console.error('Error claiming reward:', error);
      toast.error('حدث خطأ أثناء استلام المكافأة');
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold">الإنجازات والمكافآت</h1>
          <p className="text-gray-600">نقاطك الحالية: {points}</p>
        </div>

        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="px-4 py-2 border rounded-md"
        >
          <option value="all">جميع الإنجازات</option>
          <option value="unlocked">المكتملة</option>
          <option value="locked">غير المكتملة</option>
          <option value="rewards">المكافآت المتاحة</option>
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="text-4xl">{achievement.icon}</div>
                <div className="text-sm text-gray-500">{achievement.category}</div>
              </div>

              <h3 className="text-lg font-semibold mb-2">{achievement.title}</h3>
              <p className="text-gray-600 text-sm mb-4">{achievement.description}</p>

              {/* شريط التقدم */}
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-1">
                  <span>التقدم</span>
                  <span>{achievement.progress} / {achievement.total}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div