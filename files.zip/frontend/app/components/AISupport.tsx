// ... تكملة الكود السابق
              </ul>
            </div>

            {analysis.similarAnswers && (
              <div>
                <h5 className="font-medium mb-2">إجابات مشابهة</h5>
                <div className="space-y-2">
                  {analysis.similarAnswers.map((answer, index) => (
                    <div key={index} className="bg-white p-3 rounded border">
                      <div className="text-sm text-gray-700">{answer.answer}</div>
                      <div className="text-sm text-purple-600 mt-1">
                        الدرجة: {answer.score}/{maxScore}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}