import { useState, useEffect } from 'react';
import axios from 'axios';

interface ExamReviewModalProps {
  exam: Exam;
  onClose: () => void;
  onApprove: (examId: string) => void;
  onReject: (examId: string, reason: string) => void;
}

export default function ExamReviewModal({
  exam,
  onClose,
  onApprove,
  onReject
}: ExamReviewModalProps) {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectForm, setShowRejectForm] = useState(false);

  useEffect(() => {
    fetchExamQuestions();
  }, [exam.id]);

  const fetchExamQuestions = async () => {
    try {
      const response = await axios.get(`/api/admin/exams/${exam.id}/questions`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setQuestions(response.data);
    } catch (error) {
      console.error('Error fetching exam questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleReject = () => {
    if (!rejectReason.trim()) {
      alert('يرجى كتابة سبب الرفض');
      return;
    }
    onReject(exam.id, rejectReason);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">مراجعة الاختبار: {exam.title}</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ✕
          </button>
        </div>

        {/* معلومات الاختبار */}
        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="text-sm text-gray-600">المادة</div>
              <div className="font-medium">{exam.subject}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">الصف</div>
              <div className="font-medium">{exam.grade}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">المدة</div>
              <div className="font-medium">{exam.duration} دقيقة</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">عدد الأسئلة</div>
              <div className="font-medium">{exam.questionsCount}</div>
            </div>
          </div>
        </div>

        {/* الأسئلة */}
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {questions.map((question, index) => (
              <div key={question.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <div className="font-medium">السؤال {index + 1}</div>
                  <div className="text-sm text-gray-500">
                    {question.type === 'mcq' ? 'اختيار من متعدد' : 'مقالي'}
                  </div>
                </div>
                <div className="mb-4">{question.text}</div>
                {question.type === 'mcq' && (
                  <div className="grid grid-cols-2 gap-2">
                    {question.options.map((option, optIndex) => (
                      <div
                        key={optIndex}
                        className={`p-2 rounded ${
                          option === question.correctAnswer
                            ? 'bg-green-50 border border-green-200'
                            : 'bg-gray-50'
                        }`}
                      >
                        {option}
                      </div>
                    ))}
                  </div>
                )}
                <div className="mt-2 text-sm text-gray-600">
                  الدرجة: {question.points} نقاط
                </div>
              </div>
            ))}
          </div>
        )}

        {/* أزرار الإجراءات */}
        <div className="mt-8 flex justify-end gap-4">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            إغلاق
          </button>
          
          {exam.status === 'pending' && (
            <>
              <button
                onClick={() => setShowRejectForm(true)}
                className="px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                رفض
              </button>
              <button
                onClick={() => onApprove(exam.id)}
                className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
              >
                اعتماد
              </button>
            </>
          )}
        </div>

        {/* نموذج الرفض */}
        {showRejectForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-lg w-full">
              <h3 className="text-lg font-medium mb-4">سبب رفض الاختبار</h3>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full px-3 py-2 border rounded-md"
                rows={4}
                placeholder="اكتب سبب الرفض هنا..."
              />
              <div className="mt-4 flex justify-end gap-4">
                <button
                  onClick={() => setShowRejectForm(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleReject}
                  className="px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                >
                  تأكيد الرفض
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}