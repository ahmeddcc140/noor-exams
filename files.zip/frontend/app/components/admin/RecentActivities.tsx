interface Activity {
  id: string;
  type: string;
  description: string;
  user: string;
  timestamp: string;
}

export default function RecentActivities({ activities }: { activities: Activity[] }) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'exam':
        return '📝';
      case 'user':
        return '👤';
      case 'system':
        return '⚙️';
      default:
        return '📌';
    }
  };

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div
          key={activity.id}
          className="flex items-start space-x-4 space-x-reverse border-b pb-4 last:border-b-0"
        >
          <div className="text-2xl">
            {getActivityIcon(activity.type)}
          </div>
          <div className="flex-1">
            <div className="text-sm text-gray-600">
              {activity.description}
            </div>
            <div className="mt-1 flex items-center text-xs text-gray-500">
              <span>{activity.user}</span>
              <span className="mx-2">•</span>
              <span>{new Date(activity.timestamp).toLocaleString('ar-SA')}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}