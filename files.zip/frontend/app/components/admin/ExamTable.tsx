interface ExamTableProps {
  exams: Exam[];
  onReview: (exam: Exam) => void;
  onApprove: (examId: string) => void;
  onReject: (examId: string, reason: string) => void;
  onDelete: (examId: string) => void;
}

export default function ExamTable({
  exams,
  onReview,
  onApprove,
  onReject,
  onDelete
}: ExamTableProps) {
  const getStatusBadge = (status: string) => {
    const classes = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      active: 'bg-blue-100 text-blue-800',
      completed: 'bg-gray-100 text-gray-800',
      draft: 'bg-purple-100 text-purple-800'
    };

    const labels = {
      pending: 'في انتظار المراجعة',
      approved: 'معتمد',
      active: 'نشط',
      completed: 'مكتمل',
      draft: 'مسودة'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs ${classes[status]}`}>
        {labels[status]}
      </span>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <table className="min-w-full">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              عنوان الاختبار
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              المادة
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              الصف
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              المعلم
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              الحالة
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              تاريخ البدء
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              الإجراءات
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {exams.map((exam) => (
            <tr key={exam.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-gray-900">
                  {exam.title}
                </div>
                <div className="text-sm text-gray-500">
                  {exam.questionsCount} أسئلة • {exam.duration} دقيقة
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {exam.subject}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {exam.grade}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{exam.teacher.name}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {getStatusBadge(exam.status)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {new Date(exam.startDate).toLocaleDateString('ar-SA')}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <div className="flex gap-2">
                  <button
                    onClick={() => onReview(exam)}
                    className="text-blue-600 hover:text-blue-900"
                  >
                    مراجعة
                  </button>
                  {exam.status === 'pending' && (
                    <>
                      <button
                        onClick={() => onApprove(exam.id)}
                        className="text-green-600 hover:text-green-900"
                      >
                        اعتماد
                      </button>
                      <button
                        onClick={() => {
                          const reason = prompt('سبب الرفض:');
                          if (reason) onReject(exam.id, reason);
                        }}
                        className="text-red-600 hover:text-red-900"
                      >
                        رفض
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => onDelete(exam.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    حذف
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}