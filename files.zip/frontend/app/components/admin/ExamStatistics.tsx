import { useState, useEffect } from 'react';
import axios from 'axios';
import { Chart } from 'react-chartjs-2';

interface ExamStats {
  submissionsCount: number;
  averageScore: number;
  passRate: number;
  gradeDistribution: {
    excellent: number;
    veryGood: number;
    good: number;
    pass: number;
    fail: number;
  };
  questionStats: {
    questionId: string;
    correctAnswersRate: number;
    averageTime: number;
  }[];
  timeDistribution: {
    label: string;
    count: number;
  }[];
}

export default function ExamStatistics({ examId }: { examId: string }) {
  const [stats, setStats] = useState<ExamStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStatistics();
  }, [examId]);

  const fetchStatistics = async () => {
    try {
      const response = await axios.get(`/api/admin/exams/${examId}/statistics`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching exam statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !stats) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-6">إحصائيات الاختبار</h2>

      {/* الإحصائيات الرئيسية */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="text-sm text-blue-600">عدد المشاركين</div>
          <div className="text-2xl font-bold">{stats.submissionsCount}</div>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <div className="text-sm text-green-600">متوسط الدرجات</div>
          <div className="text-2xl font-bold">{stats.averageScore}%</div>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg">
          <div className="text-sm text-yellow-600">نسبة النجاح</div>
          <div className="text-2xl font-bold">{stats.passRate}%</div>
        </div>
      </div>

      {/* توزيع الدرجات */}
      <div className="mb-8">
        <h3 className="text-lg font-medium mb-4">توزيع التقديرات</h3>
        <div className="h-64">
          <Chart
            type="bar"
            data={{
              labels: ['ممتاز', 'جيد جداً', 'جيد', 'مقبول', 'راسب'],
              datasets: [{
                data: [
                  stats.gradeDistribution.excellent,
                  stats.gradeDistribution.veryGood,
                  stats.gradeDistribution.good,
                  stats.gradeDistribution.pass,
                  stats.gradeDistribution.fail
                ],
                backgroundColor: [
                  '#10B981',
                  '#3B82F6',
                  '#F59E0B',
                  '#6B7280',
                  '#EF4444'
                ]
              }]
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true
                }
              }
            }}
          />
        </div>
      </div>

      {/* إحصائيات الأسئلة */}
      <div className="mb-8">
        <h3 className="text-lg font-medium mb-4">أداء الأسئلة</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500">
                  رقم السؤال
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500">
                  نسبة الإجابات الصحيحة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500">
                  متوسط زمن الإجابة
                </th>
              </tr>
            </thead>
            <tbody>
              {stats.questionStats.map((stat, index) => (
                <tr key={stat.questionId} className="border-b">
                  <td className="px-6 py-4">السؤال {index + 1}</td>
                  <td className="px-6 py-4">
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div
                        className="bg-blue-600 h-2.5 rounded-full"
                        style={{ width: `${stat.correctAnswersRate}%` }}
                      ></div>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {stat.correctAnswersRate}%
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {Math.round(stat.averageTime)} ثانية
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* توزيع الوقت */}
      <div>
        <h3 className="text-lg font-medium mb-4">توزيع زمن الإجابة</h3>
        <div className="h-64">
          <Chart
            type="line"
            data={{
              labels: stats.timeDistribution.map(d => d.label),
              datasets: [{
                label: 'عدد الطلاب',
                data: stats.timeDistribution.map(d => d.count),
                borderColor: 'rgb(59, 130, 246)',
                tension: 0.1
              }]
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false
            }}
          />
        </div>
      </div>
    </div>
  );
}