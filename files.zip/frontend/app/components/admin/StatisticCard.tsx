interface StatisticCardProps {
  title: string;
  value: number;
  change?: number;
  total?: number;
  pending?: number;
  icon: string;
  type: 'primary' | 'success' | 'warning' | 'info';
  isPercentage?: boolean;
}

export default function StatisticCard({
  title,
  value,
  change,
  total,
  pending,
  icon,
  type,
  isPercentage
}: StatisticCardProps) {
  const getTypeClasses = () => {
    switch (type) {
      case 'primary':
        return 'bg-blue-50 text-blue-600';
      case 'success':
        return 'bg-green-50 text-green-600';
      case 'warning':
        return 'bg-yellow-50 text-yellow-600';
      case 'info':
        return 'bg-purple-50 text-purple-600';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-full ${getTypeClasses()}`}>
          <span className="text-2xl">{icon}</span>
        </div>
        {change !== undefined && (
          <div className={`text-sm ${
            change >= 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            {change >= 0 ? '+' : ''}{change}
            {isPercentage ? '%' : ''}
          </div>
        )}
      </div>

      <h3 className="text-gray-600 text-sm mb-1">{title}</h3>
      <div className="text-2xl font-bold">
        {value}
        {isPercentage && '%'}
      </div>

      {total && (
        <div className="text-sm text-gray-500 mt-2">
          من إجمالي {total}
        </div>
      )}

      {pending && (
        <div className="text-sm text-yellow-600 mt-2">
          {pending} في الانتظار
        </div>
      )}
    </div>
  );
}