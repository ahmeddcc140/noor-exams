// ... باقي الاستيرادات السابقة تظل كما هي

interface FormData {
  studentCode: string;
  fullName: string;
  email: string;
  studentPhone: string;
  parentPhone: string;
  educationLevel: string;
  grade: string;
  password: string;
  confirmPassword: string;
}

export default function RegisterModal({ onClose }: RegisterModalProps) {
  const [formData, setFormData] = useState<FormData>({
    studentCode: '',
    fullName: '',
    email: '',
    studentPhone: '',
    parentPhone: '',
    educationLevel: '',
    grade: '',
    password: '',
    confirmPassword: ''
  });

  // ... باقي المتغيرات والوظائف تظل كما هي

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!passwordStrength.isValid) {
      toast.error('كلمة المرور لا تستوفي المتطلبات');
      return;
    }

    if (!passwordMatch) {
      toast.error('كلمات المرور غير متطابقة');
      return;
    }

    if (!phoneMatch) {
      toast.error('رقم هاتف الطالب وولي الأمر يجب أن يكونا مختلفين');
      return;
    }

    setLoading(true);
    try {
      // كود ولي الأمر سيتم توليده في الخادم (Backend)
      const response = await axios.post('/api/auth/student/register', {
        ...formData,
        registrationDate: new Date().toISOString(),
        registeredBy: 'self' // تسجيل ذاتي من قبل الطالب
      });
      
      toast.success('تم إنشاء الحساب بنجاح!');
      onClose();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'حدث خطأ أثناء إنشاء الحساب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center overflow-y-auto py-6">
      <div className="bg-white rounded-lg max-w-2xl w-full mx-4">
        {/* ... باقي الكود السابق للعنوان */}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* كود الطالب - غير قابل للتعديل */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              كود الطالب
            </label>
            <input
              type="text"
              value={formData.studentCode}
              disabled
              className="w-full px-3 py-2 border rounded-md bg-gray-100"
            />
            <p className="text-sm text-gray-500 mt-1">
              سيتم استخدام هذا الكود لتسجيل الدخول
            </p>
          </div>

          {/* ... باقي حقول النموذج تظل كما هي */}

          {/* إضافة ملحوظة عن إخطار ولي الأمر */}
          <div className="bg-blue-50 p-4 rounded-md">
            <p className="text-sm text-blue-800">
              سيتم إرسال بيانات الدخول الخاصة بولي الأمر عبر رسالة نصية على الرقم المسجل
            </p>
          </div>

          <div className="flex items-center justify-between pt-6 border-t">
            <p className="text-sm text-gray-500">* الحقول المطلوبة</p>
            <button
              type="submit"
              disabled={loading || !passwordMatch || !passwordStrength.isValid || !phoneMatch}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'جاري إنشاء الحساب...' : 'إنشاء الحساب'}
            </button>
          </div>
        </form>

        {/* ... باقي الكود يظل كما هو */}
      </div>
    </div>
  );
}