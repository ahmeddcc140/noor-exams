interface StatisticsProps {
  stats: {
    students: number;
    teachers: number;
    admins: number;
    exams: number;
    successRate: number;
  };
}

export default function Statistics({ stats }: StatisticsProps) {
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num;
  };

  return (
    <section className="py-16 bg-blue-600 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">إحصائيات المنصة</h2>
          <p className="text-blue-100 max-w-2xl mx-auto">
            نفخر بثقة آلاف المستخدمين في منصة نور للاختبارات الإلكترونية
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{formatNumber(stats.students)}</div>
            <div className="text-blue-100">طالب مسجل</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{formatNumber(stats.teachers)}</div>
            <div className="text-blue-100">معلم نشط</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{formatNumber(stats.admins)}</div>
            <div className="text-blue-100">إداري</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{formatNumber(stats.exams)}</div>
            <div className="text-blue-100">اختبار منجز</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{stats.successRate}%</div>
            <div className="text-blue-100">نسبة النجاح</div>
          </div>
        </div>

        {/* رسم بياني تفاعلي */}
        <div className="mt-16 bg-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold">تطور عدد المستخدمين</h3>
            <select className="bg-transparent border border-blue-300 rounded px-3 py-1 text-sm">
              <option value="year">آخر سنة</option>
              <option value="month">آخر شهر</option>
              <option value="week">آخر أسبوع</option>
            </select>
          </div>
          <div className="h-64">
            {/* هنا يمكن إضافة مكتبة رسوم بيانية مثل Chart.js أو Recharts */}
          </div>
        </div>
      </div>
    </section>
  );
}