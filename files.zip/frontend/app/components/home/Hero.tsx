interface HeroProps {
  onRegisterClick: () => void;
}

export default function Hero({ onRegisterClick }: HeroProps) {
  return (
    <div className="relative bg-gradient-to-b from-blue-50 to-white pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-right">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              منصة نور للاختبارات الإلكترونية
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              نظام متكامل لإدارة الاختبارات والتقييم الذكي، يجمع بين سهولة الاستخدام وقوة الأداء
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button
                onClick={onRegisterClick}
                className="px-8 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-lg font-medium"
              >
                ابدأ الآن مجاناً
              </button>
              <a
                href="#features"
                className="px-8 py-3 border-2 border-blue-600 text-blue-600 rounded-md hover:bg-blue-50 text-lg font-medium"
              >
                تعرف على المزيد
              </a>
            </div>
            <div className="mt-8 text-sm text-gray-500">
              انضم إلى أكثر من 100,000 طالب ومعلم يستخدمون منصة نور
            </div>
          </div>
          <div className="hidden lg:block">
            <img
              src="/images/hero-illustration.svg"
              alt="نور للاختبارات الإلكترونية"
              className="w-full h-auto"
            />
          </div>
        </div>

        {/* مميزات سريعة */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <div className="text-3xl mb-4">🎯</div>
            <h3 className="text-lg font-semibold mb-2">اختبارات ذكية</h3>
            <p className="text-gray-600">
              تقييم مستمر وتحليل دقيق لمستوى الطلاب
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <div className="text-3xl mb-4">📊</div>
            <h3 className="text-lg font-semibold mb-2">تقارير تفصيلية</h3>
            <p className="text-gray-600">
              متابعة تقدم الطلاب بتقارير وإحصائيات شاملة
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <div className="text-3xl mb-4">🤝</div>
            <h3 className="text-lg font-semibold mb-2">تواصل فعال</h3>
            <p className="text-gray-600">
              منصة موحدة للتواصل بين الطلاب والمعلمين وأولياء الأمور
            </p>
          </div>
        </div>
      </div>

      {/* خلفية زخرفية */}
      <div className="absolute top-0 left-0 right-0 h-full overflow-hidden -z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-100/20 to-transparent"></div>
        <svg
          className="absolute top-0 left-0 right-0"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1440 320"
        >
          <path
            fill="#E3F2FD"
            fillOpacity="1"
            d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"
          ></path>
        </svg>
      </div>
    </div>
  );
}