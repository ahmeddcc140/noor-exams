export default function Features() {
  const features = [
    {
      icon: '📝',
      title: 'إدارة الاختبارات بسهولة',
      description: 'إنشاء وتنظيم وتصحيح الاختبارات بشكل تلقائي مع دعم أنواع متعددة من الأسئلة',
      details: [
        'اختبارات متعددة الخيارات',
        'أسئلة الصواب والخطأ',
        'الأسئلة المقالية',
        'تصحيح تلقائي فوري'
      ]
    },
    {
      icon: '🤖',
      title: 'دعم الذكاء الاصطناعي',
      description: 'تقييم ذكي للإجابات وتوصيات مخصصة لتحسين مستوى الطلاب',
      details: [
        'تحليل الإجابات المقالية',
        'اكتشاف نقاط الضعف',
        'توصيات للتحسين',
        'تكييف مستوى الأسئلة'
      ]
    },
    {
      icon: '📊',
      title: 'تحليل الأداء',
      description: 'تقارير تفصيلية وإحصائيات دقيقة لمتابعة تقدم الطلاب',
      details: [
        'رسوم بيانية تفاعلية',
        'تقارير دورية',
        'مقارنات الأداء',
        'تتبع التحسن'
      ]
    },
    {
      icon: '💬',
      title: 'تواصل فعال',
      description: 'منصة موحدة للتواصل بين جميع أطراف العملية التعليمية',
      details: [
        'رسائل مباشرة',
        'إشعارات فورية',
        'مشاركة الملفات',
        'منتديات النقاش'
      ]
    },
    {
      icon: '📱',
      title: 'تجربة سلسة',
      description: 'واجهة سهلة الاستخدام تعمل على جميع الأجهزة',
      details: [
        'تصميم متجاوب',
        'وضع غير متصل',
        'تحديثات تلقائية',
        'دعم اللغة العربية'
      ]
    },
    {
      icon: '🔒',
      title: 'أمان وخصوصية',
      description: 'حماية كاملة للبيانات وخصوصية المستخدمين',
      details: [
        'تشفير البيانات',
        'نسخ احتياطي',
        'صلاحيات محددة',
        'سجل النشاطات'
      ]
    }
  ];

  return (
    <section id="features" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">مميزات المنصة</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            نوفر مجموعة متكاملة من المميزات التي تسهل عملية التقييم وتضمن أفضل تجربة تعليمية
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="text-3xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600 mb-4">{feature.description}</p>
              <ul className="space-y-2">
                {feature.details.map((detail, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm text-gray-500">
                    <svg
                      className="w-4 h-4 text-blue-500"
                      fill="none"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path d="M5 13l4 4L19 7"></path>
                    </svg>
                    {detail}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}