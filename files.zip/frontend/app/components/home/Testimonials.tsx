import { useState } from 'react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  image: string;
  content: string;
  rating: number;
}

export default function Testimonials() {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "أحمد محمد",
      role: "معلم رياضيات",
      image: "/testimonials/1.jpg",
      content: "منصة رائعة سهلت علي عملية إدارة الاختبارات وتقييم الطلاب بشكل كبير.",
      rating: 5
    },
    {
      id: 2,
      name: "سارة أحمد",
      role: "طالبة",
      image: "/testimonials/2.jpg",
      content: "ساعدتني المنصة في التحضير للاختبارات وتحسين مستواي الدراسي.",
      rating: 5
    },
    {
      id: 3,
      name: "محمد علي",
      role: "ولي أمر",
      image: "/testimonials/3.jpg",
      content: "أتابع تقدم أبنائي بسهولة من خلال التقارير المفصلة والإشعارات الفورية.",
      rating: 4
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">آراء المستخدمين</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            تعرف على تجارب مستخدمي منصة نور وكيف ساعدتهم في تحسين العملية التعليمية
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* أزرار التنقل */}
            <button
              onClick={prevTestimonial}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-md hover:bg-gray-50"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button
              onClick={nextTestimonial}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-md hover:bg-gray-50"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>

            {/* المراجعة الحالية */}
            <div className="bg-white rounded-xl shadow-lg p-8 text-center">
              <div className="mb-6">
                <img
                  src={testimonials[currentIndex].image}
                  alt={testimonials[currentIndex].name}
                  className="w-20 h-20 rounded-full mx-auto"
                />
              </div>
              <blockquote className="text-xl italic text-gray-700 mb-6">
                "{testimonials[currentIndex].content}"
              </blockquote>
              <div className="mb-4">
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                  <span key={i} className="text-yellow-400">★</span>
                ))}
              </div>
              <div className="font-semibold text-lg">{testimonials[currentIndex].name}</div>
              <div className="text-gray-500">{testimonials[currentIndex].role}</div>
            </div>
          </div>

          {/* نقاط التنقل */}
          <div className="flex justify-center gap-2 mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full ${
                  index === currentIndex ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}