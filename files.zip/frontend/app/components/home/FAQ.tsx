import { useState } from 'react';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export default function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState('general');

  const faqItems: FAQItem[] = [
    {
      question: "كيف يمكنني إنشاء حساب في المنصة؟",
      answer: "يمكنك إنشاء حساب بسهولة من خلال النقر على زر 'إنشاء حساب' في الصفحة الرئيسية وملء النموذج بمعلوماتك الأساسية. بعد التحقق من بريدك الإلكتروني، يمكنك البدء في استخدام المنصة مباشرة.",
      category: "general"
    },
    {
      question: "ما هي أنواع الاختبارات المدعومة في المنصة؟",
      answer: "تدعم المنصة عدة أنواع من الاختبارات: الاختيار من متعدد، الصواب والخطأ، الأسئلة المقالية، وأسئلة المطابقة. كما يمكن للمعلمين إضافة الصور والملفات الصوتية إلى الأسئلة.",
      category: "exams"
    },
    {
      question: "كيف يتم تقييم الإجابات المقالية؟",
      answer: "يتم تقييم الإجابات المقالية باستخدام مزيج من التقييم الآلي المدعوم بالذكاء الاصطناعي والمراجعة البشرية من قبل المعلمين. يضمن هذا النظام دقة التقييم وموضوعيته.",
      category: "exams"
    },
    {
      question: "هل يمكن للطلاب مراجعة إجاباتهم بعد الاختبار؟",
      answer: "نعم، يمكن للطلاب مراجعة إجاباتهم بعد انتهاء الاختبار إذا سمح المعلم بذلك. تتضمن المراجعة الإجابات الصحيحة والشرح التفصيلي لكل سؤال.",
      category: "exams"
    },
    {
      question: "كيف يمكنني التواصل مع الدعم الفني؟",
      answer: "يمكنك التواصل مع فريق الدعم الفني من خلال عدة قنوات: البريد الإلكتروني، نظام التذاكر داخل المنصة، أو الدردشة المباشرة خلال ساعات العمل.",
      category: "support"
    }
  ];

  const categories = [
    { id: 'general', name: 'عام' },
    { id: 'exams', name: 'الاختبارات' },
    { id: 'support', name: 'الدعم الفني' }
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">الأسئلة الشائعة</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            إجابات على الأسئلة الأكثر شيوعاً حول منصة نور للاختبارات الإلكترونية
          </p>
        </div>

        {/* تصفية حسب الفئة */}
        <div className="flex justify-center gap-4 mb-8">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-4 py-2 rounded-full transition-colors ${
                activeCategory === category.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* قائمة الأسئلة */}
        <div className="max-w-3xl mx-auto space-y-4">
          {faqItems
            .filter(item => item.category === activeCategory)
            .map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-lg shadow-md overflow-hidden"
              >
                <button
                  onClick={() => setActiveIndex(activeIndex === index ? null : index)}
                  className="w-full px-6 py-4 text-right flex items-center justify-between"
                >
                  <span className="font-medium">{item.question}</span>
                  <svg
                    className={`w-5 h-5 transition-transform ${
                      activeIndex === index ? 'transform rotate-180' : ''
                    }`}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>
                {activeIndex === index && (
                  <div className="px-6 py-4 bg-gray-50 border-t">
                    <p className="text-gray-600">{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
        </div>

        {/* قسم المساعدة الإضافية */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">
            لم تجد إجابة على سؤالك؟
          </p>
          <a
            href="/support"
            className="inline-flex items-center text-blue-600 hover:text-blue-700"
          >
            تواصل مع فريق الدعم
            <svg
              className="w-5 h-5 mr-2"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17 8l4 4m0 0l-4 4m4-4H3"
              />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}