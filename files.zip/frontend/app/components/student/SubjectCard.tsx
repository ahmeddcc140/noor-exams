interface SubjectCardProps {
  subject: {
    id: string;
    name: string;
    teacher: string;
    progress: number;
    lastGrade: number;
    nextExam?: {
      date: string;
      topic: string;
    };
  };
}

export default function SubjectCard({ subject }: SubjectCardProps) {
  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return 'text-green-600';
    if (grade >= 75) return 'text-blue-600';
    if (grade >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-semibold text-lg mb-1">{subject.name}</h3>
          <p className="text-gray-600 text-sm">
            المعلم: {subject.teacher}
          </p>
        </div>
        <div className={`text-2xl font-bold ${getGradeColor(subject.lastGrade)}`}>
          {subject.lastGrade}%
        </div>
      </div>

      <div className="mb-4">
        <div className="flex justify-between text-sm mb-1">
          <span>التقدم</span>
          <span>{subject.progress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className={`${getProgressColor(subject.progress)} h-2 rounded-full transition-all duration-500`}
            style={{ width: `${subject.progress}%` }}
          ></div>
        </div>
      </div>

      {subject.nextExam && (
        <div className="border-t pt-4">
          <div className="text-sm text-gray-600">الاختبار القادم</div>
          <div className="font-medium">{subject.nextExam.topic}</div>
          <div className="text-sm text-blue-600">
            {new Date(subject.nextExam.date).toLocaleDateString('ar-SA')}
          </div>
        </div>
      )}

      <div className="mt-4 flex justify-end">
        <a
          href={`/student/subjects/${subject.id}`}
          className="text-blue-600 hover:text-blue-800 text-sm"
        >
          عرض التفاصيل →
        </a>
      </div>
    </div>
  );
}