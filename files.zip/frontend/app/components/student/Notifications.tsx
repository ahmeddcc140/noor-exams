interface NotificationsProps {
  notifications: {
    id: string;
    type: string;
    message: string;
    date: string;
    read: boolean;
  }[];
  onMarkAsRead: (notificationId: string) => Promise<void>;
}

export default function Notifications({
  notifications,
  onMarkAsRead
}: NotificationsProps) {
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'exam':
        return '📝';
      case 'grade':
        return '📊';
      case 'message':
        return '💬';
      case 'reminder':
        return '⏰';
      default:
        return '📌';
    }
  };

  return (
    <div className="space-y-4">
      {notifications.length === 0 ? (
        <div className="text-center text-gray-500 py-8">
          لا توجد إشعارات جديدة
        </div>
      ) : (
        notifications.map((notification) => (
          <div
            key={notification.id}
            className={`flex items-start gap-4 p-4 rounded-lg transition-colors ${
              notification.read ? 'bg-gray-50' : 'bg-blue-50'
            }`}
          >
            <div className="text-2xl">
              {getNotificationIcon(notification.type)}
            </div>
            <div className="flex-1">
              <div className="text-sm">
                {notification.message}
              </div>
              <div className="text-xs text-gray-500 mt-1">
                {new Date(notification.date).toLocaleString('ar-SA')}
              </div>
            </div>
            {!notification.read && (
              <button
                onClick={() => onMarkAsRead(notification.id)}
                className="text-blue-600 hover:text-blue-800 text-sm"
              >
                تم
              </button>
            )}
          </div>
        ))
      )}
    </div>
  );
}