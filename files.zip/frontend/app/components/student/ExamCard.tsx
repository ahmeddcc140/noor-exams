interface ExamCardProps {
  exam: {
    id: string;
    title: string;
    subject: string;
    startDate: string;
    endDate: string;
    duration: number;
    status: 'upcoming' | 'in_progress' | 'completed';
    score?: number;
    questions: number;
    totalPoints: number;
    allowReview: boolean;
  };
  onStartExam: () => void;
}

export default function ExamCard({ exam, onStartExam }: ExamCardProps) {
  const getStatusBadge = () => {
    const styles = {
      upcoming: 'bg-yellow-100 text-yellow-800',
      in_progress: 'bg-green-100 text-green-800',
      completed: 'bg-blue-100 text-blue-800'
    };

    const labels = {
      upcoming: 'قادم',
      in_progress: 'جارٍ',
      completed: 'مكتمل'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[exam.status]}`}>
        {labels[exam.status]}
      </span>
    );
  };

  const isExamAvailable = () => {
    const now = new Date();
    const startDate = new Date(exam.startDate);
    const endDate = new Date(exam.endDate);
    return now >= startDate && now <= endDate;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-semibold text-lg mb-1">{exam.title}</h3>
          <p className="text-gray-600 text-sm">{exam.subject}</p>
        </div>
        {getStatusBadge()}
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">تاريخ البدء:</span>
          <span>{new Date(exam.startDate).toLocaleDateString('ar-SA')}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">المدة:</span>
          <span>{exam.duration} دقيقة</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">عدد الأسئلة:</span>
          <span>{exam.questions}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">الدرجة الكلية:</span>
          <span>{exam.totalPoints} نقطة</span>
        </div>
      </div>

      {exam.status === 'completed' && (
        <div className="mb-4 text-center">
          <div className="text-2xl font-bold text-blue-600">
            {exam.score}%
          </div>
          <div className="text-sm text-gray-600">درجتك في الاختبار</div>
        </div>
      )}

      <div className="flex justify-end gap-2">
        {exam.status === 'upcoming' && isExamAvailable() && (
          <button
            onClick={onStartExam}
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
          >
            بدء الاختبار
          </button>
        )}

        {exam.status === 'completed' && exam.allowReview && (
          <a
            href={`/student/exams/${exam.id}/review`}
            className="text-blue-600 hover:text-blue-800"
          >
            مراجعة الإجابات
          </a>
        )}

        <a
          href={`/student/exams/${exam.id}/details`}
          className="text-gray-600 hover:text-gray-800"
        >
          التفاصيل
        </a>
      </div>
    </div>
  );
}