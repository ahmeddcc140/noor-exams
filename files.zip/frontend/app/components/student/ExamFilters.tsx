interface ExamFiltersProps {
  filters: {
    status: string;
    subject: string;
    date: string;
  };
  onFilterChange: (filters: any) => void;
}

export default function ExamFilters({
  filters,
  onFilterChange
}: ExamFiltersProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md mb-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <select
          value={filters.subject}
          onChange={(e) => onFilterChange({ ...filters, subject: e.target.value })}
          className="w-full px-3 py-2 border rounded-md"
        >
          <option value="all">جميع المواد</option>
          <option value="math">الرياضيات</option>
          <option value="science">العلوم</option>
          <option value="arabic">اللغة العربية</option>
          <option value="english">اللغة الإنجليزية</option>
        </select>

        <select
          value={filters.status}
          onChange={(e) => onFilterChange({ ...filters, status: e.target.value })}
          className="w-full px-3 py-2 border rounded-md"
        >
          <option value="all">جميع الحالات</option>
          <option value="upcoming">القادمة</option>
          <option value="in_progress">جارية</option>
          <option value="completed">مكتملة</option>
        </select>

        <select
          value={filters.date}
          onChange={(e) => onFilterChange({ ...filters, date: e.target.value })}
          className="w-full px-3 py-2 border rounded-md"
        >
          <option value="all">جميع التواريخ</option>
          <option value="today">اليوم</option>
          <option value="week">هذا الأسبوع</option>
          <option value="month">هذا الشهر</option>
        </select>
      </div>
    </div>
  );
}