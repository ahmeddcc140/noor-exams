interface ResourceCardProps {
  resource: {
    id: string;
    title: string;
    description: string;
    type: 'pdf' | 'video' | 'presentation' | 'worksheet';
    subject: string;
    topic: string;
    uploadedBy: {
      name: string;
      role: string;
    };
    uploadDate: string;
    size: number;
    duration?: number;
    thumbnailUrl?: string;
    downloadCount: number;
    rating: number;
  };
  onDownload: () => void;
  onRate: (rating: number) => void;
}

export default function ResourceCard({
  resource,
  onDownload,
  onRate
}: ResourceCardProps) {
  const getTypeIcon = () => {
    switch (resource.type) {
      case 'pdf':
        return '📄';
      case 'video':
        return '🎥';
      case 'presentation':
        return '📊';
      case 'worksheet':
        return '📝';
      default:
        return '📁';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
      {resource.thumbnailUrl && (
        <div className="relative h-48 rounded-t-lg overflow-hidden">
          <img
            src={resource.thumbnailUrl}
            alt={resource.title}
            className="w-full h-full object-cover"
          />
          {resource.type === 'video' && resource.duration && (
            <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-sm">
              {formatDuration(resource.duration)}
            </div>
          )}
        </div>
      )}

      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="font-semibold text-lg mb-1">{resource.title}</h3>
            <p className="text-gray-600 text-sm">{resource.subject} • {resource.topic}</p>
          </div>
          <span className="text-2xl">{getTypeIcon()}</span>
        </div>

        <p className="text-gray-700 text-sm mb-4 line-clamp-2">
          {resource.description}
        </p>

        <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
          <div>
            {formatFileSize(resource.size)} • {resource.downloadCount} تحميل
          </div>
          <div>
            {new Date(resource.uploadDate).toLocaleDateString('ar-SA')}
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => onRate(star)}
                className={`text-2xl ${
                  star <= resource.rating ? 'text-yellow-400' : 'text-gray-300'
                }`}
              >
                ★
              </button>
            ))}
          </div>

          <button
            onClick={onDownload}
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
          >
            تحميل
          </button>
        </div>

        <div className="mt-4 text-sm text-gray-500 text-center">
          تم الرفع بواسطة {resource.uploadedBy.name}
        </div>
      </div>
    </div>
  );
}