interface ResourceFiltersProps {
  filters: {
    type: string;
    subject: string;
    topic: string;
    sortBy: string;
  };
  onFilterChange: (filters: any) => void;
}

export default function ResourceFilters({
  filters,
  onFilterChange
}: ResourceFiltersProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md mb-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <select
          value={filters.type}
          onChange={(e) => onFilterChange({ ...filters, type: e.target.value })}
          className="w-full px-3 py-2 border rounded-md"
        >
          <option value="all">جميع الأنواع</option>
          <option value="pdf">ملفات PDF</option>
          <option value="video">فيديوهات</option>
          <option value="presentation">عروض تقديمية</option>
          <option value="worksheet">أوراق عمل</option>
        </select>

        <select
          value={filters.subject}
          onChange={(e) => onFilterChange({ ...filters, subject: e.target.value })}
          className="w-full px-3 py-2 border rounded-md"
        >
          <option value="all">جميع المواد</option>
          <option value="math">الرياضيات</option>
          <option value="science">العلوم</option>
          <option value="arabic">اللغة العربية</option>
          <option value="english">اللغة الإنجليزية</option>
        </select>

        <input
          type="text"
          placeholder="الموضوع..."
          value={filters.topic}
          onChange={(e) => onFilterChange({ ...filters, topic: e.target.value })}
          className="w-full px-3 py-2 border rounded-md"
        />

        <select
          value={filters.sortBy}
          onChange={(e) => onFilterChange({ ...filters, sortBy: e.target.value })}
          className="w-full px-3 py-2 border rounded-md"
        >
          <option value="date">الأحدث</option>
          <option value="rating">الأعلى تقييماً</option>
          <option value="downloads">الأكثر تحميلاً</option>
          <option value="title">الأبجدية</option>
        </select>
      </div>
    </div>
  );
}