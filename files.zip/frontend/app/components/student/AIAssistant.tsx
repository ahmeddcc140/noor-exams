'use client';

import { useState } from 'react';
import axios from 'axios';

interface AIAssistantProps {
  onClose: () => void;
  studentStats: any;
}

export default function AIAssistant({
  onClose,
  studentStats
}: AIAssistantProps) {
  const [message, setMessage] = useState('');
  const [conversation, setConversation] = useState<{
    role: 'user' | 'assistant';
    content: string;
  }[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const userMessage = message;
    setMessage('');
    setConversation(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const response = await axios.post('/api/student/ai-assistant', {
        message: userMessage,
        context: studentStats,
        conversation: conversation
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });

      setConversation(prev => [...prev, { role: 'assistant', content: response.data.message }]);
    } catch (error) {
      console.error('Error getting AI response:', error);
      setConversation(prev => [...prev, {
        role: 'assistant',
        content: 'عذراً، حدث خطأ. يرجى المحاولة مرة أخرى.'
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[80vh] flex flex-col">
        {/* رأس النافذة */}
        <div className="p-4 border-b flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🤖</span>
            <h3 className="font-semibold">المساعد الدراسي الذكي</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ✕
          </button>
        </div>

        {/* محتوى المحادثة */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* رسالة الترحيب */}
          {conversation.length === 0 && (
            <div className="text-center text-gray-500">
              <p>مرحباً! أنا مساعدك الدراسي الذكي.</p>
              <p>يمكنني مساعدتك في:</p>
              <ul className="mt-2 space-y-1">
                <li>• تحليل أدائك وتقديم توصيات للتحسين</li>
                <li>• الإجابة عن أسئلتك حول المواد الدراسية</li>
                <li>• تقديم نصائح للمذاكرة والتحضير للاختبارات</li>
                <li>• مساعدتك في فهم المفاهيم الصعبة</li>
              </ul>
            </div>
          )}

          {/* المحادثة */}
          {conversation.map((msg, index) => (
            <div
              key={index}
              className={`flex ${
                msg.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  msg.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}

          {/* مؤشر التحميل */}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-lg p-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* نموذج إرسال الرسالة */}
        <form onSubmit={handleSubmit} className="p-4 border-t">
          <div className="flex gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="اكتب سؤالك هنا..."
              className="flex-1 px-4 py-2 border rounded-full focus:outline-none focus:border-blue-500"
              disabled={loading}
            />
            