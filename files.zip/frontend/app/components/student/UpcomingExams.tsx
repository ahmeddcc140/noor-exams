interface UpcomingExamsProps {
  exams: {
    id: string;
    subject: string;
    title: string;
    date: string;
    duration: number;
    preparationStatus: 'not_started' | 'in_progress' | 'ready';
  }[];
}

export default function UpcomingExams({ exams }: UpcomingExamsProps) {
  const getStatusBadge = (status: string) => {
    const styles = {
      not_started: 'bg-red-100 text-red-800',
      in_progress: 'bg-yellow-100 text-yellow-800',
      ready: 'bg-green-100 text-green-800'
    };

    const labels = {
      not_started: 'لم تبدأ',
      in_progress: 'قيد التحضير',
      ready: 'جاهز'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status]}`}>
        {labels[status]}
      </span>
    );
  };

  const getDaysRemaining = (date: string) => {
    const examDate = new Date(date);
    const today = new Date();
    const diffTime = examDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'اليوم';
    if (diffDays === 1) return 'غداً';
    return `${diffDays} يوم`;
  };

  return (
    <div className="space-y-4">
      {exams.length === 0 ? (
        <div className="text-center text-gray-500 py-8">
          لا توجد اختبارات قادمة حالياً
        </div>
      ) : (
        exams.map((exam) => (
          <div
            key={exam.id}
            className="border rounded-lg p-4 hover:border-blue-500 transition-colors"
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className="font-medium">{exam.title}</h4>
                <p className="text-sm text-gray-600">{exam.subject}</p>
              </div>
              {getStatusBadge(exam.preparationStatus)}
            </div>

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <span className="text-gray-600">
                  {new Date(exam.date).toLocaleDateString('ar-SA')}
                </span>
                <span className="text-gray-600">
                  {exam.duration} دقيقة
                </span>
              </div>
              <div className="text-blue-600 font-medium">
                متبقي: {getDaysRemaining(exam.date)}
              </div>
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <a
                href={`/student/exams/${exam.id}/prepare`}
                className="text-blue-600 hover:text-blue-800 text-sm"
              >
                تحضير →
              </a>
              <span className="text-gray-300">|</span>
              <a
                href={`/student/exams/${exam.id}/details`}
                className="text-gray-600 hover:text-gray-800 text-sm"
              >
                التفاصيل
              </a>
            </div>
          </div>
        ))
      )}
    </div>
  );
}