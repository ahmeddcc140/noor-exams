'use client';

import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface PerformanceChartProps {
  overall: number;
  bySubject: {
    subject: string;
    average: number;
  }[];
  trend: {
    date: string;
    score: number;
  }[];
}

export default function PerformanceChart({
  overall,
  bySubject,
  trend
}: PerformanceChartProps) {
  // تكوين بيانات مخطط التقدم
  const trendData = {
    labels: trend.map(t => new Date(t.date).toLocaleDateString('ar-SA')),
    datasets: [
      {
        label: 'متوسط الدرجات',
        data: trend.map(t => t.score),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.4
      }
    ]
  };

  // تكوين بيانات مخطط المواد
  const subjectsData = {
    labels: bySubject.map(s => s.subject),
    datasets: [
      {
        label: 'متوسط الدرجات لكل مادة',
        data: bySubject.map(s => s.average),
        backgroundColor: [
          'rgba(59, 130, 246, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(139, 92, 246, 0.8)'
        ]
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        rtl: true,
        labels: {
          font: {
            family: 'Cairo'
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: {
          callback: (value: number) => `${value}%`
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* المتوسط العام */}
      <div className="text-center mb-6">
        <div className="text-sm text-gray-600 mb-1">المتوسط العام</div>
        <div className="text-3xl font-bold text-blue-600">{overall}%</div>
      </div>

      {/* مخطط التقدم */}
      <div className="h-64 mb-8">
        <h3 className="text-sm font-medium text-gray-600 mb-2">تقدم الأداء</h3>
        <Line data={trendData} options={options} />
      </div>

      {/* مخطط المواد */}
      <div className="h-64">
        <h3 className="text-sm font-medium text-gray-600 mb-2">الأداء حسب المادة</h3>
        <Bar data={subjectsData} options={options} />
      </div>
    </div>
  );
}