interface QuestionViewProps {
  question: {
    id: string;
    type: 'mcq' | 'essay' | 'true_false';
    text: string;
    options?: string[];
    points: number;
  };
  answer: string;
  onAnswer: (answer: string) => void;
}

export default function QuestionView({
  question,
  answer,
  onAnswer
}: QuestionViewProps) {
  const renderAnswerInput = () => {
    switch (question.type) {
      case 'mcq':
        return (
          <div className="space-y-2">
            {question.options?.map((option, index) => (
              <label
                key={index}
                className={`block p-4 rounded-lg border cursor-pointer
                  ${answer === option ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-200'}
                `}
              >
                <input
                  type="radio"
                  name={`question-${question.id}`}
                  value={option}
                  checked={answer === option}
                  onChange={(e) => onAnswer(e.target.value)}
                  className="hidden"
                />
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full border flex items-center justify-center
                    ${answer === option ? 'border-blue-500 bg-blue-500' : 'border-gray-300'}
                  `}>
                    {answer === option && (
                      <div className="w-3 h-3 rounded-full bg-white" />
                    )}
                  </div>
                  <span>{option}</span>
                </div>
              </label>
            ))}
          </div>
        );

      case 'true_false':
        return (
          <div className="flex gap-4">
            <label className={`flex-1 p-4 rounded-lg border cursor-pointer text-center
              ${answer === 'true' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-200'}
            `}>
              <input
                type="radio"
                name={`question-${question.id}`}
                value="true"
                checked={answer === 'true'}
                onChange={(e) => onAnswer(e.target.value)}
                className="hidden"
              />
              صح
            </label>
            <label className={`flex-1 p-4 rounded-lg border cursor-pointer text-center
              ${answer === 'false' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-200'}
            `}>
              <input
                type="radio"
                name={`question-${question.id}`}
                value="false"
                checked={answer === 'false'}
                onChange={(e) => onAnswer(e.target.value)}
                className="hidden"
              />
              خطأ
            </label>
          </div>
        );

      case 'essay':
        return (
          <textarea
            value={answer || ''}
            onChange={(e) => onAnswer(e.target.value)}
            className="w-full h-32 p-4 border rounded-lg resize-none focus:outline-none focus:border-blue-500"
            placeholder="اكتب إجابتك هنا..."
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-start mb-6">
        <div className="flex-1">
          <div className="text-lg font-medium mb-2">
            {question.text}
          </div>
          <div className="text-sm text-gray-600">
            {question.points} نقطة
          </div>
        </div>
        <div className="text-sm text-gray-500">
          {
            question.type === 'mcq' ? 'اختيار من متعدد' :
            question.type === 'true_false' ? 'صح أم خطأ' :
            'سؤال مقالي'
          }
        </div>
      </div>

      {renderAnswerInput()}
    </div>
  );
}