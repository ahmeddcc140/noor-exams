'use client';

import { useState } from 'react';
import Link from 'next/link';
import LoginModal from '@/components/auth/LoginModal';

interface NavbarProps {
  onRegisterClick: () => void;
}

export default function Navbar({ onRegisterClick }: NavbarProps) {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  return (
    <nav className="bg-white shadow-md fixed w-full top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* الشعار */}
          <Link href="/" className="flex items-center gap-2">
            <img src="/logo.svg" alt="نور" className="h-8 w-auto" />
            <span className="text-xl font-bold text-blue-600">نور</span>
          </Link>

          {/* القائمة الرئيسية - سطح المكتب */}
          <div className="hidden md:flex items-center gap-6">
            <div className="flex gap-4">
              <Link 
                href="/student/dashboard" 
                className="text-gray-600 hover:text-blue-600"
              >
                لوحة تحكم الطلاب
              </Link>
              <Link 
                href="/teacher/dashboard" 
                className="text-gray-600 hover:text-blue-600"
              >
                لوحة تحكم المعلمين
              </Link>
              <Link 
                href="/admin/dashboard" 
                className="text-gray-600 hover:text-blue-600"
              >
                لوحة تحكم الإدارة
              </Link>
              <Link 
                href="/library" 
                className="text-gray-600 hover:text-blue-600"
              >
                المكتبة التعليمية
              </Link>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowLoginModal(true)}
                className="px-4 py-2 text-blue-600 hover:text-blue-800"
              >
                تسجيل الدخول
              </button>
              <button
                onClick={onRegisterClick}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                إنشاء حساب
              </button>
            </div>
          </div>

          {/* زر القائمة المتنقلة */}
          <button
            className="md:hidden p-2"
            onClick={() => setShowMobileMenu(!showMobileMenu)}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              {showMobileMenu ? (
                <path d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* القائمة المتنقلة */}
        {showMobileMenu && (
          <div className="md:hidden py-4 border-t">
            <div className="space-y-4">
              <Link 
                href="/student/dashboard" 
                className="block px-4 py-2 text-gray-600 hover:bg-gray-50"
              >
                لوحة تحكم الطلاب
              </Link>
              <Link 
                href="/teacher/dashboard" 
                className="block px-4 py-2 text-gray-600 hover:bg-gray-50"
              >
                لوحة تحكم المعلمين
              </Link>
              <Link 
                href="/admin/dashboard" 
                className="block px-4 py-2 text-gray-600 hover:bg-gray-50"
              >
                لوحة تحكم الإدارة
              </Link>
              <Link 
                href="/library" 
                className="block px-4 py-2 text-gray-600 hover:bg-gray-50"
              >
                المكتبة التعليمية
              </Link>
              <div className="border-t pt-4">
                <button
                  onClick={() => setShowLoginModal(true)}
                  className="block w-full px-4 py-2 text-blue-600 hover:bg-blue-50"
                >
                  تسجيل الدخول
                </button>
                <button
                  onClick={onRegisterClick}
                  className="block w-full px-4 py-2 mt-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  إنشاء حساب
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {showLoginModal && (
        <LoginModal onClose={() => setShowLoginModal(false)} />
      )}
    </nav>
  );
}