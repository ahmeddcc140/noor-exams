'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface SupervisorForm {
  fullName: string;
  phoneNumber: string;
  email: string;
}

export default function AddSupervisor() {
  const router = useRouter();
  const [form, setForm] = useState<SupervisorForm>({
    fullName: '',
    phoneNumber: '',
    email: ''
  });
  const [errors, setErrors] = useState<Partial<SupervisorForm>>({});
  const [generatedData, setGeneratedData] = useState({
    supervisorCode: '',
    password: ''
  });
  const [isSuccess, setIsSuccess] = useState(false);

  const validateForm = (): boolean => {
    const newErrors: Partial<SupervisorForm> = {};

    if (!form.fullName) {
      newErrors.fullName = 'اسم المشرف مطلوب';
    }

    if (!/^[0-9]{11,}$/.test(form.phoneNumber)) {
      newErrors.phoneNumber = 'رقم الهاتف يجب أن يتكون من 11 رقم على الأقل';
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'البريد الإلكتروني غير صالح';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const response = await axios.post('/api/supervisors', form, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });

      setGeneratedData({
        supervisorCode: response.data.supervisorCode,
        password: response.data.password
      });
      setIsSuccess(true);
    } catch (error) {
      console.error('Error adding supervisor:', error);
      setErrors({
        ...errors,
        submit: 'حدث خطأ أثناء إضافة المشرف'
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 className="text-2xl font-bold mb-6 text-center">إضافة مشرف جديد</h1>

        {isSuccess ? (
          <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
            <h2 className="text-xl font-semibold text-green-800 mb-4">
              تم إضافة المشرف بنجاح!
            </h2>
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-md">
                <p className="font-medium">كود المشرف:</p>
                <p className="text-lg">{generatedData.supervisorCode}</p>
              </div>
              <div className="bg-white p-4 rounded-md">
                <p className="font-medium">كلمة المرور:</p>
                <p className="text-lg">{generatedData.password}</p>
              </div>
              <button
                onClick={() => router.push('/admin/supervisors')}
                className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
              >
                العودة لقائمة المشرفين
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* اسم المشرف */}
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                اسم المشرف
              </label>
              <input
                type="text"
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                required
              />
              {errors.fullName && (
                <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>
              )}
            </div>

            {/* رقم الهاتف */}
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                رقم الهاتف
              </label>
              <input
                type="tel"
                value={form.phoneNumber}
                onChange={(e) => setForm({ ...form, phoneNumber: e.target.value })}
                className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                required
                pattern="[0-9]{11,}"
              />
              {errors.phoneNumber && (
                <p className="text-red-500 text-sm mt-1">{errors.phoneNumber}</p>
              )}
            </div>

            {/* البريد الإلكتروني */}
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
                required
              />
              {errors.email && (
                <p className="text-red-500 text-sm mt-1">{errors.email}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
            >
              إضافة المشرف
            </button>
          </form>
        )}
      </div>
    </div>
  );
}