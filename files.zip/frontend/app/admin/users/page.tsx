'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import UserForm from '@/components/admin/UserForm';
import UserTable from '@/components/admin/UserTable';
import RoleManager from '@/components/admin/RoleManager';
import UserActivityLog from '@/components/admin/UserActivityLog';

interface User {
  id: string;
  fullName: string;
  email: string;
  type: 'student' | 'teacher' | 'admin' | 'parent';
  status: 'active' | 'inactive';
  createdAt: string;
  lastLogin: string;
  roles: string[];
}

export default function UsersManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [filter, setFilter] = useState({
    type: '',
    status: '',
    search: ''
  });

  useEffect(() => {
    fetchUsers();
  }, [filter]);

  const fetchUsers = async () => {
    try {
      const queryParams = new URLSearchParams({
        type: filter.type,
        status: filter.status,
        search: filter.search
      });

      const response = await axios.get(`/api/admin/users?${queryParams}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = async (userData: any) => {
    try {
      await axios.post('/api/admin/users', userData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      fetchUsers();
      setShowForm(false);
    } catch (error) {
      console.error('Error adding user:', error);
    }
  };

  const handleUpdateUser = async (userId: string, userData: any) => {
    try {
      await axios.put(`/api/admin/users/${userId}`, userData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      fetchUsers();
      setSelectedUser(null);
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المستخدم؟')) return;

    try {
      await axios.delete(`/api/admin/users/${userId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleUpdateRoles = async (userId: string, roles: string[]) => {
    try {
      await axios.put(`/api/admin/users/${userId}/roles`, { roles }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      fetchUsers();
    } catch (error) {
      console.error('Error updating roles:', error);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">إدارة المستخدمين</h1>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
        >
          إضافة مستخدم جديد
        </button>
      </div>

      {/* فلترة المستخدمين */}
      <div className="bg-white p-4 rounded-lg shadow-md mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select
            value={filter.type}
            onChange={(e) => setFilter({ ...filter, type: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">جميع أنواع المستخدمين</option>
            <option value="student">طالب</option>
            <option value="teacher">معلم</option>
            <option value="admin">مشرف</option>
            <option value="parent">ولي أمر</option>
          </select>

          <select
            value={filter.status}
            onChange={(e) => setFilter({ ...filter, status: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">جميع الحالات</option>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </select>

          <input
            type="text"
            placeholder="بحث..."
            value={filter.search}
            onChange={(e) => setFilter({ ...filter, search: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>
      </div>

      {/* جدول المستخدمين */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <UserTable
          users={users}
          onEdit={setSelectedUser}
          onDelete={handleDeleteUser}
          onUpdateRoles={handleUpdateRoles}
        />
      )}

      {/* نموذج إضافة/تعديل مستخدم */}
      {(showForm || selectedUser) && (
        <UserForm
          user={selectedUser}
          onSubmit={selectedUser ? handleUpdateUser : handleAddUser}
          onClose={() => {
            setShowForm(false);
            setSelectedUser(null);
          }}
        />
      )}

      {/* إدارة الأدوار */}
      {selectedUser && (
        <RoleManager
          userId={selectedUser.id}
          currentRoles={selectedUser.roles}
          onUpdate={handleUpdateRoles}
        />
      )}

      {/* سجل النشاط */}
      {selectedUser && (
        <UserActivityLog userId={selectedUser.id} />
      )}
    </div>
  );
}