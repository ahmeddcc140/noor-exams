'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import ExamTable from '@/components/admin/ExamTable';
import ExamReviewModal from '@/components/admin/ExamReviewModal';
import ExamStatistics from '@/components/admin/ExamStatistics';
import { toast } from 'react-hot-toast';

interface Exam {
  id: string;
  title: string;
  subject: string;
  grade: string;
  teacher: {
    id: string;
    name: string;
  };
  status: 'draft' | 'pending' | 'approved' | 'active' | 'completed';
  startDate: string;
  duration: number;
  questionsCount: number;
  submissionsCount: number;
  averageScore: number;
  createdAt: string;
}

export default function ExamsManagement() {
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [filters, setFilters] = useState({
    status: '',
    subject: '',
    grade: '',
    dateRange: 'all'
  });

  useEffect(() => {
    fetchExams();
  }, [filters]);

  const fetchExams = async () => {
    try {
      const queryParams = new URLSearchParams(filters);
      const response = await axios.get(`/api/admin/exams?${queryParams}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setExams(response.data);
    } catch (error) {
      console.error('Error fetching exams:', error);
      toast.error('حدث خطأ أثناء جلب بيانات الاختبارات');
    } finally {
      setLoading(false);
    }
  };

  const handleApproveExam = async (examId: string) => {
    try {
      await axios.post(`/api/admin/exams/${examId}/approve`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('تم اعتماد الاختبار بنجاح');
      fetchExams();
    } catch (error) {
      console.error('Error approving exam:', error);
      toast.error('حدث خطأ أثناء اعتماد الاختبار');
    }
  };

  const handleRejectExam = async (examId: string, reason: string) => {
    try {
      await axios.post(`/api/admin/exams/${examId}/reject`, { reason }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('تم رفض الاختبار وإرسال السبب للمعلم');
      fetchExams();
    } catch (error) {
      console.error('Error rejecting exam:', error);
      toast.error('حدث خطأ أثناء رفض الاختبار');
    }
  };

  const handleDeleteExam = async (examId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الاختبار؟')) return;

    try {
      await axios.delete(`/api/admin/exams/${examId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('تم حذف الاختبار بنجاح');
      fetchExams();
    } catch (error) {
      console.error('Error deleting exam:', error);
      toast.error('حدث خطأ أثناء حذف الاختبار');
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">إدارة الاختبارات</h1>
        <div className="flex gap-4">
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            className="px-3 py-2 border rounded-md"
          >
            <option value="">جميع الحالات</option>
            <option value="pending">في انتظار المراجعة</option>
            <option value="approved">معتمد</option>
            <option value="active">نشط</option>
            <option value="completed">مكتمل</option>
          </select>

          <select
            value={filters.dateRange}
            onChange={(e) => setFilters({ ...filters, dateRange: e.target.value })}
            className="px-3 py-2 border rounded-md"
          >
            <option value="all">جميع الفترات</option>
            <option value="today">اليوم</option>
            <option value="week">هذا الأسبوع</option>
            <option value="month">هذا الشهر</option>
          </select>
        </div>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white p-4 rounded-lg shadow-md">
          <div className="text-sm text-gray-600">إجمالي الاختبارات</div>
          <div className="text-2xl font-bold">{exams.length}</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-md">
          <div className="text-sm text-gray-600">في انتظار المراجعة</div>
          <div className="text-2xl font-bold text-yellow-600">
            {exams.filter(e => e.status === 'pending').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-md">
          <div className="text-sm text-gray-600">نشط حالياً</div>
          <div className="text-2xl font-bold text-green-600">
            {exams.filter(e => e.status === 'active').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-md">
          <div className="text-sm text-gray-600">متوسط الدرجات</div>
          <div className="text-2xl font-bold text-blue-600">
            {Math.round(exams.reduce((acc, e) => acc + e.averageScore, 0) / exams.length || 0)}%
          </div>
        </div>
      </div>

      {/* جدول الاختبارات */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <ExamTable
          exams={exams}
          onReview={(exam) => {
            setSelectedExam(exam);
            setShowReviewModal(true);
          }}
          onApprove={handleApproveExam}
          onReject={handleRejectExam}
          onDelete={handleDeleteExam}
        />
      )}

      {/* نافذة مراجعة الاختبار */}
      {showReviewModal && selectedExam && (
        <ExamReviewModal
          exam={selectedExam}
          onClose={() => {
            setShowReviewModal(false);
            setSelectedExam(null);
          }}
          onApprove={handleApproveExam}
          onReject={handleRejectExam}
        />
      )}

      {/* إحصائيات الاختبارات */}
      {selectedExam && (
        <ExamStatistics examId={selectedExam.id} />
      )}
    </div>
  );
}