'use client';

import { useState, useEffect } from 'react';
import { Chart } from 'react-chartjs-2';
import axios from 'axios';
import StatisticCard from '@/components/admin/StatisticCard';
import DashboardChart from '@/components/admin/DashboardChart';
import RecentActivities from '@/components/admin/RecentActivities';

interface DashboardStats {
  students: {
    total: number;
    active: number;
    new: number;
  };
  teachers: {
    total: number;
    active: number;
  };
  exams: {
    total: number;
    completed: number;
    pending: number;
  };
  performance: {
    passRate: number;
    failRate: number;
    averageScore: number;
  };
  activities: {
    id: string;
    type: string;
    description: string;
    user: string;
    timestamp: string;
  }[];
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('week'); // week, month, year

  useEffect(() => {
    fetchDashboardStats();
  }, [dateRange]);

  const fetchDashboardStats = async () => {
    try {
      const response = await axios.get(`/api/admin/dashboard/stats?range=${dateRange}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !stats) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">لوحة التحكم</h1>
        <p className="text-gray-600">
          مرحباً بك في لوحة تحكم النظام - {new Date().toLocaleDateString('ar-SA')}
        </p>
      </div>

      {/* الإحصائيات العامة */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatisticCard
          title="إجمالي الطلاب"
          value={stats.students.total}
          change={stats.students.new}
          icon="👥"
          type="primary"
        />
        <StatisticCard
          title="المعلمين النشطين"
          value={stats.teachers.active}
          total={stats.teachers.total}
          icon="👨‍🏫"
          type="success"
        />
        <StatisticCard
          title="الاختبارات"
          value={stats.exams.completed}
          total={stats.exams.total}
          pending={stats.exams.pending}
          icon="📝"
          type="warning"
        />
        <StatisticCard
          title="نسبة النجاح"
          value={stats.performance.passRate}
          change={stats.performance.averageScore - 70}
          icon="📊"
          type="info"
          isPercentage
        />
      </div>

      {/* الرسوم البيانية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">أداء الطلاب</h2>
          <DashboardChart
            type="line"
            data={{
              labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو'],
              datasets: [
                {
                  label: 'متوسط الدرجات',
                  data: [65, 70, 75, 72, 78, 80],
                  borderColor: 'rgb(59, 130, 246)',
                  tension: 0.1
                }
              ]
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true,
                  max: 100
                }
              }
            }}
          />
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">توزيع الدرجات</h2>
          <DashboardChart
            type="doughnut"
            data={{
              labels: ['ممتاز', 'جيد جداً', 'جيد', 'مقبول', 'راسب'],
              datasets: [
                {
                  data: [30, 25, 20, 15, 10],
                  backgroundColor: [
                    '#10B981',
                    '#3B82F6',
                    '#F59E0B',
                    '#6B7280',
                    '#EF4444'
                  ]
                }
              ]
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false
            }}
          />
        </div>
      </div>

      {/* النشاطات الأخيرة */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-4">النشاطات الأخيرة</h2>
        <RecentActivities activities={stats.activities} />
      </div>
    </div>
  );
}