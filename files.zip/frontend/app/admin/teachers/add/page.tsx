'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface Subject {
  _id: string;
  name: string;
}

interface TeacherForm {
  fullName: string;
  phoneNumber: string;
  email: string;
  subject: string;
  educationalLevels: string[];
}

export default function AddTeacher() {
  const router = useRouter();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [form, setForm] = useState<TeacherForm>({
    fullName: '',
    phoneNumber: '',
    email: '',
    subject: '',
    educationalLevels: []
  });
  const [errors, setErrors] = useState<Partial<TeacherForm>>({});
  const [generatedData, setGeneratedData] = useState({
    teacherCode: '',
    password: ''
  });

  useEffect(() => {
    fetchSubjects();
  }, []);

  const fetchSubjects = async () => {
    try {
      const response = await axios.get('/api/subjects', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      setSubjects(response.data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<TeacherForm> = {};

    if (!form.fullName) {
      newErrors.fullName = 'اسم المعلم مطلوب';
    }

    if (!/^[0-9]{11,}$/.test(form.phoneNumber)) {
      newErrors.phoneNumber = 'رقم الهاتف يجب أن يتكون من 11 رقم على الأقل';
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'البريد الإلكتروني غير صالح';
    }

    if (!form.subject) {
      newErrors.subject = 'مادة التخصص مطلوبة';
    }

    if (form.educationalLevels.length === 0) {
      newErrors.educationalLevels = 'يجب اختيار مرحلة تعليمية واحدة على الأقل';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const response = await axios.post('/api/teachers', form, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });

      setGeneratedData({
        teacherCode: response.data.teacherCode,
        password: response.data.password
      });

      // عرض النافذة المنبثقة مع البيانات المولدة
      alert(`
        تم إضافة المعلم بنجاح!
        كود المعلم: ${response.data.teacherCode}
        كلمة المرور: ${response.data.password}
        
        يرجى حفظ هذه البيانات في مكان آمن.
      `);

      router.push('/admin/teachers');
    } catch (error) {
      console.error('Error adding teacher:', error);
      setErrors({
        ...errors,
        submit: 'حدث خطأ أثناء إضافة المعلم'
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 className="text-2xl font-bold mb-6 text-center">إضافة معلم جديد</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* اسم المعلم */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">
              اسم المعلم
            </label>
            <input
              type="text"
              value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            />
            {errors.fullName && (
              <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>
            )}
          </div>

          {/* رقم الهاتف */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">
              رقم الهاتف
            </label>
            <input
              type="tel"
              value={form.phoneNumber}
              onChange={(e) => setForm({ ...form, phoneNumber: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
              pattern="[0-9]{11,}"
            />
            {errors.phoneNumber && (
              <p className="text-red-500 text-sm mt-1">{errors.phoneNumber}</p>
            )}
          </div>

          {/* البريد الإلكتروني */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">
              البريد الإلكتروني
            </label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            />
            {errors.email && (
              <p className="text-red-500 text-sm mt-1">{errors.email}</p>
            )}
          </div>

          {/* مادة التخصص */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">
              مادة التخصص
            </label>
            <select
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">اختر المادة</option>
              {subjects.map((subject) => (
                <option key={subject._id} value={subject._id}>
                  {subject.name}
                </option>
              ))}
            </select>
            {errors.subject && (
              <p className="text-red-500 text-sm mt-1">{errors.subject}</p>
            )}
          </div>

          {/* المراحل التعليمية */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">
              المراحل التعليمية
            </label>
            <div className="space-y-2">
              {['primary', 'middle', 'high'].map((level) => (
                <label key={level} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={form.educationalLevels.includes(level)}
                    onChange={(e) => {
                      const levels = e.target.checked
                        ? [...form.educationalLevels, level]
                        : form.educationalLevels.filter((l) => l !== level);
                      setForm({ ...form, educationalLevels: levels });
                    }}
                    className="rounded text-blue-600 focus:ring-blue-500 mr-2"
                  />
                  <span>
                    {level === 'primary' ? 'ابتدائي' : 
                     level === 'middle' ? 'إعدادي' : 'ثانوي'}
                  </span>
                </label>
              ))}
            </div>
            {errors.educationalLevels && (
              <p className="text-red-500 text-sm mt-1">{errors.educationalLevels}</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
          >
            إضافة المعلم
          </button>
        </form>
      </div>
    </div>
  );
}