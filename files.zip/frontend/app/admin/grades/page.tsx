'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';

interface Grade {
  _id: string;
  gradeCode: string;
  name: string;
}

export default function Grades() {
  const [grades, setGrades] = useState<Grade[]>([]);
  const [newGrade, setNewGrade] = useState({ name: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    fetchGrades();
  }, []);

  const fetchGrades = async () => {
    try {
      const response = await axios.get('/api/grades', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setGrades(response.data);
    } catch (error) {
      console.error('Error fetching grades:', error);
      setError('حدث خطأ أثناء جلب الصفوف الدراسية');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/grades', newGrade, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setGrades([...grades, response.data]);
      setNewGrade({ name: '' });
    } catch (error) {
      console.error('Error adding grade:', error);
      setError('حدث خطأ أثناء إضافة الصف الدراسي');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">الصفوف الدراسية</h1>

      <form onSubmit={handleSubmit} className="mb-8 bg-white p-6 rounded-lg shadow-md">
        <div className="flex gap-4">
          <input
            type="text"
            value={newGrade.name}
            onChange={(e) => setNewGrade({ name: e.target.value })}
            placeholder="اسم الصف الدراسي"
            className="flex-1 px-3 py-2 border rounded-md"
            required
          />
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
          >
            إضافة
          </button>
        </div>
        {error && <p className="text-red-500 mt-2">{error}</p>}
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {grades.map((grade) => (
          <div key={grade._id} className="bg-white p-4 rounded-lg shadow-md">
            <div className="font-semibold text-lg mb-2">{grade.name}</div>
            <div className="text-gray-600">الكود: {grade.gradeCode}</div>
          </div>
        ))}
      </div>
    </div>
  );
}