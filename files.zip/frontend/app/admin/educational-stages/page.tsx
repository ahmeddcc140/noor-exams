'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';

interface EducationalStage {
  _id: string;
  stageCode: string;
  name: string;
}

export default function EducationalStages() {
  const [stages, setStages] = useState<EducationalStage[]>([]);
  const [newStage, setNewStage] = useState({ name: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    fetchStages();
  }, []);

  const fetchStages = async () => {
    try {
      const response = await axios.get('/api/educational-stages', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setStages(response.data);
    } catch (error) {
      console.error('Error fetching stages:', error);
      setError('حدث خطأ أثناء جلب المراحل التعليمية');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/educational-stages', newStage, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setStages([...stages, response.data]);
      setNewStage({ name: '' });
    } catch (error) {
      console.error('Error adding stage:', error);
      setError('حدث خطأ أثناء إضافة المرحلة التعليمية');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">المراحل التعليمية</h1>

      {/* نموذج إضافة مرحلة جديدة */}
      <form onSubmit={handleSubmit} className="mb-8 bg-white p-6 rounded-lg shadow-md">
        <div className="flex gap-4">
          <input
            type="text"
            value={newStage.name}
            onChange={(e) => setNewStage({ name: e.target.value })}
            placeholder="اسم المرحلة التعليمية"
            className="flex-1 px-3 py-2 border rounded-md"
            required
          />
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
          >
            إضافة
          </button>
        </div>
        {error && <p className="text-red-500 mt-2">{error}</p>}
      </form>

      {/* عرض المراحل التعليمية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stages.map((stage) => (
          <div key={stage._id} className="bg-white p-4 rounded-lg shadow-md">
            <div className="font-semibold text-lg mb-2">{stage.name}</div>
            <div className="text-gray-600">الكود: {stage.stageCode}</div>
          </div>
        ))}
      </div>
    </div>
  );
}