// ... تكملة الكود السابق
        {error && <p className="text-red-500 mt-2">{error}</p>}
      </form>

      {/* عرض المواد الدراسية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((subject) => (
          <div key={subject._id} className="bg-white p-4 rounded-lg shadow-md">
            <div className="font-semibold text-lg mb-2">{subject.nameAr}</div>
            <div className="text-gray-600 mb-2">
              {subject.nameEn}
            </div>
            <div className="text-gray-500 mb-2">
              الكود: {subject.subjectCode}
            </div>
            <div className="text-sm">
              <h4 className="font-medium mb-1">المراحل التعليمية:</h4>
              <div className="flex flex-wrap gap-1">
                {subject.stages.map((stage) => (
                  <span key={stage._id} className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                    {stage.name}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}