'use client';

import { useState, useEffect } from 'react';
import { Chart } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import axios from 'axios';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface DashboardStats {
  totalStudents: number;
  totalExams: number;
  completedExams: number;
  upcomingExams: {
    _id: string;
    title: string;
    date: string;
    studentsCount: number;
  }[];
  performanceStats: {
    averageScore: number;
    examCompletion: number;
    improvements: number;
  };
}

interface ExamPerformance {
  examTitle: string;
  averageScore: number;
  studentCount: number;
  date: string;
}

export default function TeacherDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [examPerformance, setExamPerformance] = useState<ExamPerformance[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [statsResponse, performanceResponse] = await Promise.all([
        axios.get('/api/teacher/dashboard/stats'),
        axios.get('/api/teacher/dashboard/exam-performance')
      ]);

      setStats(statsResponse.data);
      setExamPerformance(performanceResponse.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">لوحة تحكم المعلم</h1>

      {/* الإحصائيات العامة */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">إجمالي الطلاب</h3>
          <p className="text-3xl font-bold text-blue-600">{stats?.totalStudents}</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">الاختبارات المنشأة</h3>
          <p className="text-3xl font-bold text-green-600">{stats?.totalExams}</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">الاختبارات المكتملة</h3>
          <p className="text-3xl font-bold text-purple-600">{stats?.completedExams}</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">متوسط الأداء</h3>
          <p className="text-3xl font-bold text-orange-600">
            {stats?.performanceStats.averageScore}%
          </p>
        </div>
      </div>

      {/* الاختبارات القادمة */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">الاختبارات القادمة</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-600">
                  عنوان الاختبار
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-600">
                  التاريخ
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-600">
                  عدد الطلاب
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {stats?.upcomingExams.map((exam) => (
                <tr key={exam._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">{exam.title}</td>
                  <td className="px-6 py-4">
                    {new Date(exam.date).toLocaleDateString('ar-SA')}
                  </td>
                  <td className="px-6 py-4">{exam.studentsCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* الرسم البياني لأداء الاختبارات */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">تحليل أداء الاختبارات</h2>
        <div className="h-80">
          <Chart
            type="line"
            data={{
              labels: examPerformance.map(exam => exam.examTitle),
              datasets: [
                {
                  label: 'متوسط الدرجات',
                  data: examPerformance.map(exam => exam.averageScore),
                  borderColor: 'rgb(75, 192, 192)',
                  tension: 0.1
                }
              ]
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true,
                  max: 100
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  );
}