'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';

interface MaterialFile {
  _id: string;
  title: string;
  description: string;
  fileType: 'pdf' | 'video' | 'presentation' | 'document';
  fileUrl: string;
  subject: string;
  grade: string;
  uploadedAt: string;
  downloads: number;
  size: number;
}

export default function TeacherLibrary() {
  const [materials, setMaterials] = useState<MaterialFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadModal, setUploadModal] = useState(false);
  const [filter, setFilter] = useState({
    subject: '',
    grade: '',
    type: ''
  });

  const [newMaterial, setNewMaterial] = useState({
    title: '',
    description: '',
    subject: '',
    grade: '',
    file: null as File | null
  });

  useEffect(() => {
    fetchMaterials();
  }, [filter]);

  const fetchMaterials = async () => {
    try {
      const queryParams = new URLSearchParams(filter);
      const response = await axios.get(`/api/teacher/library?${queryParams}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setMaterials(response.data);
    } catch (error) {
      console.error('Error fetching materials:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMaterial.file) return;

    const formData = new FormData();
    formData.append('title', newMaterial.title);
    formData.append('description', newMaterial.description);
    formData.append('subject', newMaterial.subject);
    formData.append('grade', newMaterial.grade);
    formData.append('file', newMaterial.file);

    try {
      await axios.post('/api/teacher/library', formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'multipart/form-data'
        }
      });

      setUploadModal(false);
      fetchMaterials();
    } catch (error) {
      console.error('Error uploading material:', error);
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return '📄';
      case 'video':
        return '🎥';
      case 'presentation':
        return '📊';
      default:
        return '📝';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">مكتبة المواد التعليمية</h1>
        <button
          onClick={() => setUploadModal(true)}
          className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
        >
          رفع ملف جديد
        </button>
      </div>

      {/* فلترة المواد */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select
            value={filter.subject}
            onChange={(e) => setFilter({ ...filter, subject: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">جميع المواد</option>
            {/* قائمة المواد */}
          </select>

          <select
            value={filter.grade}
            onChange={(e) => setFilter({ ...filter, grade: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">جميع المراحل</option>
            {/* قائمة المراحل */}
          </select>

          <select
            value={filter.type}
            onChange={(e) => setFilter({ ...filter, type: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">جميع أنواع الملفات</option>
            <option value="pdf">PDF</option>
            <option value="video">فيديو</option>
            <option value="presentation">عرض تقديمي</option>
            <option value="document">مستند</option>
          </select>
        </div>
      </div>

      {/* عرض المواد */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {materials.map((material) => (
          <div key={material._id} className="bg-white rounded-lg shadow-md p-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-2xl mr-2">
                  {getFileIcon(material.fileType)}
                </span>
                <h3 className="font-medium">{material.title}</h3>
              </div>
              <div className="text-sm text-gray-500">
                {(material.size / 1024 / 1024).toFixed(2)} MB
              </div>
            </div>

            <p className="text-gray-600 text-sm mt-2">
              {material.description}
            </p>

            <div className="mt-4 flex justify-between items-center">
              <div className="text-sm text-gray-500">
                {new Date(material.uploadedAt).toLocaleDateString('ar-SA')}
              </div>
              <div className="text-sm text-gray-500">
                {material.downloads} تحميل
              </div>
            </div>

            <div className="mt-4 flex gap-2">
              <a
                href={material.fileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-blue-100 text-blue-700 px-4 py-2 rounded text-center hover:bg-blue-200"
              >
                عرض
              </a>
              <a
                href={`${material.fileUrl}?download=true`}
                className="flex-1 bg-green-100 text-green-700 px-4 py-2 rounded text-center hover:bg-green-200"
              >
                تحميل
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* نافذة رفع ملف جديد */}
      {uploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-lg w-full">
            <h2 className="text-xl font-semibold mb-4">رفع ملف جديد</h2>
            <form onSubmit={handleUpload}>
              {/* نموذج رفع الملف */}
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="عنوان الملف"
                  value={newMaterial.title}
                  onChange={(e) => setNewMaterial({ ...newMaterial, title: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md"
                  required
                />

                <textarea
                  placeholder="وصف الملف"
                  value={newMaterial.description}
                  onChange={(e) => setNewMaterial({ ...newMaterial, description: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md"
                  rows={3}
                  required
                />

                <select
                  value={newMaterial.subject}
                  onChange={(e) => setNewMaterial({ ...newMaterial, subject: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md"
                  required
                >
                  <option value="">اختر المادة</option>
                  {/* قائمة المواد */}
                </select>

                <select
                  value={newMaterial.grade}
                  onChange={(e) => setNewMaterial({ ...newMaterial, grade: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md"
                  required
                >
                  <option value="">اختر المرحلة</option>
                  {/* قائمة المراحل */}
                </select>

                <input
                  type="file"
                  onChange={(e) => setNewMaterial({ ...newMaterial, file: e.target.files?.[0] || null })}
                  className="w-full"
                  required
                />
              </div>

              <div className="mt-6 flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setUploadModal(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  رفع الملف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}