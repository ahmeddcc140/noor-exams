// ... تكملة الكود السابق
                      <th className="px-4 py-2 text-right">الاختبار</th>
                      <th className="px-4 py-2 text-right">الدرجة</th>
                      <th className="px-4 py-2 text-right">التاريخ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {studentStats.examHistory.map((exam) => (
                      <tr key={exam.examId}>
                        <td className="px-4 py-2">{exam.examTitle}</td>
                        <td className="px-4 py-2">
                          <span className={`${
                            exam.score >= 60 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {exam.score}%
                          </span>
                        </td>
                        <td className="px-4 py-2">
                          {new Date(exam.date).toLocaleDateString('ar-SA')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-6 flex gap-4">
                <button
                  onClick={() => window.open(`/reports/student/${selectedStudent._id}/pdf`, '_blank')}
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  تصدير PDF
                </button>
                <button
                  onClick={() => window.open(`/reports/student/${selectedStudent._id}/excel`, '_blank')}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                  تصدير Excel
                </button>
                <button
                  onClick={() => {
                    window.location.href = `mailto:${selectedStudent.email}`;
                  }}
                  className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
                >
                  إرسال بريد إلكتروني
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex justify-center items-center">
            <div className="text-gray-500">
              اختر طالباً لعرض تفاصيله
            </div>
          </div>
        )}
      </div>
    </div>
  );
}