// ... تكملة الكود السابق
                    <label className="block text-gray-700 font-medium mb-2">
                      درجة النجاح (%)
                    </label>
                    <input
                      type="number"
                      value={form.passingScore}
                      onChange={(e) => setForm({ ...form, passingScore: parseInt(e.target.value) })}
                      className="w-full px-3 py-2 border rounded-md"
                      min="0"
                      max="100"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
                >
                  التالي: إضافة الأسئلة
                </button>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-4">إضافة أسئلة</h3>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => addQuestion('multiple_choice')}
                    className="bg-blue-100 text-blue-700 px-4 py-2 rounded hover:bg-blue-200"
                  >
                    اختيار متعدد
                  </button>
                  <button
                    type="button"
                    onClick={() => addQuestion('essay')}
                    className="bg-green-100 text-green-700 px-4 py-2 rounded hover:bg-green-200"
                  >
                    مقالي
                  </button>
                  <button
                    type="button"
                    onClick={() => addQuestion('true_false')}
                    className="bg-purple-100 text-purple-700 px-4 py-2 rounded hover:bg-purple-200"
                  >
                    صح/خطأ
                  </button>
                  <button
                    type="button"
                    onClick={() => addQuestion('drag_drop')}
                    className="bg-orange-100 text-orange-700 px-4 py-2 rounded hover:bg-orange-200"
                  >
                    سحب وإفلات
                  </button>
                  <button
                    type="button"
                    onClick={() => addQuestion('ordering')}
                    className="bg-pink-100 text-pink-700 px-4 py-2 rounded hover:bg-pink-200"
                  >
                    ترتيب
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                {form.questions.map((question, index) => (
                  <div key={question.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-4">
                      <h4 className="font-medium">سؤال {index + 1}</h4>
                      <button
                        type="button"
                        onClick={() => {
                          const newQuestions = [...form.questions];
                          newQuestions.splice(index, 1);
                          setForm({ ...form, questions: newQuestions });
                        }}
                        className="text-red-600 hover:text-red-800"
                      >
                        حذف
                      </button>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-gray-700 font-medium mb-2">
                          نص السؤال
                        </label>
                        <textarea
                          value={question.text}
                          onChange={(e) => {
                            const newQuestions = [...form.questions];
                            newQuestions[index].text = e.target.value;
                            setForm({ ...form, questions: newQuestions });
                          }}
                          className="w-full px-3 py-2 border rounded-md"
                          rows={2}
                          required
                        />
                      </div>

                      {question.type === 'multiple_choice' && (
                        <div className="space-y-2">
                          {question.options?.map((option, optionIndex) => (
                            <div key={optionIndex} className="flex gap-2">
                              <input
                                type="radio"
                                name={`correct_${question.id}`}
                                checked={question.correctAnswer === optionIndex.toString()}
                                onChange={() => {
                                  const newQuestions = [...form.questions];
                                  newQuestions[index].correctAnswer = optionIndex.toString();
                                  setForm({ ...form, questions: newQuestions });
                                }}
                              />
                              <input
                                type="text"
                                value={option}
                                onChange={(e) => {
                                  const newQuestions = [...form.questions];
                                  newQuestions[index].options![optionIndex] = e.target.value;
                                  setForm({ ...form, questions: newQuestions });
                                }}
                                className="flex-1 px-3 py-2 border rounded-md"
                                placeholder={`الخيار ${optionIndex + 1}`}
                                required
                              />
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">
                            الدرجة
                          </label>
                          <input
                            type="number"
                            value={question.points}
                            onChange={(e) => {
                              const newQuestions = [...form.questions];
                              newQuestions[index].points = parseInt(e.target.value);
                              setForm({ ...form, questions: newQuestions });
                            }}
                            className="w-full px-3 py-2 border rounded-md"
                            min="1"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">
                            الوقت (دقائق)
                          </label>
                          <input
                            type="number"
                            value={question.time}
                            onChange={(e) => {
                              const newQuestions = [...form.questions];
                              newQuestions[index].time = parseInt(e.target.value);
                              setForm({ ...form, questions: newQuestions });
                            }}
                            className="w-full px-3 py-2 border rounded-md"
                            min="0"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="text-gray-600 hover:text-gray-800"
                >
                  السابق
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
                  disabled={form.questions.length === 0}
                >
                  التالي: الإعدادات
                </button>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-4">إعدادات الاختبار</h3>

              <div className="space-y-4">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="allowReview"
                    checked={form.allowReview}
                    onChange={(e) => setForm({ ...form, allowReview: e.target.checked })}
                    className="ml-2"
                  />
                  <label htmlFor="allowReview" className="text-gray-700">
                    السماح بمراجعة الإجابات
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="randomizeQuestions"
                    checked={form.randomizeQuestions}
                    onChange={(e) => setForm({ ...form, randomizeQuestions: e.target.checked })}
                    className="ml-2"
                  />
                  <label htmlFor="randomizeQuestions" className="text-gray-700">
                    ترتيب الأسئلة عشوائياً
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="showResults"
                    checked={form.showResults}
                    onChange={(e) => setForm({ ...form, showResults: e.target.checked })}
                    className="ml-2"
                  />
                  <label htmlFor="showResults" className="text-gray-700">
                    عرض النتائج مباشرة بعد الانتهاء
                  </label>
                </div>
              </div>

              <div className="mt-6 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="text-gray-600 hover:text-gray-800"
                >
                  السابق
                </button>
                <button
                  type="submit"
                  className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700"
                >
                  حفظ الاختبار
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}