'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface ExamSubmission {
  _id: string;
  studentId: string;
  studentName: string;
  submittedAt: string;
  answers: {
    questionId: string;
    questionText: string;
    type: string;
    answer: string;
    points: number;
    maxPoints: number;
    feedback?: string;
    isCorrect?: boolean;
  }[];
  totalScore: number;
  maxScore: number;
  status: 'pending' | 'graded';
}

export default function GradeExam({ params }: { params: { examId: string } }) {
  const router = useRouter();
  const [submissions, setSubmissions] = useState<ExamSubmission[]>([]);
  const [currentSubmission, setCurrentSubmission] = useState<ExamSubmission | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSubmissions();
  }, [params.examId]);

  const fetchSubmissions = async () => {
    try {
      const response = await axios.get(`/api/teacher/exams/${params.examId}/submissions`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setSubmissions(response.data);
      if (response.data.length > 0) {
        setCurrentSubmission(response.data[0]);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching submissions:', error);
      setLoading(false);
    }
  };

  const handleGrade = async (answerId: string, points: number, feedback: string) => {
    if (!currentSubmission) return;

    try {
      await axios.post(`/api/teacher/submissions/${currentSubmission._id}/grade`, {
        answerId,
        points,
        feedback
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });

      // تحديث واجهة المستخدم
      const updatedSubmission = {
        ...currentSubmission,
        answers: currentSubmission.answers.map(answer =>
          answer.questionId === answerId
            ? { ...answer, points, feedback }
            : answer
        )
      };
      setCurrentSubmission(updatedSubmission);

      // تحديث قائمة التقديمات
      setSubmissions(submissions.map(sub =>
        sub._id === currentSubmission._id ? updatedSubmission : sub
      ));
    } catch (error) {
      console.error('Error grading answer:', error);
    }
  };

  const completeGrading = async () => {
    if (!currentSubmission) return;

    try {
      await axios.post(`/api/teacher/submissions/${currentSubmission._id}/complete`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });

      // تحديث حالة التقديم
      const updatedSubmission = { ...currentSubmission, status: 'graded' as const };
      setSubmissions(submissions.map(sub =>
        sub._id === currentSubmission._id ? updatedSubmission : sub
      ));

      // الانتقال إلى التقديم التالي غير المصحح
      const nextSubmission = submissions.find(sub =>
        sub.status === 'pending' && sub._id !== currentSubmission._id
      );
      if (nextSubmission) {
        setCurrentSubmission(nextSubmission);
      }
    } catch (error) {
      console.error('Error completing grading:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex gap-8">
        {/* قائمة التقديمات */}
        <div className="w-1/4">
          <h2 className="text-lg font-semibold mb-4">التقديمات ({submissions.length})</h2>
          <div className="bg-white rounded-lg shadow-md">
            {submissions.map((submission) => (
              <button
                key={submission._id}
                onClick={() => setCurrentSubmission(submission)}
                className={`w-full text-right px-4 py-3 border-b last:border-b-0 hover:bg-gray-50 ${
                  currentSubmission?._id === submission._id ? 'bg-blue-50' : ''
                }`}
              >
                <div className="font-medium">{submission.studentName}</div>
                <div className="text-sm text-gray-500">
                  {new Date(submission.submittedAt).toLocaleString('ar-SA')}
                </div>
                <div className={`text-sm ${
                  submission.status === 'graded' ? 'text-green-600' : 'text-orange-600'
                }`}>
                  {submission.status === 'graded' ? 'تم التصحيح' : 'في انتظار التصحيح'}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* تفاصيل التصحيح */}
        {currentSubmission ? (
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">
                  تصحيح إجابات {currentSubmission.studentName}
                </h2>
                <div className="text-sm text-gray-500">
                  تم التقديم: {new Date(currentSubmission.submittedAt).toLocaleString('ar-SA')}
                </div>
              </div>

              <div className="space-y-8">
                {currentSubmission.answers.map((answer) => (
                  <div key={answer.questionId} className="border rounded-lg p-4">
                    <div className="font-medium mb-2">{answer.questionText}</div>
                    <div className="bg-gray-50 p-3 rounded mb-4">
                      <div className="text-sm text-gray-600 mb-1">إجابة الطالب:</div>
                      <div>{answer.answer}</div>
                    </div>

                    <div className="flex gap-4 items-start">
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          التعليق
                        </label>
                        <textarea
                          value={answer.feedback || ''}
                          onChange={(e) => handleGrade(
                            answer.questionId,
                            answer.points,
                            e.target.value
                          )}
                          className="w-full px-3 py-2 border rounded-md"
                          rows={2}
                        />
                      </div>

                      <div className="w-32">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          الدرجة
                        </label>
                        <input
                          type="number"
                          value={answer.points}
                          onChange={(e) => handleGrade(
                            answer.questionId,
                            parseInt(e.target.value),
                            answer.feedback || ''
                          )}
                          className="w-full px-3 py-2 border rounded-md"
                          min="0"
                          max={answer.maxPoints}
                        />
                        <div className="text-sm text-gray-500 mt-1">
                          من {answer.maxPoints} درجة
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 flex justify-between items-center">
                <div className="text-lg">
                  المجموع: {currentSubmission.totalScore}/{currentSubmission.maxScore}
                  ({Math.round((currentSubmission.totalScore / currentSubmission.maxScore) * 100)}%)
                </div>
                <button
                  onClick={completeGrading}
                  className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700"
                  disabled={currentSubmission.status === 'graded'}
                >
                  {currentSubmission.status === 'graded' ? 'تم التصحيح' : 'إنهاء التصحيح'}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex justify-center items-center">
            <div className="text-gray-500">لا توجد تقديمات للتصحيح</div>
          </div>
        )}
      </div>
    </div>
  );
}