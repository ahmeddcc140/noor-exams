'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface Exam {
  _id: string;
  title: string;
  subject: string;
  duration: number;
  startDate: string;
  endDate: string;
  totalQuestions: number;
  passingScore: number;
  status: 'draft' | 'published' | 'active' | 'completed';
  enrolledStudents: number;
  completedStudents: number;
}

export default function ExamsManagement() {
  const router = useRouter();
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchExams();
  }, [filter]);

  const fetchExams = async () => {
    try {
      const response = await axios.get(`/api/teacher/exams?status=${filter}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setExams(response.data);
    } catch (error) {
      console.error('Error fetching exams:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadgeColor = (status: string) => {
    const colors = {
      draft: 'bg-gray-100 text-gray-800',
      published: 'bg-blue-100 text-blue-800',
      active: 'bg-green-100 text-green-800',
      completed: 'bg-purple-100 text-purple-800'
    };
    return colors[status] || colors.draft;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">إدارة الاختبارات</h1>
        <button
          onClick={() => router.push('/teacher/exams/create')}
          className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
        >
          إنشاء اختبار جديد
        </button>
      </div>

      {/* فلتر الاختبارات */}
      <div className="mb-6">
        <div className="flex space-x-4 rtl:space-x-reverse">
          {['all', 'draft', 'published', 'active', 'completed'].map((status) => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`px-4 py-2 rounded-md ${
                filter === status
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {status === 'all' ? 'الكل' :
               status === 'draft' ? 'مسودة' :
               status === 'published' ? 'منشور' :
               status === 'active' ? 'نشط' : 'مكتمل'}
            </button>
          ))}
        </div>
      </div>

      {/* قائمة الاختبارات */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
          </div>
        ) : (
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  عنوان الاختبار
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  المادة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الحالة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  التاريخ
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  المشاركون
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الإجراءات
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {exams.map((exam) => (
                <tr key={exam._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {exam.title}
                    </div>
                    <div className="text-sm text-gray-500">
                      {exam.totalQuestions} أسئلة • {exam.duration} دقيقة
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{exam.subject}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeColor(exam.status)}`}>
                      {exam.status === 'draft' ? 'مسودة' :
                       exam.status === 'published' ? 'منشور' :
                       exam.status === 'active' ? 'نشط' : 'مكتمل'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(exam.startDate).toLocaleDateString('ar-SA')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {exam.completedStudents}/{exam.enrolledStudents}
                    </div>
                    <div className="text-sm text-gray-500">
                      {Math.round((exam.completedStudents / exam.enrolledStudents) * 100)}% أكملوا
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2 rtl:space-x-reverse">
                      <button
                        onClick={() => router.push(`/teacher/exams/${exam._id}`)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        عرض
                      </button>
                      <button
                        onClick={() => router.push(`/teacher/exams/${exam._id}/edit`)}
                        className="text-green-600 hover:text-green-900"
                      >
                        تعديل
                      </button>
                      <button
                        onClick={() => router.push(`/teacher/exams/${exam._id}/results`)}
                        className="text-purple-600 hover:text-purple-900"
                      >
                        النتائج
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}