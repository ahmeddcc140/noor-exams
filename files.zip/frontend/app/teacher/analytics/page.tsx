'use client';

import { useState, useEffect } from 'react';
import { Chart } from 'react-chartjs-2';
import axios from 'axios';

interface AnalyticsData {
  examStats: {
    totalExams: number;
    averageScore: number;
    passRate: number;
    subjectPerformance: {
      subject: string;
      averageScore: number;
      studentCount: number;
    }[];
  };
  studentProgress: {
    improving: number;
    stable: number;
    declining: number;
    topPerformers: {
      studentId: string;
      name: string;
      averageScore: number;
    }[];
  };
  timeAnalysis: {
    date: string;
    averageScore: number;
    examCount: number;
  }[];
}

export default function Analytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [timeRange, setTimeRange] = useState('month'); // week, month, year
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`/api/teacher/analytics?range=${timeRange}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setData(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !data) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-4">التحليلات والإحصائيات</h1>
        <div className="flex gap-4">
          {['week', 'month', 'year'].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-4 py-2 rounded-md ${
                timeRange === range
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              {range === 'week' ? 'أسبوع' :
               range === 'month' ? 'شهر' : 'سنة'}
            </button>
          ))}
        </div>
      </div>

      {/* الإحصائيات العامة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium mb-2">إجمالي الاختبارات</h3>
          <p className="text-3xl font-bold text-blue-600">
            {data.examStats.totalExams}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium mb-2">متوسط الدرجات</h3>
          <p className="text-3xl font-bold text-green-600">
            {data.examStats.averageScore}%
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium mb-2">نسبة النجاح</h3>
          <p className="text-3xl font-bold text-purple-600">
            {data.examStats.passRate}%
          </p>
        </div>
      </div>

      {/* تحليل المواد */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h3 className="text-lg font-medium mb-4">أداء المواد الدراسية</h3>
        <div className="h-96">
          <Chart
            type="bar"
            data={{
              labels: data.examStats.subjectPerformance.map(s => s.subject),
              datasets: [
                {
                  label: 'متوسط الدرجات',
                  data: data.examStats.subjectPerformance.map(s => s.averageScore),
                  backgroundColor: 'rgba(59, 130, 246, 0.5)',
                  borderColor: 'rgb(59, 130, 246)',
                  borderWidth: 1
                }
              ]
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true,
                  max: 100
                }
              }
            }}
          />
        </div>
      </div>

      {/* تقدم الطلاب */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium mb-4">تطور مستوى الطلاب</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>تحسن</span>
              <span className="text-green-600">{data.studentProgress.improving} طالب</span>
            </div>
            <div className="flex justify-between items-center">
              <span>ثبات</span>
              <span className="text-blue-600">{data.studentProgress.stable} طالب</span>
            </div>
            <div className="flex justify-between items-center">
              <span>تراجع</span>
              <span className="text-red-600">{data.studentProgress.declining} طالب</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium mb-4">أفضل الطلاب أداءً</h3>
          <div className="space-y-4">
            {data.studentProgress.topPerformers.map((student, index) => (
              <div key={student.studentId} className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="text-gray-500">{index + 1}.</span>
                  <span>{student.name}</span>
                </div>
                <span className="text-blue-600">{student.averageScore}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* تحليل زمني */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-medium mb-4">التحليل الزمني</h3>
        <div className="h-80">
          <Chart
            type="line"
            data={{
              labels: data.timeAnalysis.map(t => 
                new Date(t.date).toLocaleDateString('ar-SA')
              ),
              datasets: [
                {
                  label: 'متوسط الدرجات',
                  data: data.timeAnalysis.map(t => t.averageScore),
                  borderColor: 'rgb(59, 130, 246)',
                  tension: 0.1,
                  fill: false
                }
              ]
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true,
                  max: 100
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  );
}