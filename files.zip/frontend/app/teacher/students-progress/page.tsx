'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import { Chart } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface StudentProgress {
  studentId: string;
  studentName: string;
  examResults: {
    examId: string;
    examTitle: string;
    score: number;
    maxScore: number;
    submissionDate: string;
  }[];
  averageScore: number;
}

export default function StudentsProgress() {
  const [studentsProgress, setStudentsProgress] = useState<StudentProgress[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<string>('');

  useEffect(() => {
    fetchStudentsProgress();
  }, []);

  const fetchStudentsProgress = async () => {
    try {
      const response = await axios.get('/api/teacher/students-progress', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      setStudentsProgress(response.data);
    } catch (error) {
      console.error('Error fetching students progress:', error);
    }
  };

  const chartData = {
    labels: studentsProgress.map(student => student.studentName),
    datasets: [
      {
        label: 'متوسط الدرجات',
        data: studentsProgress.map(student => student.averageScore),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      }
    ]
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">تقدم الطلاب</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* إحصائيات عامة */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">الإحصائيات العامة</h2>
          <div className="h-80">
            <Chart type="bar" data={chartData} />
          </div>
        </div>

        {/* تفاصيل الطلاب */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">تفاصيل الطلاب</h2>
          <div className="space-y-4">
            {studentsProgress.map((student) => (
              <div key={student.studentId} className="border-b pb-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium">{student.studentName}</h3>
                  <span className="text-gray-600">
                    المتوسط: {student.averageScore.toFixed(1)}%
                  </span>
                </div>
                <div className="space-y-2">
                  {student.examResults.map((result) => (
                    <div key={result.examId} className="flex justify-between text-sm">
                      <span>{result.examTitle}</span>
                      <span className="text-gray-600">
                        {result.score}/{result.maxScore}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}