'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';

interface TeacherSettings {
  profile: {
    fullName: string;
    email: string;
    phone: string;
    avatar: string;
    bio: string;
  };
  notifications: {
    emailNotifications: boolean;
    examResults: boolean;
    studentMessages: boolean;
    systemUpdates: boolean;
  };
  privacy: {
    showEmail: boolean;
    showPhone: boolean;
    allowMessages: boolean;
    allowParentContact: boolean;
  };
  preferences: {
    language: 'ar' | 'en';
    theme: 'light' | 'dark';
    autoGrading: boolean;
    useAI: boolean;
  };
}

export default function TeacherSettings() {
  const [settings, setSettings] = useState<TeacherSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('profile');
  const [avatar, setAvatar] = useState<File | null>(null);
  const [saveStatus, setSaveStatus] = useState('');

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await axios.get('/api/teacher/settings', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setSettings(response.data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (section: string, data: any) => {
    try {
      setSaveStatus('جارٍ الحفظ...');
      await axios.patch(`/api/teacher/settings/${section}`, data, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setSaveStatus('تم الحفظ بنجاح');
      setTimeout(() => setSaveStatus(''), 3000);
    } catch (error) {
      console.error('Error saving settings:', error);
      setSaveStatus('حدث خطأ أثناء الحفظ');
    }
  };

  const handleAvatarUpload = async (file: File) => {
    const formData = new FormData();
    formData.append('avatar', file);

    try {
      await axios.post('/api/teacher/settings/avatar', formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'multipart/form-data'
        }
      });
      fetchSettings();
    } catch (error) {
      console.error('Error uploading avatar:', error);
    }
  };

  if (loading || !settings) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">إعدادات الحساب</h1>

      <div className="flex gap-8">
        {/* القائمة الجانبية */}
        <div className="w-64">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            {['profile', 'notifications', 'privacy', 'preferences'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`w-full text-right px-4 py-3 border-b last:border-b-0 ${
                  activeTab === tab ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
                }`}
              >
                {tab === 'profile' ? 'الملف الشخصي' :
                 tab === 'notifications' ? 'الإشعارات' :
                 tab === 'privacy' ? 'الخصوصية' : 'التفضيلات'}
              </button>
            ))}
          </div>
        </div>

        {/* المحتوى */}
        <div className="flex-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <div className="flex items-center gap-6">
                  <div className="relative">
                    <img
                      src={settings.profile.avatar || '/default-avatar.png'}
                      alt="الصورة الشخصية"
                      className="w-24 h-24 rounded-full object-cover"
                    />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files?.[0] && handleAvatarUpload(e.target.files[0])}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium">الصورة الشخصية</h3>
                    <p className="text-sm text-gray-500">
                      اختر صورة شخصية لملفك التعريفي
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      الاسم الكامل
                    </label>
                    <input
                      type="text"
                      value={settings.profile.fullName}
                      onChange={(e) => setSettings({
                        ...settings,
                        profile: { ...settings.profile, fullName: e.target.value }
                      })}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      البريد الإلكتروني
                    </label>
                    <input
                      type="email"
                      value={settings.profile.email}
                      onChange={(e) => setSettings({
                        ...settings,
                        profile: { ...settings.profile, email: e.target.value }
                      })}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      رقم الهاتف
                    </label>
                    <input
                      type="tel"
                      value={settings.profile.phone}
                      onChange={(e) => setSettings({
                        ...settings,
                        profile: { ...settings.profile, phone: e.target.value }
                      })}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      نبذة تعريفية
                    </label>
                    <textarea
                      value={settings.profile.bio}
                      onChange={(e) => setSettings({
                        ...settings,
                        profile: { ...settings.profile, bio: e.target.value }
                      })}
                      className="w-full px-3 py-2 border rounded-md"
                      rows={4}
                    />
                  </div>
                </div>

                <button
                  onClick={() => handleSave('profile', settings.profile)}
                  className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
                >
                  حفظ التغييرات
                </button>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium mb-4">إعدادات الإشعارات</h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">إشعارات البريد الإلكتروني</div>
                      <div className="text-sm text-gray-500">
                        استلام الإشعارات عبر البريد الإلكتروني
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.notifications.emailNotifications}
                        onChange={(e) => setSettings({
                          ...settings,
                          notifications: {
                            ...settings.notifications,
                            emailNotifications: e.target.checked
                          }
                        })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">نتائج الاختبارات</div>
                      <div className="text-sm text-gray-500">
                        إشعارات عند اكتمال الاختبارات
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.notifications.examResults}
                        onChange={(e) => setSettings({
                          ...settings,
                          notifications: {
                            ...settings.notifications,
                            examResults: e.target.checked
                          }
                        })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  {/* المزيد من إعدادات الإشعارات */}
                </div>

                <button
                  onClick={() => handleSave('notifications', settings.notifications)}
                  className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
                >
                  حفظ التغييرات
                </button>
              </div>
            )}

            {/* المزيد من الأقسام */}
          </div>
        </div>
      </div>

      {saveStatus && (
        <div className="fixed bottom-4 right-4 bg-gray-800 text-white px-6 py-3 rounded-md shadow-lg">
          {saveStatus}
        </div>
      )}
    </div>
  );
}