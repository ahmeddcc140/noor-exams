'use client';

import { useState, useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import Hero from '@/components/home/Hero';
import Features from '@/components/home/Features';
import Statistics from '@/components/home/Statistics';
import Testimonials from '@/components/home/Testimonials';
import FAQ from '@/components/home/FAQ';
import Footer from '@/components/layout/Footer';
import RegisterModal from '@/components/auth/RegisterModal';

export default function HomePage() {
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [stats, setStats] = useState({
    students: 0,
    teachers: 0,
    admins: 0,
    exams: 0,
    successRate: 0
  });

  useEffect(() => {
    fetchStatistics();
  }, []);

  const fetchStatistics = async () => {
    try {
      const response = await fetch('/api/statistics');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching statistics:', error);
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar onRegisterClick={() => setShowRegisterModal(true)} />
      
      <main>
        <Hero onRegisterClick={() => setShowRegisterModal(true)} />
        <Features />
        <Statistics stats={stats} />
        <Testimonials />
        <FAQ />
      </main>

      <Footer />

      {showRegisterModal && (
        <RegisterModal onClose={() => setShowRegisterModal(false)} />
      )}
    </div>
  );
}