<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class StudentController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'full_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'student_phone' => 'nullable|string|min:11',
            'parent_phone' => 'required|string|min:11',
            'education_level' => 'required|string',
            'grade' => 'required|string',
        ]);

        $user = User::create([
            'name' => $request->full_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'student',
        ]);

        $student = Student::create([
            'user_id' => $user->id,
            'full_name' => $request->full_name,
            'email' => $request->email,
            'student_code' => 'STUD' . Str::random(6),
            'student_phone' => $request->student_phone,
            'parent_phone' => $request->parent_phone,
            'parent_code' => 'PAR' . Str::random(6),
            'education_level' => $request->education_level,
            'grade' => $request->grade,
        ]);

        // إرسال SMS لولي الأمر
        $this->sendParentSMS($student);

        return response()->json([
            'message' => 'تم التسجيل بنجاح',
            'student_code' => $student->student_code
        ]);
    }

    private function sendParentSMS(Student $student)
    {
        $message = sprintf(
            'مرحباً، تم تسجيل ابنكم في نظام نور للاختبارات. كود الدخول الخاص بكم: %s',
            $student->parent_code
        );

        // استخدام خدمة SMS
        try {
            $twilio = new \Twilio\Rest\Client(
                config('services.twilio.sid'),
                config('services.twilio.token')
            );

            $twilio->messages->create(
                $student->parent_phone,
                [
                    'from' => config('services.twilio.from'),
                    'body' => $message
                ]
            );
        } catch (\Exception $e) {
            \Log::error('Failed to send SMS: ' . $e->getMessage());
        }
    }
}