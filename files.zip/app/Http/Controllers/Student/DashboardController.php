<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Services\AIAnalytics;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    protected $aiAnalytics;

    public function __construct(AIAnalytics $aiAnalytics)
    {
        $this->aiAnalytics = $aiAnalytics;
    }

    public function index()
    {
        $student = auth()->user()->student;

        $data = [
            'upcomingExams' => $student->exams()
                ->where('start_date', '>', now())
                ->orderBy('start_date')
                ->take(5)
                ->get(),

            'pendingTasks' => $student->tasks()
                ->where('status', 'pending')
                ->orderBy('due_date')
                ->take(5)
                ->get(),

            'recentAchievements' => $student->achievements()
                ->latest()
                ->take(5)
                ->get(),

            'averageScore' => $student->examResults()
                ->avg('obtained_marks'),

            'completedExams' => $student->examResults()
                ->where('status', 'completed')
                ->count(),

            'completedTasks' => $student->tasks()
                ->where('status', 'completed')
                ->count(),

            'analysis' => $this->aiAnalytics->analyzePerformance($student->id)
        ];

        return view('student.dashboard', $data);
    }
}