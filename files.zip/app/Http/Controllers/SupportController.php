<?php

namespace App\Http\Controllers;

use App\Models\SupportTicket;
use App\Services\TicketService;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    protected $ticketService;

    public function __construct(TicketService $ticketService)
    {
        $this->ticketService = $ticketService;
    }

    public function index()
    {
        $tickets = SupportTicket::where('user_id', auth()->id())
            ->latest()
            ->paginate(10);

        return view('support.index', compact('tickets'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'subject' => 'required|string|max:255',
            'description' => 'required|string',
            'priority' => 'required|in:low,medium,high',
            'category' => 'required|string'
        ]);

        $ticket = $this->ticketService->createTicket($validated);

        return redirect()->route('support.show', $ticket)
            ->with('success', 'تم إنشاء تذكرة الدعم بنجاح');
    }
}