<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Lesson;
use App\Services\ContentService;
use Illuminate\Http\Request;

class LMSController extends Controller
{
    protected $contentService;

    public function __construct(ContentService $contentService)
    {
        $this->contentService = $contentService;
        $this->middleware('auth');
    }

    public function index()
    {
        $courses = Course::with(['lessons', 'teacher'])
            ->when(auth()->user()->role === 'student', function($query) {
                return $query->whereHas('students', function($q) {
                    $q->where('student_id', auth()->user()->student->id);
                });
            })
            ->latest()
            ->paginate(12);

        return view('lms.index', compact('courses'));
    }

    public function showCourse(Course $course)
    {
        $progress = auth()->user()->role === 'student' ? 
            $this->contentService->calculateProgress(auth()->user()->student->id, $course->id) : null;

        return view('lms.course', compact('course', 'progress'));
    }

    public function showLesson(Course $course, Lesson $lesson)
    {
        // تسجيل مشاهدة الدرس
        if(auth()->user()->role === 'student') {
            $this->contentService->recordLessonView(
                auth()->user()->student->id, 
                $lesson->id
            );
        }

        return view('lms.lesson', compact('course', 'lesson'));
    }
}