<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Services\AIAnalytics;
use Illuminate\Http\Request;
use PDF;

class ReportController extends Controller
{
    protected $aiAnalytics;

    public function __construct(AIAnalytics $aiAnalytics)
    {
        $this->aiAnalytics = $aiAnalytics;
    }

    public function studentProgress($studentId)
    {
        $student = Student::findOrFail($studentId);
        $analysis = $this->aiAnalytics->analyzePerformance($studentId);
        
        $data = [
            'student' => $student,
            'analysis' => $analysis,
            'exams' => $student->examResults()->with('exam')->get(),
            'achievements' => $student->achievements
        ];

        return view('reports.student-progress', $data);
    }

    public function generatePDF($studentId)
    {
        $data = $this->getReportData($studentId);
        $pdf = PDF::loadView('reports.pdf.student-progress', $data);
        
        return $pdf->download('تقرير-الأداء.pdf');
    }
}