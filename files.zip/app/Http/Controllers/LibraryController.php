<?php

namespace App\Http\Controllers;

use App\Models\Resource;
use App\Services\AIAnalytics;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class LibraryController extends Controller
{
    protected $aiAnalytics;

    public function __construct(AIAnalytics $aiAnalytics)
    {
        $this->aiAnalytics = $aiAnalytics;
    }

    public function index(Request $request)
    {
        $query = Resource::query();

        // فلترة حسب المادة
        if ($request->has('subject')) {
            $query->where('subject_id', $request->subject);
        }

        // فلترة حسب النوع
        if ($request->has('type')) {
            $query->where('type', $request->type);
        }

        // البحث في العنوان والوصف
        if ($request->has('search')) {
            $query->where(function($q) use ($request) {
                $q->where('title', 'like', "%{$request->search}%")
                  ->orWhere('description', 'like', "%{$request->search}%");
            });
        }

        $resources = $query->with(['subject', 'teacher'])
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        // اقتراحات ذكية للمواد التعليمية
        $recommendations = $this->aiAnalytics->getResourceRecommendations(
            auth()->user()->student->id
        );

        return view('library.index', compact('resources', 'recommendations'));
    }

    public function show(Resource $resource)
    {
        // تحديث عدد المشاهدات
        $resource->increment('views_count');

        // تسجيل نشاط المستخدم
        activity()
            ->performedOn($resource)
            ->causedBy(auth()->user())
            ->log('viewed resource');

        return view('library.show', compact('resource'));
    }

    public function download(Resource $resource)
    {
        // تحديث عدد التحميلات
        $resource->increment('downloads_count');

        // تسجيل نشاط التحميل
        activity()
            ->performedOn($resource)
            ->causedBy(auth()->user())
            ->log('downloaded resource');

        return Storage::download($resource->file_path, $resource->title);
    }
}