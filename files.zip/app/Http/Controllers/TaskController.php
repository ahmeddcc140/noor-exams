<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\Student;
use Illuminate\Http\Request;
use App\Notifications\TaskAssigned;
use App\Notifications\TaskSubmitted;
use Illuminate\Support\Facades\Storage;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = Task::when(auth()->user()->role === 'student', function($query) {
            return $query->where('student_id', auth()->user()->student->id);
        })->when(auth()->user()->role === 'teacher', function($query) {
            return $query->where('teacher_id', auth()->user()->teacher->id);
        })->latest()->paginate(10);

        return view('tasks.index', compact('tasks'));
    }

    public function create()
    {
        $students = Student::all();
        return view('tasks.create', compact('students'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'due_date' => 'required|date|after:today',
            'student_id' => 'required|exists:students,id',
            'attachments.*' => 'nullable|file|max:10240' // 10MB max
        ]);

        $task = Task::create([
            ...$validated,
            'teacher_id' => auth()->user()->teacher->id,
            'status' => 'pending'
        ]);

        // معالجة المرفقات
        if($request->hasFile('attachments')) {
            foreach($request->file('attachments') as $file) {
                $path = $file->store('task-attachments');
                $task->attachments()->create([
                    'path' => $path,
                    'name' => $file->getClientOriginalName()
                ]);
            }
        }

        // إرسال إشعار للطالب
        $task->student->user->notify(new TaskAssigned($task));

        return redirect()->route('tasks.index')
            ->with('success', 'تم إنشاء المهمة بنجاح');
    }

    public function submit(Request $request, Task $task)
    {
        $request->validate([
            'submission' => 'required|string',
            'files.*' => 'nullable|file|max:10240'
        ]);

        $task->update([
            'submission' => $request->submission,
            'submitted_at' => now(),
            'status' => 'submitted'
        ]);

        // معالجة الملفات المرفقة
        if($request->hasFile('files')) {
            foreach($request->file('files') as $file) {
                $path = $file->store('task-submissions');
                $task->submissions()->create([
                    'path' => $path,
                    'name' => $file->getClientOriginalName()
                ]);
            }
        }

        // إشعار المعلم
        $task->teacher->user->notify(new TaskSubmitted($task));

        return redirect()->route('tasks.index')
            ->with('success', 'تم تسليم المهمة بنجاح');
    }

    public function review(Task $task)
    {
        return view('tasks.review', compact('task'));
    }

    public function grade(Request $request, Task $task)
    {
        $validated = $request->validate([
            'grade' => 'required|numeric|min:0|max:100',
            'feedback' => 'required|string'
        ]);

        $task->update([
            'grade' => $validated['grade'],
            'feedback' => $validated['feedback'],
            'status' => 'completed'
        ]);

        return redirect()->route('tasks.index')
            ->with('success', 'تم تقييم المهمة بنجاح');
    }
}