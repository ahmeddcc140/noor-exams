<?php

namespace App\Http\Controllers;

use App\Models\Package;
use App\Models\Subscription;
use App\Services\PaymentService;
use Illuminate\Http\Request;

class SubscriptionController extends Controller
{
    protected $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    public function showPackages()
    {
        $packages = Package::where('is_active', true)->get();
        return view('subscriptions.packages', compact('packages'));
    }

    public function checkout(Package $package)
    {
        return view('subscriptions.checkout', compact('package'));
    }

    public function processPayment(Request $request)
    {
        $validated = $request->validate([
            'package_id' => 'required|exists:packages,id',
            'payment_method' => 'required|string'
        ]);

        $package = Package::findOrFail($request->package_id);

        // إنشاء الاشتراك
        $subscription = Subscription::create([
            'student_id' => auth()->user()->student->id,
            'package_id' => $package->id,
            'starts_at' => now(),
            'ends_at' => now()->addDays($package->duration_in_days),
            'status' => 'pending'
        ]);

        // بدء عملية الدفع
        $paymentResponse = $this->paymentService->initiatePayment(
            $subscription,
            $request->payment_method,
            $request->all()
        );

        // توجيه المستخدم حسب وسيلة الدفع
        return match($request->payment_method) {
            'fawry' => redirect($paymentResponse['redirect_url']),
            'vodafone_cash' => view('subscriptions.vodafone-instructions', $paymentResponse),
            'bank_transfer' => view('subscriptions.bank-transfer-instructions', $paymentResponse),
            default => redirect()->route('subscriptions.payment-instructions', $paymentResponse)
        };
    }
}