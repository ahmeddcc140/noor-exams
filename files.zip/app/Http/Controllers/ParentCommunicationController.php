<?php

namespace App\Http\Controllers;

use App\Models\ParentMessage;
use App\Models\Student;
use App\Services\NotificationService;
use Illuminate\Http\Request;

class ParentCommunicationController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    public function dashboard()
    {
        $student = Student::where('parent_code', auth()->user()->parent_code)
            ->with(['examResults', 'tasks', 'attendance'])
            ->first();

        return view('parent.dashboard', compact('student'));
    }

    public function sendMessage(Request $request)
    {
        $validated = $request->validate([
            'subject' => 'required|string|max:255',
            'message' => 'required|string',
            'teacher_id' => 'required|exists:teachers,id'
        ]);

        $message = ParentMessage::create([
            'parent_id' => auth()->id(),
            'teacher_id' => $request->teacher_id,
            'subject' => $request->subject,
            'message' => $request->message,
            'status' => 'sent'
        ]);

        // إرسال إشعار للمعلم
        $this->notificationService->notifyTeacher($message);

        return back()->with('success', 'تم إرسال الرسالة بنجاح');
    }
}