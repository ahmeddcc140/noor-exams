<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Exam;
use App\Models\Task;

class Calendar extends Component
{
    public $events = [];
    public $selectedDate;

    public function mount()
    {
        $this->loadEvents();
    }

    public function loadEvents()
    {
        // تحميل الاختبارات
        $exams = Exam::whereBetween('start_date', [
            now()->startOfMonth(),
            now()->endOfMonth()
        ])->get();

        // تحميل المهام
        $tasks = Task::whereBetween('due_date', [
            now()->startOfMonth(),
            now()->endOfMonth()
        ])->get();

        $this->events = [
            'exams' => $exams,
            'tasks' => $tasks
        ];
    }

    public function render()
    {
        return view('livewire.calendar');
    }
}