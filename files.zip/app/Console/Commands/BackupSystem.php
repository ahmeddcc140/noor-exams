<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class BackupSystem extends Command
{
    protected $signature = 'system:backup';
    protected $description = 'Create a full system backup';

    public function handle()
    {
        try {
            // نسخ قاعدة البيانات
            $this->info('Creating database backup...');
            $dbBackup = $this->createDatabaseBackup();

            // نسخ الملفات
            $this->info('Creating files backup...');
            $filesBackup = $this->createFilesBackup();

            // تخزين النسخة الاحتياطية
            $backupName = 'backup_' . now()->format('Y_m_d_His');
            Storage::put(
                "backups/{$backupName}.zip",
                file_get_contents($dbBackup . $filesBackup)
            );

            $this->info('Backup completed successfully!');
        } catch (\Exception $e) {
            $this->error('Backup failed: ' . $e->getMessage());
            Log::error('Backup failed', [
                'error' => $e->getMessage(),
                'timestamp' => now()->format('Y-m-d H:i:s')
            ]);
        }
    }
}