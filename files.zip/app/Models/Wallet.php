<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wallet extends Model
{
    protected $fillable = [
        'user_id',
        'balance',
        'last_transaction_at'
    ];

    public function transactions()
    {
        return $this->hasMany(WalletTransaction::class);
    }

    public function addBalance($amount, $source = 'manual')
    {
        $this->transactions()->create([
            'type' => 'credit',
            'amount' => $amount,
            'source' => $source,
            'balance_before' => $this->balance,
            'balance_after' => $this->balance + $amount
        ]);

        $this->increment('balance', $amount);
        $this->update(['last_transaction_at' => now()]);
    }

    public function deductBalance($amount, $description = '')
    {
        if ($this->balance < $amount) {
            throw new \Exception('رصيد غير كافي');
        }

        $this->transactions()->create([
            'type' => 'debit',
            'amount' => $amount,
            'description' => $description,
            'balance_before' => $this->balance,
            'balance_after' => $this->balance - $amount
        ]);

        $this->decrement('balance', $amount);
        $this->update(['last_transaction_at' => now()]);
    }
}