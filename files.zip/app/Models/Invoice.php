<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $fillable = [
        'subscription_id',
        'payment_id',
        'invoice_number',
        'subtotal',
        'discount',
        'tax',
        'total',
        'status',
        'due_date'
    ];

    public function generateInvoicePDF()
    {
        $data = [
            'invoice' => $this,
            'company' => [
                'name' => 'نظام نور للاختبارات',
                'address' => 'القاهرة، مصر',
                'phone' => '+20 123 456 7890',
                'email' => 'info@noor-exams.com',
                'tax_number' => '123456789'
            ]
        ];

        $pdf = PDF::loadView('invoices.template', $data);
        return $pdf;
    }
}