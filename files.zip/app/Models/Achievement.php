<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class Achievement extends Model
{
    use HasUuids;

    protected $fillable = [
        'student_id',
        'type',
        'title',
        'description',
        'points',
        'earned_at'
    ];

    protected $casts = [
        'earned_at' => 'datetime'
    ];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }
}