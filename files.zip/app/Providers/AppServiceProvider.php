<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class AppServiceProvider extends ServiceProvider
{
    public function boot()
    {
        // مراقبة استعلامات قاعدة البيانات البطيئة
        DB::listen(function($query) {
            if ($query->time > 100) {
                Log::warning('Slow Query: ' . $query->sql, [
                    'time' => $query->time,
                    'user' => auth()->user()?->id ?? 'guest',
                    'timestamp' => now()->format('Y-m-d H:i:s')
                ]);
            }
        });

        // تخزين مؤقت للبيانات المتكررة
        Cache::remember('system_settings', 3600, function () {
            return DB::table('settings')->get();
        });
    }
}