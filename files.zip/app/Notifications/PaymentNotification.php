<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class PaymentNotification extends Notification
{
    protected $payment;
    protected $type;

    public function __construct($payment, $type = 'success')
    {
        $this->payment = $payment;
        $this->type = $type;
    }

    public function via($notifiable)
    {
        return ['mail', 'database', 'sms'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject($this->getSubject())
            ->greeting('مرحباً ' . $notifiable->name)
            ->line($this->getMessage())
            ->action(
                'عرض تفاصيل الدفع',
                route('payments.show', $this->payment)
            );
    }

    public function toSms($notifiable)
    {
        return [
            'message' => $this->getSmsMessage(),
            'phone' => $notifiable->phone
        ];
    }

    private function getMessage()
    {
        return match($this->type) {
            'success' => "تم استلام دفعتك بنجاح بقيمة {$this->payment->amount} جنيه مصري",
            'pending' => "في انتظار تأكيد دفعتك بقيمة {$this->payment->amount} جنيه مصري",
            'failed' => "عذراً، فشلت عملية الدفع الخاصة بك",
            default => "تحديث بخصوص دفعتك"
        };
    }
}