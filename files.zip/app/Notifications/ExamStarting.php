<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\DatabaseMessage;

class ExamStarting extends Notification
{
    public $exam;

    public function __construct($exam)
    {
        $this->exam = $exam;
    }

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('تذكير: اختبار قادم')
            ->line("لديك اختبار {$this->exam->title} سيبدأ قريباً")
            ->line("تاريخ البداية: {$this->exam->start_date}")
            ->line("المدة: {$this->exam->duration} دقيقة")
            ->action('عرض تفاصيل الاختبار', route('exams.show', $this->exam));
    }
}