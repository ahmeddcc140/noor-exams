<?php

namespace App\Services;

use App\Models\Payment;
use App\Models\Subscription;
use Exception;

class PaymentService
{
    // وسائل الدفع المتاحة
    const PAYMENT_METHODS = [
        'fawry' => 'فوري',
        'vodafone_cash' => 'فودافون كاش',
        'orange_cash' => 'أورانج كاش',
        'etisalat_cash' => 'اتصالات كاش',
        'bank_transfer' => 'تحويل بنكي',
        'meeza' => 'ميزة'
    ];

    public function initiatePayment(Subscription $subscription, string $paymentMethod, array $paymentDetails)
    {
        // التحقق من صحة وسيلة الدفع
        if (!array_key_exists($paymentMethod, self::PAYMENT_METHODS)) {
            throw new Exception('وسيلة دفع غير صالحة');
        }

        // إنشاء سجل الدفع
        $payment = Payment::create([
            'subscription_id' => $subscription->id,
            'amount' => $subscription->package->price,
            'payment_method' => $paymentMethod,
            'status' => 'pending',
            'payment_details' => $paymentDetails
        ]);

        // معالجة الدفع حسب الوسيلة
        return match($paymentMethod) {
            'fawry' => $this->processFawryPayment($payment),
            'vodafone_cash' => $this->processVodafoneCashPayment($payment),
            'bank_transfer' => $this->processBankTransfer($payment),
            'meeza' => $this->processMeezaPayment($payment),
            default => throw new Exception('وسيلة الدفع غير مدعومة حالياً')
        };
    }

    private function processFawryPayment(Payment $payment)
    {
        // تكامل مع خدمة فوري
        $fawryData = [
            'merchantCode' => config('payment.fawry.merchant_code'),
            'merchantRefNum' => $payment->id,
            'customerProfileId' => $payment->subscription->student_id,
            'amount' => $payment->amount,
            'currencyCode' => 'EGP',
            'language' => 'ar-eg',
            'description' => 'اشتراك في نظام نور للاختبارات'
        ];

        // إرسال الطلب لفوري
        // $response = Http::post('https://api.fawry.com/...', $fawryData);

        return [
            'payment_id' => $payment->id,
            'redirect_url' => "https://atfawry.fawrystaging.com/...",
            'reference_number' => '123456789'
        ];
    }

    private function processVodafoneCashPayment(Payment $payment)
    {
        return [
            'payment_id' => $payment->id,
            'wallet_number' => '0123456789',
            'amount' => $payment->amount,
            'reference' => strtoupper(uniqid('VC'))
        ];
    }
}