<?php

namespace App\Services;

class DocumentationService
{
    /**
     * توثيق تلقائي للعمليات المهمة في النظام
     * 
     * @param string $action نوع العملية
     * @param array $data البيانات المتعلقة بالعملية
     * @param string $user_id معرف المستخدم
     * @return void
     */
    public function logAction($action, $data, $user_id)
    {
        activity()
            ->performedOn($data['model'] ?? null)
            ->causedBy($user_id)
            ->withProperties([
                'action' => $action,
                'data' => $data,
                'timestamp' => now()->format('Y-m-d H:i:s'),
                'ip' => request()->ip()
            ])
            ->log($action);
    }
}