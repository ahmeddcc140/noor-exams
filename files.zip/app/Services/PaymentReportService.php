<?php

namespace App\Services;

use App\Models\Payment;
use Carbon\Carbon;

class PaymentReportService
{
    public function generateDailyReport($date = null)
    {
        $date = $date ?? now();
        
        return Payment::whereDate('created_at', $date)
            ->selectRaw('
                payment_method,
                COUNT(*) as total_transactions,
                SUM(amount) as total_amount,
                SUM(CASE WHEN status = "completed" THEN 1 ELSE 0 END) as successful_transactions,
                SUM(CASE WHEN status = "failed" THEN 1 ELSE 0 END) as failed_transactions
            ')
            ->groupBy('payment_method')
            ->get();
    }

    public function generateMonthlyReport($month = null, $year = null)
    {
        $date = Carbon::create($year ?? now()->year, $month ?? now()->month, 1);
        
        return Payment::whereYear('created_at', $date->year)
            ->whereMonth('created_at', $date->month)
            ->selectRaw('
                DATE(created_at) as date,
                SUM(amount) as daily_total,
                COUNT(*) as transactions_count
            ')
            ->groupBy('date')
            ->orderBy('date')
            ->get();
    }
}