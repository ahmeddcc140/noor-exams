<?php

namespace App\Services;

use App\Models\Exam;
use App\Models\Student;
use App\Models\Task;
use Illuminate\Support\Facades\DB;
use PDF;

class ReportingService
{
    public function generateStudentReport($studentId, $period = 'semester')
    {
        $student = Student::with([
            'examResults',
            'tasks',
            'achievements'
        ])->findOrFail($studentId);

        $data = [
            'student' => $student,
            'performance' => $this->calculatePerformance($student, $period),
            'improvements' => $this->analyzeImprovements($student),
            'recommendations' => $this->generateRecommendations($student)
        ];

        return PDF::loadView('reports.student.detailed', $data);
    }

    public function generateClassReport($gradeId)
    {
        $students = Student::where('grade_id', $gradeId)
            ->with(['examResults', 'tasks'])
            ->get();

        $data = [
            'averagePerformance' => $this->calculateClassAverage($students),
            'topPerformers' => $this->getTopPerformers($students),
            'needsImprovement' => $this->getStudentsNeedingImprovement($students),
            'subjectAnalysis' => $this->analyzeSubjects($gradeId)
        ];

        return PDF::loadView('reports.class.summary', $data);
    }

    private function calculatePerformance($student, $period)
    {
        // حساب الأداء حسب الفترة المحددة
        return [
            'examAverage' => $student->examResults()
                ->whereBetween('created_at', $this->getPeriodDates($period))
                ->avg('score'),
            'tasksCompleted' => $student->tasks()
                ->where('status', 'completed')
                ->whereBetween('created_at', $this->getPeriodDates($period))
                ->count(),
            'achievementsEarned' => $student->achievements()
                ->whereBetween('created_at', $this->getPeriodDates($period))
                ->count()
        ];
    }

    private function getPeriodDates($period)
    {
        switch ($period) {
            case 'week':
                return [now()->subWeek(), now()];
            case 'month':
                return [now()->subMonth(), now()];
            case 'semester':
                return [now()->subMonths(6), now()];
            default:
                return [now()->subYear(), now()];
        }
    }
}