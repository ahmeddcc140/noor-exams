<?php

namespace App\Services;

class InstallmentService
{
    public function calculateInstallments($totalAmount, $months)
    {
        $interestRates = [
            3 => 0.05,  // 5% للتقسيط 3 شهور
            6 => 0.08,  // 8% للتقسيط 6 شهور
            12 => 0.12  // 12% للتقسيط 12 شهر
        ];

        $interest = $interestRates[$months] ?? 0;
        $totalWithInterest = $totalAmount * (1 + $interest);
        $monthlyPayment = $totalWithInterest / $months;

        return [
            'total_amount' => $totalAmount,
            'interest_rate' => $interest * 100 . '%',
            'total_with_interest' => $totalWithInterest,
            'monthly_payment' => $monthlyPayment,
            'number_of_months' => $months,
            'payment_schedule' => $this->generatePaymentSchedule($monthlyPayment, $months)
        ];
    }

    private function generatePaymentSchedule($monthlyPayment, $months)
    {
        $schedule = [];
        $startDate = now();

        for ($i = 1; $i <= $months; $i++) {
            $schedule[] = [
                'installment_number' => $i,
                'amount' => $monthlyPayment,
                'due_date' => $startDate->copy()->addMonths($i)->format('Y-m-d'),
                'status' => 'pending'
            ];
        }

        return $schedule;
    }
}