<?php

namespace App\Services;

use OpenAI\Client;
use App\Models\Student;
use App\Models\ExamResult;
use App\Models\Task;
use Illuminate\Support\Facades\Cache;

class AIAnalytics
{
    protected $openai;
    
    public function __construct()
    {
        $this->openai = \OpenAI::client(config('services.openai.api_key'));
    }

    public function analyzeStudentPerformance($studentId)
    {
        $cacheKey = "student_analysis_{$studentId}";
        
        return Cache::remember($cacheKey, now()->addHours(24), function() use ($studentId) {
            $student = Student::with(['examResults', 'tasks', 'achievements'])->find($studentId);
            
            $data = $this->collectStudentData($student);
            return $this->generateAnalysis($data);
        });
    }

    private function collectStudentData($student)
    {
        return [
            'exam_performance' => $this->analyzeExamResults($student),
            'task_completion' => $this->analyzeTaskCompletion($student),
            'learning_patterns' => $this->analyzeLearningPatterns($student),
            'strengths_weaknesses' => $this->identifyStrengthsWeaknesses($student)
        ];
    }

    private function generateAnalysis($data)
    {
        $prompt = $this->buildAnalysisPrompt($data);
        
        $response = $this->openai->chat()->create([
            'model' => 'gpt-4',
            'messages' => [
                ['role' => 'system', 'content' => 'أنت مساعد تعليمي متخصص في تحليل أداء الطلاب وتقديم توصيات مخصصة.'],
                ['role' => 'user', 'content' => $prompt]
            ]
        ]);

        return [
            'analysis' => $response->choices[0]->message->content,
            'data' => $data
        ];
    }

    private function buildAnalysisPrompt($data)
    {
        return sprintf(
            "قم بتحليل أداء الطالب بناءً على البيانات التالية:\n\n" .
            "أداء الاختبارات:\n%s\n\n" .
            "إكمال المهام:\n%s\n\n" .
            "أنماط التعلم:\n%s\n\n" .
            "نقاط القوة والضعف:\n%s\n\n" .
            "قدم تحليلاً شاملاً وتوصيات للتحسين.",
            json_encode($data['exam_performance'], JSON_PRETTY_PRINT),
            json_encode($data['task_completion'], JSON_PRETTY_PRINT),
            json_encode($data['learning_patterns'], JSON_PRETTY_PRINT),
            json_encode($data['strengths_weaknesses'], JSON_PRETTY_PRINT)
        );
    }
}