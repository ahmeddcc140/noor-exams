export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  criteria: string;
  points: number;
  createdAt: Date;
}

export interface Certificate {
  id: string;
  title: string;
  description: string;
  issuedTo: string;
  issuedBy: string;
  issuedAt: Date;
  expiresAt?: Date;
  templateId: string;
  verificationCode: string;
}

export interface Achievement {
  id: string;
  userId: string;
  type: 'badge' | 'certificate';
  referenceId: string; // Badge ID or Certificate ID
  earnedAt: Date;
  progress: number;
  total: number;
  status: 'in_progress' | 'completed';
}

export interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: Date;
  type: 'homework' | 'exam' | 'assignment';
  status: 'pending' | 'completed' | 'overdue';
  createdBy: string;
  assignedTo: string[];
  subject: string;
  points: number;
}