<?php

use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    // إدارة الطلاب
    Route::apiResource('students', StudentController::class);
    
    // إدارة الاختبارات
    Route::apiResource('exams', ExamController::class);
    Route::post('exams/{exam}/submit', [ExamController::class, 'submit']);
    
    // التحليل والتقارير
    Route::get('analytics/student/{student}', [AnalyticsController::class, 'studentPerformance']);
    Route::get('analytics/class/{grade}', [AnalyticsController::class, 'classPerformance']);
    
    // المهام والواجبات
    Route::apiResource('tasks', TaskController::class);
    
    // الإنجازات
    Route::get('achievements', [AchievementController::class, 'index']);
});