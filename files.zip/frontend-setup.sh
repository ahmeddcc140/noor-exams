cd frontend
npx create-next-app@latest . --typescript --tailwind --eslint