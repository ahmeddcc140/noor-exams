# إنشاء مجلد المشروع
mkdir noor-exams
cd noor-exams

# تهيئة Git
git init

# إنشاء الهيكل الأساسي للمشروع
mkdir frontend backend