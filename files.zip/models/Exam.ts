import mongoose from 'mongoose';

const examSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
    required: true,
  },
  subject: {
    type: String,
    required: true,
  },
  creator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  duration: {
    type: Number, // in minutes
    required: true,
    default: 60,
  },
  startDate: {
    type: Date,
    required: true,
  },
  endDate: {
    type: Date,
    required: true,
  },
  questions: [{
    question: {
      type: String,
      required: true,
    },
    options: [{
      text: String,
      isCorrect: Boolean,
    }],
    points: {
      type: Number,
      default: 1,
    },
    type: {
      type: String,
      enum: ['multiple-choice', 'true-false', 'essay'],
      required: true,
    },
  }],
  isPublished: {
    type: Boolean,
    default: false,
  },
  accessCode: {
    type: String,
    unique: true,
  },
  allowedStudents: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],
}, {
  timestamps: true,
});

export const Exam = mongoose.model('Exam', examSchema);