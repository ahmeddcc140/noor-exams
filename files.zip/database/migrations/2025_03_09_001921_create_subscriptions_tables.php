<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // جدول الباقات
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description');
            $table->decimal('price', 10, 2);
            $table->integer('duration_in_days');
            $table->json('features');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // جدول الاشتراكات
        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('student_id')->constrained();
            $table->foreignId('package_id')->constrained();
            $table->datetime('starts_at');
            $table->datetime('ends_at');
            $table->string('status'); // active, expired, cancelled
            $table->timestamps();
        });

        // جدول المدفوعات
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscription_id')->constrained();
            $table->decimal('amount', 10, 2);
            $table->string('payment_method'); // fawry, vodafone_cash, bank_transfer, etc.
            $table->string('transaction_id')->nullable();
            $table->string('status'); // pending, completed, failed
            $table->json('payment_details')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('payments');
        Schema::dropIfExists('subscriptions');
        Schema::dropIfExists('packages');
    }
};