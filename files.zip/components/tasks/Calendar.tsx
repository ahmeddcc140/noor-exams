'use client';

import { useState, useEffect } from 'react';
import { Task } from '@/types/achievements';
import { Calendar as BigCalendar, dateFnsLocalizer } from 'react-big-calendar';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfWeek from 'date-fns/startOfWeek';
import getDay from 'date-fns/getDay';
import arSA from 'date-fns/locale/ar-SA';

const locales = {
  'ar-SA': arSA,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

interface CalendarProps {
  userId: string;
}

export default function Calendar({ userId }: CalendarProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  useEffect(() => {
    fetchTasks();
  }, [userId]);

  const fetchTasks = async () => {
    try {
      const response = await fetch(`/api/users/${userId}/tasks`);
      const data = await response.json();
      setTasks(data.tasks);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const handleSelectEvent = (task: Task) => {
    setSelectedTask(task);
  };

  const calendarEvents = tasks.map(task => ({
    id: task.id,
    title: task.title,
    start: new Date(task.dueDate),
    end: new Date(task.dueDate),
    allDay: true,
    resource: task,
  }));

  return (
    <div className="h-screen p-6">
      <div className="bg-white rounded-xl shadow-md p-6 h-full">
        <BigCalendar
          localizer={localizer}
          events={calendarEvents}
          startAccessor="start"
          endAccessor="end"
          onSelectEvent={event => handleSelectEvent(event.resource)}
          views={['month', 'week', 'day']}
          messages={{
            next: 'التالي',
            previous: 'السابق',
            today: 'اليوم',
            month: 'الشهر',
            week: 'الأسبوع',
            day: 'اليوم',
          }}
          className="h-full"
        />

        {selectedTask && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h3 className="text-xl font-semibold mb-4">{selectedTask.title}</h3>
              <p className="text-gray-600 mb-4">{selectedTask.description}</p>
              <div className="space-y-2 text-sm text-gray-500">
                <div>الموعد النهائي: {new Date(selectedTask.dueDate).toLocaleDateString('ar-SA')}</div>
                <div>المادة: {selectedTask.subject}</div>
                <div>النقاط: {selectedTask.points}</div>
                <div>الحالة: {
                  selectedTask.status === 'pending' ? 'قيد الانتظار' :
                  selectedTask.status === 'completed' ? 'مكتمل' : 'متأخر'
                }</div>
              </div>
              <button
                onClick={() => setSelectedTask(null)}
                className="mt-6 w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                إغلاق
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}