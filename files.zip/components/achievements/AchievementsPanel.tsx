'use client';

import { useState, useEffect } from 'react';
import { Badge, Certificate, Achievement } from '@/types/achievements';
import { motion, AnimatePresence } from 'framer-motion';

interface AchievementsPanelProps {
  userId: string;
}

export default function AchievementsPanel({ userId }: AchievementsPanelProps) {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [selectedTab, setSelectedTab] = useState<'badges' | 'certificates'>('badges');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserAchievements();
  }, [userId]);

  const fetchUserAchievements = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/users/${userId}/achievements`);
      const data = await response.json();
      setAchievements(data.achievements);
      setBadges(data.badges);
      setCertificates(data.certificates);
    } catch (error) {
      console.error('Error fetching achievements:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderBadges = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {badges.map((badge) => (
        <motion.div
          key={badge.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="flex-shrink-0">
              <img
                src={badge.icon}
                alt={badge.name}
                className="w-16 h-16 object-contain"
              />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{badge.name}</h3>
              <p className="text-sm text-gray-600">{badge.description}</p>
              <div className="mt-2">
                <div className="text-xs text-gray-500">التقدم</div>
                <div className="mt-1 h-2 bg-gray-200 rounded-full">
                  <div
                    className="h-full bg-blue-600 rounded-full transition-all duration-500"
                    style={{
                      width: `${(achievements.find(a => a.referenceId === badge.id)?.progress || 0) / 
                        (achievements.find(a => a.referenceId === badge.id)?.total || 1) * 100}%`
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );

  const renderCertificates = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {certificates.map((certificate) => (
        <motion.div
          key={certificate.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-md overflow-hidden"
        >
          <div className="p-6">
            <h3 className="text-xl font-semibold text-gray-900">{certificate.title}</h3>
            <p className="mt-2 text-gray-600">{certificate.description}</p>
            <div className="mt-4 flex justify-between items-center">
              <div className="text-sm text-gray-500">
                تم الإصدار: {new Date(certificate.issuedAt).toLocaleDateString('ar-SA')}
              </div>
              <button
                onClick={() => window.open(`/certificates/${certificate.id}/view`, '_blank')}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                عرض الشهادة
              </button>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );

  return (
    <div className="bg-gray-50 p-6 rounded-xl">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900">الإنجازات والشهادات</h2>
        <p className="mt-2 text-gray-600">اكتشف إنجازاتك وشهاداتك في رحلة التعلم</p>
      </div>

      <div className="mb-6">
        <div className="flex space-x-4 space-x-reverse border-b border-gray-200">
          <button
            onClick={() => setSelectedTab('badges')}
            className={`px-4 py-2 text-sm font-medium ${
              selectedTab === 'badges'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            الشارات
          </button>
          <button
            onClick={() => setSelectedTab('certificates')}
            className={`px-4 py-2 text-sm font-medium ${
              selectedTab === 'certificates'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            الشهادات
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
          </div>
        ) : (
          <motion.div
            key={selectedTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {selectedTab === 'badges' ? renderBadges() : renderCertificates()}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}