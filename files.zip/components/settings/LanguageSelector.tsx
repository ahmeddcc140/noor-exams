'use client';

import { useTranslation } from 'react-i18next';
import { SUPPORTED_LANGUAGES } from '@/lib/i18n/config';
import { useEffect } from 'react';

export default function LanguageSelector() {
  const { i18n } = useTranslation();

  useEffect(() => {
    document.documentElement.dir = SUPPORTED_LANGUAGES[i18n.language].dir;
  }, [i18n.language]);

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    localStorage.setItem('preferredLanguage', lng);
  };

  return (
    <div className="relative group">
      <button className="flex items-center space-x-2 px-4 py-2 rounded-md hover:bg-gray-100">
        <span>{SUPPORTED_LANGUAGES[i18n.language].name}</span>
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      <div className="absolute hidden group-hover:block right-0 mt-2 py-2 w-48 bg-white rounded-md shadow-lg z-50">
        {Object.entries(SUPPORTED_LANGUAGES).map(([code, { name }]) => (
          <button
            key={code}
            onClick={() => changeLanguage(code)}
            className={`w-full text-right px-4 py-2 hover:bg-gray-100 ${
              i18n.language === code ? 'text-blue-600 font-medium' : 'text-gray-700'
            }`}
          >
            {name}
          </button>
        ))}
      </div>
    </div>
  );
}