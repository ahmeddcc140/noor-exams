'use client';

import { useState, useEffect } from 'react';
import { useTheme } from 'next-themes';

interface Theme {
  name: string;
  primary: string;
  secondary: string;
  background: string;
  text: string;
}

const predefinedThemes: Theme[] = [
  {
    name: 'default',
    primary: '#2563eb',
    secondary: '#4f46e5',
    background: '#ffffff',
    text: '#1f2937',
  },
  {
    name: 'dark',
    primary: '#3b82f6',
    secondary: '#6366f1',
    background: '#1f2937',
    text: '#f3f4f6',
  },
  {
    name: 'natural',
    primary: '#059669',
    secondary: '#047857',
    background: '#f8fafc',
    text: '#1f2937',
  },
];

export default function ThemeCustomizer() {
  const { theme, setTheme } = useTheme();
  const [fontSize, setFontSize] = useState('normal');
  const [customColors, setCustomColors] = useState<Theme>(predefinedThemes[0]);

  useEffect(() => {
    const savedFontSize = localStorage.getItem('fontSize') || 'normal';
    setFontSize(savedFontSize);
    
    const savedTheme = localStorage.getItem('customTheme');
    if (savedTheme) {
      setCustomColors(JSON.parse(savedTheme));
    }
  }, []);

  const applyTheme = (newTheme: Theme) => {
    setCustomColors(newTheme);
    localStorage.setItem('customTheme', JSON.stringify(newTheme));
    
    document.documentElement.style.setProperty('--primary-color', newTheme.primary);
    document.documentElement.style.setProperty('--secondary-color', newTheme.secondary);
    document.documentElement.style.setProperty('--background-color', newTheme.background);
    document.documentElement.style.setProperty('--text-color', newTheme.text);
  };

  const changeFontSize = (size: string) => {
    setFontSize(size);
    localStorage.setItem('fontSize', size);
    document.documentElement.setAttribute('data-font-size', size);
  };

  return (
    <div className="space-y-6 p-6 bg-white rounded-lg shadow-md">
      <div>
        <h3 className="text-lg font-semibold mb-4">تخصيص المظهر</h3>
        
        <div className="space-y-4">
          {/* اختيار الثيم */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              السمة
            </label>
            <div className="grid grid-cols-3 gap-4">
              {predefinedThemes.map((themeOption) => (
                <button
                  key={themeOption.name}
                  onClick={() => applyTheme(themeOption)}
                  className={`p-4 rounded-lg border-2 ${
                    customColors.name === themeOption.name
                      ? 'border-blue-500'
                      : 'border-gray-200'
                  }`}
                  style={{
                    backgroundColor: themeOption.background,
                    color: themeOption.text,
                  }}
                >
                  <div
                    className="h-4 rounded-full mb-2"
                    style={{ backgroundColor: themeOption.primary }}
                  />
                  <div className="text-sm font-medium">
                    {themeOption.name === 'default' ? 'افتراضي' :
                     themeOption.name === 'dark' ? 'داكن' : 'طبيعي'}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* حجم الخط */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              حجم الخط
            </label>
            <div className="flex space-x-4 space-x-reverse">
              {['small', 'normal', 'large'].map((size) => (
                <button
                  key={size}
                  onClick={() => changeFontSize(size)}
                  className={`px-4 py-2 rounded-md ${
                    fontSize === size
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {size === 'small' ? 'صغير' :
                   size === 'normal' ? 'عادي' : 'كبير'}
                </button>
              ))}
            </div>
          </div>

          {/* تخصيص الألوان */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              تخصيص الألوان
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-500 mb-1">
                  اللون الرئيسي
                </label>
                <input
                  type="color"
                  value={customColors.primary}
                  onChange={(e) => applyTheme({
                    ...customColors,
                    primary: e.target.value,
                  })}
                  className="w-full h-10 rounded-md cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-500 mb-1">
                  اللون الثانوي
                </label>
                <input
                  type="color"
                  value={customColors.secondary}
                  onChange={(e) => applyTheme({
                    ...customColors,
                    secondary: e.target.value,
                  })}
                  className="w-full h-10 rounded-md cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}