import i18n from 'i18next';

export const SUPPORTED_LANGUAGES = {
  ar: {
    name: 'العربية',
    dir: 'rtl',
    code: 'ar-SA'
  },
  en: {
    name: 'English',
    dir: 'ltr',
    code: 'en-US'
  }
};

i18n.init({
  defaultLanguage: 'ar',
  fallbackLng: 'ar',
  supportedLngs: Object.keys(SUPPORTED_LANGUAGES),
  detection: {
    order: ['localStorage', 'navigator']
  }
});