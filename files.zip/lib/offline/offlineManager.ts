import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface OfflineDB extends DBSchema {
  answers: {
    key: string;
    value: {
      examId: string;
      studentId: string;
      answers: any[];
      timestamp: number;
      synced: boolean;
    };
  };
  tasks: {
    key: string;
    value: {
      id: string;
      data: any;
      lastModified: number;
    };
  };
}

export class OfflineManager {
  private db: IDBPDatabase<OfflineDB>;

  async init() {
    this.db = await openDB<OfflineDB>('noor-offline', 1, {
      upgrade(db) {
        db.createObjectStore('answers');
        db.createObjectStore('tasks');
      },
    });
  }

  async saveExamAnswers(examId: string, studentId: string, answers: any[]) {
    await this.db.put('answers', {
      examId,
      studentId,
      answers,
      timestamp: Date.now(),
      synced: false,
    }, `${examId}_${studentId}`);
  }

  async syncAnswers() {
    const tx = this.db.transaction('answers', 'readwrite');
    const store = tx.objectStore('answers');
    const unsynced = await store.getAll();

    for (const answer of unsynced) {
      if (!answer.synced) {
        try {
          await fetch('/api/exams/submit', {
            method: 'POST',
            body: JSON.stringify(answer),
          });
          
          await store.put({
            ...answer,
            synced: true,
          }, `${answer.examId}_${answer.studentId}`);
        } catch (error) {
          console.error('Failed to sync answer:', error);
        }
      }
    }
  }

  async cacheTask(taskId: string, data: any) {
    await this.db.put('tasks', {
      id: taskId,
      data,
      lastModified: Date.now(),
    }, taskId);
  }

  async getTask(taskId: string) {
    return await this.db.get('tasks', taskId);
  }
}

export const offlineManager = new OfflineManager();