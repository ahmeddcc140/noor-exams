import { prisma } from './db'
import Redis from 'ioredis'

export async function checkHealth() {
  try {
    // فحص قاعدة البيانات
    await prisma.$queryRaw`SELECT 1`
    
    // فحص Redis
    const redis = new Redis(process.env.REDIS_URL)
    await redis.ping()
    
    // فحص المصادقة
    if (!process.env.NEXTAUTH_SECRET) {
      throw new Error('NEXTAUTH_SECRET is not set')
    }
    
    return {
      status: 'healthy',
      database: 'connected',
      cache: 'connected',
      auth: 'configured'
    }
  } catch (error) {
    return {
      status: 'unhealthy',
      error: error.message
    }
  }
}