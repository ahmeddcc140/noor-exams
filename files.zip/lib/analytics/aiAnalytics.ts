// ... يتبع من الكود السابق

  private calculateTrendline(results: PerformanceData['examResults']) {
    const scores = results.map((r) => r.score);
    const n = scores.length;
    
    // حساب متوسط النقاط ومعدل التحسن
    const averageScore = scores.reduce((a, b) => a + b, 0) / n;
    const trend = scores[n - 1] - scores[0];
    
    return {
      averageScore,
      trend,
      isImproving: trend > 0,
      percentageChange: ((scores[n - 1] - scores[0]) / scores[0]) * 100
    };
  }

  private calculateImprovement(results: PerformanceData['examResults']) {
    const improvements = new Map<string, number>();
    
    results.forEach((exam, index) => {
      if (index === 0) return;
      
      exam.topics.forEach(topic => {
        const prevScore = results[index - 1].score;
        const currentScore = exam.score;
        const improvement = currentScore - prevScore;
        
        improvements.set(topic, (improvements.get(topic) || 0) + improvement);
      });
    });
    
    return Array.from(improvements.entries())
      .map(([topic, improvement]) => ({
        topic,
        improvement,
        isPositive: improvement > 0
      }));
  }

  private analyzeTimeEfficiency(results: PerformanceData['examResults']) {
    const timeAnalysis = results.map((exam, index) => {
      const avgTimePerQuestion = exam.timeSpent / exam.topics.length;
      const efficiency = exam.score / exam.timeSpent;
      
      return {
        examId: exam.examId,
        avgTimePerQuestion,
        efficiency,
        improvement: index > 0 ? 
          efficiency - (results[index - 1].score / results[index - 1].timeSpent) : 
          0
      };
    });

    return {
      timeAnalysis,
      overallEfficiency: timeAnalysis.reduce((acc, curr) => acc + curr.efficiency, 0) / timeAnalysis.length
    };
  }

  async generatePersonalizedPlan(studentId: string, analysisResults: any) {
    const prompt = `
      استناداً إلى نتائج التحليل التالية:
      - متوسط الدرجات: ${analysisResults.trendline.averageScore}
      - نسبة التحسن: ${analysisResults.trendline.percentageChange}%
      - نقاط الضعف الرئيسية: ${analysisResults.weaknesses.map(w => w.topic).join(', ')}
      
      قم بإنشاء خطة دراسية مخصصة تتضمن:
      1. الأهداف الأسبوعية
      2. المواد التعليمية المقترحة
      3. التمارين والاختبارات الموصى بها
      4. جدول زمني مقترح للدراسة
    `;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      max_tokens: 1000
    });

    return {
      personalizedPlan: response.choices[0].message.content,
      generatedAt: new Date(),
      studentId,
      validFor: '2 weeks'
    };
  }
}

export const aiAnalytics = new AIAnalytics(process.env.OPENAI_API_KEY!);